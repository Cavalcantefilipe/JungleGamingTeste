const t={tokenId:"ID do token:"};export{t as n};
