import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/CarouselNavigation.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { FigmaIcon } from "/src/components/icons/FigmaIcon.tsx";
import { Button } from "/src/components/ui/button.tsx";
export function CarouselNavigation({ page, pages, goTo }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex shrink-0 gap-2", children: [
    /* @__PURE__ */ jsxDEV(
      Button,
      {
        variant: "ghost",
        size: "icon",
        "aria-label": "Recomendações anteriores",
        disabled: page === 0,
        onClick: () => {
          goTo(page - 1);
        },
        children: /* @__PURE__ */ jsxDEV(FigmaIcon, { name: "chevron-left", "aria-hidden": "true" }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CarouselNavigation.tsx",
          lineNumber: 18,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CarouselNavigation.tsx",
        lineNumber: 9,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Button,
      {
        variant: "ghost",
        size: "icon",
        "aria-label": "Próximas recomendações",
        disabled: page >= pages - 1,
        onClick: () => {
          goTo(page + 1);
        },
        children: /* @__PURE__ */ jsxDEV(FigmaIcon, { name: "chevron-right", "aria-hidden": "true" }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CarouselNavigation.tsx",
          lineNumber: 29,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CarouselNavigation.tsx",
        lineNumber: 20,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CarouselNavigation.tsx",
    lineNumber: 8,
    columnNumber: 5
  }, this);
}
_c = CarouselNavigation;
var _c;
$RefreshReg$(_c, "CarouselNavigation");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CarouselNavigation.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CarouselNavigation.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CarouselNavigation.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJRO0FBakJSLFNBQVNBLGlCQUFpQjtBQUMxQixTQUFTQyxjQUFjO0FBSWhCLGdCQUFTQyxtQkFBbUIsRUFBRUMsTUFBTUMsT0FBT0MsS0FBOEIsR0FBRztBQUNqRixTQUNFLHVCQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFRO0FBQUEsUUFDUixNQUFLO0FBQUEsUUFDTCxjQUFXO0FBQUEsUUFDWCxVQUFVRixTQUFTO0FBQUEsUUFDbkIsU0FBUyxNQUFNO0FBQ2JFLGVBQUtGLE9BQU8sQ0FBQztBQUFBLFFBQ2Y7QUFBQSxRQUVBLGlDQUFDLGFBQVUsTUFBSyxnQkFBZSxlQUFZLFVBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUQ7QUFBQTtBQUFBLE1BVG5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVVBO0FBQUEsSUFDQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsU0FBUTtBQUFBLFFBQ1IsTUFBSztBQUFBLFFBQ0wsY0FBVztBQUFBLFFBQ1gsVUFBVUEsUUFBUUMsUUFBUTtBQUFBLFFBQzFCLFNBQVMsTUFBTTtBQUNiQyxlQUFLRixPQUFPLENBQUM7QUFBQSxRQUNmO0FBQUEsUUFFQSxpQ0FBQyxhQUFVLE1BQUssaUJBQWdCLGVBQVksVUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRDtBQUFBO0FBQUEsTUFUcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBVUE7QUFBQSxPQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUJBO0FBRUo7QUFBQ0csS0EzQmVKO0FBQWtCLElBQUFJO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkZpZ21hSWNvbiIsIkJ1dHRvbiIsIkNhcm91c2VsTmF2aWdhdGlvbiIsInBhZ2UiLCJwYWdlcyIsImdvVG8iLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDYXJvdXNlbE5hdmlnYXRpb24udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZpZ21hSWNvbiB9IGZyb20gJ0AvY29tcG9uZW50cy9pY29ucy9GaWdtYUljb24nO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbic7XG5cbmltcG9ydCB0eXBlIHsgQ2Fyb3VzZWxOYXZpZ2F0aW9uU3RhdGUgfSBmcm9tICcuLi91c2VDYXJvdXNlbCc7XG5cbmV4cG9ydCBmdW5jdGlvbiBDYXJvdXNlbE5hdmlnYXRpb24oeyBwYWdlLCBwYWdlcywgZ29UbyB9OiBDYXJvdXNlbE5hdmlnYXRpb25TdGF0ZSkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBzaHJpbmstMCBnYXAtMlwiPlxuICAgICAgPEJ1dHRvblxuICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxuICAgICAgICBzaXplPVwiaWNvblwiXG4gICAgICAgIGFyaWEtbGFiZWw9XCJSZWNvbWVuZGHDp8O1ZXMgYW50ZXJpb3Jlc1wiXG4gICAgICAgIGRpc2FibGVkPXtwYWdlID09PSAwfVxuICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgZ29UbyhwYWdlIC0gMSk7XG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIDxGaWdtYUljb24gbmFtZT1cImNoZXZyb24tbGVmdFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICA8L0J1dHRvbj5cbiAgICAgIDxCdXR0b25cbiAgICAgICAgdmFyaWFudD1cImdob3N0XCJcbiAgICAgICAgc2l6ZT1cImljb25cIlxuICAgICAgICBhcmlhLWxhYmVsPVwiUHLDs3hpbWFzIHJlY29tZW5kYcOnw7Vlc1wiXG4gICAgICAgIGRpc2FibGVkPXtwYWdlID49IHBhZ2VzIC0gMX1cbiAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgIGdvVG8ocGFnZSArIDEpO1xuICAgICAgICB9fVxuICAgICAgPlxuICAgICAgICA8RmlnbWFJY29uIG5hbWU9XCJjaGV2cm9uLXJpZ2h0XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgIDwvQnV0dG9uPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvZmlsaXBlY2F2YWxjYW50ZS9Eb2N1bWVudHMvSnVuZ2xlR2FtaW5nVGVzdGUvc3JjL2ZlYXR1cmVzL2NhdGFsb2cvY29tcG9uZW50cy9DYXJvdXNlbE5hdmlnYXRpb24udHN4In0=