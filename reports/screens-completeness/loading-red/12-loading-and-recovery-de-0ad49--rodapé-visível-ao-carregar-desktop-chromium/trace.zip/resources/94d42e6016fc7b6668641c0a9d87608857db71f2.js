import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/QuantityInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Input } from "/src/components/ui/input.tsx";
import { cn } from "/src/lib/cn.ts";
export function QuantityInput({
  value,
  max,
  disabled,
  tone,
  onChange
}) {
  return /* @__PURE__ */ jsxDEV(
    Input,
    {
      disabled: disabled || max === 0,
      type: "number",
      "aria-label": "Quantidade",
      inputMode: "numeric",
      min: 1,
      max,
      value,
      onChange: (event) => {
        onChange(Math.max(1, Math.min(max, Number(event.target.value) || 1)));
      },
      className: cn(
        "h-11 w-11 [appearance:textfield] rounded-none border-0 px-0 text-center text-sm shadow-none md:h-11 md:w-6 md:text-sm [&::-webkit-inner-spin-button]:appearance-none",
        tone === "purchase" && "text-xl md:text-xl"
      )
    },
    void 0,
    false,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/QuantityInput.tsx",
      lineNumber: 14,
      columnNumber: 5
    },
    this
  );
}
_c = QuantityInput;
var _c;
$RefreshReg$(_c, "QuantityInput");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/QuantityInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/QuantityInput.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/QuantityInput.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYUk7QUFiSixTQUFTQSxhQUFhO0FBQ3RCLFNBQVNDLFVBQVU7QUFJWixnQkFBU0MsY0FBYztBQUFBLEVBQzVCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNnRCxHQUFHO0FBQ25ELFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFVBQVVGLFlBQVlELFFBQVE7QUFBQSxNQUM5QixNQUFLO0FBQUEsTUFDTCxjQUFXO0FBQUEsTUFDWCxXQUFVO0FBQUEsTUFDVixLQUFLO0FBQUEsTUFDTDtBQUFBLE1BQ0E7QUFBQSxNQUNBLFVBQVUsQ0FBQ0ksVUFBVTtBQUNuQkQsaUJBQVNFLEtBQUtMLElBQUksR0FBR0ssS0FBS0MsSUFBSU4sS0FBS08sT0FBT0gsTUFBTUksT0FBT1QsS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQUEsTUFDdEU7QUFBQSxNQUNBLFdBQVdGO0FBQUFBLFFBQ1Q7QUFBQSxRQUNBSyxTQUFTLGNBQWM7QUFBQSxNQUN6QjtBQUFBO0FBQUEsSUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFjSTtBQUdSO0FBQUNPLEtBekJlWDtBQUFhLElBQUFXO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIklucHV0IiwiY24iLCJRdWFudGl0eUlucHV0IiwidmFsdWUiLCJtYXgiLCJkaXNhYmxlZCIsInRvbmUiLCJvbkNoYW5nZSIsImV2ZW50IiwiTWF0aCIsIm1pbiIsIk51bWJlciIsInRhcmdldCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlF1YW50aXR5SW5wdXQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IElucHV0IH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2lucHV0JztcbmltcG9ydCB7IGNuIH0gZnJvbSAnQC9saWIvY24nO1xuXG5pbXBvcnQgdHlwZSB7IFF1YW50aXR5U3RlcHBlclByb3BzIH0gZnJvbSAnLi9RdWFudGl0eVN0ZXBwZXInO1xuXG5leHBvcnQgZnVuY3Rpb24gUXVhbnRpdHlJbnB1dCh7XG4gIHZhbHVlLFxuICBtYXgsXG4gIGRpc2FibGVkLFxuICB0b25lLFxuICBvbkNoYW5nZSxcbn06IFJlcXVpcmVkPE9taXQ8UXVhbnRpdHlTdGVwcGVyUHJvcHMsICdvblJlbW92ZSc+Pikge1xuICByZXR1cm4gKFxuICAgIDxJbnB1dFxuICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkIHx8IG1heCA9PT0gMH1cbiAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgYXJpYS1sYWJlbD1cIlF1YW50aWRhZGVcIlxuICAgICAgaW5wdXRNb2RlPVwibnVtZXJpY1wiXG4gICAgICBtaW49ezF9XG4gICAgICBtYXg9e21heH1cbiAgICAgIHZhbHVlPXt2YWx1ZX1cbiAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHtcbiAgICAgICAgb25DaGFuZ2UoTWF0aC5tYXgoMSwgTWF0aC5taW4obWF4LCBOdW1iZXIoZXZlbnQudGFyZ2V0LnZhbHVlKSB8fCAxKSkpO1xuICAgICAgfX1cbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICdoLTExIHctMTEgW2FwcGVhcmFuY2U6dGV4dGZpZWxkXSByb3VuZGVkLW5vbmUgYm9yZGVyLTAgcHgtMCB0ZXh0LWNlbnRlciB0ZXh0LXNtIHNoYWRvdy1ub25lIG1kOmgtMTEgbWQ6dy02IG1kOnRleHQtc20gWyY6Oi13ZWJraXQtaW5uZXItc3Bpbi1idXR0b25dOmFwcGVhcmFuY2Utbm9uZScsXG4gICAgICAgIHRvbmUgPT09ICdwdXJjaGFzZScgJiYgJ3RleHQteGwgbWQ6dGV4dC14bCcsXG4gICAgICApfVxuICAgIC8+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9maWxpcGVjYXZhbGNhbnRlL0RvY3VtZW50cy9KdW5nbGVHYW1pbmdUZXN0ZS9zcmMvZmVhdHVyZXMvbmZ0LWRldGFpbC9jb21wb25lbnRzL1F1YW50aXR5SW5wdXQudHN4In0=