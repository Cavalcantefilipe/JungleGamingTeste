import { useNavigate } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=970a124b";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=970a124b"; const useState = __vite__cjsImport1_react["useState"];
import { useAddToCart } from "/src/features/cart/useAddToCart.ts";
export function usePurchaseSelection(nft) {
  const [editionId, setEditionId] = useState(
    nft.editions.find((edition2) => edition2.available > 0)?.id ?? ""
  );
  const [requestedQuantity, setQuantity] = useState(1);
  const mutation = useAddToCart();
  const navigate = useNavigate();
  const edition = nft.editions.find((entry) => entry.id === editionId);
  const available = edition?.available ?? 0;
  const quantity = Math.min(requestedQuantity, Math.max(available, 1));
  const add = (purchase = false) => {
    if (!available || mutation.isPending) return;
    mutation.mutate(
      { nftId: nft.id, editionId, quantity },
      {
        onSuccess: () => {
          if (purchase) void navigate({ to: "/cart" });
        }
      }
    );
  };
  const actions = {
    pending: mutation.isPending,
    disabled: available === 0,
    purchase: () => {
      add(true);
    },
    add: () => {
      add();
    }
  };
  return { editionId, setEditionId, quantity, setQuantity, available, actions };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZVB1cmNoYXNlU2VsZWN0aW9uLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcic7XG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcblxuaW1wb3J0IHR5cGUgeyBOZnQgfSBmcm9tICdAL2NvbnRyYWN0cy9uZnQnO1xuaW1wb3J0IHsgdXNlQWRkVG9DYXJ0IH0gZnJvbSAnQC9mZWF0dXJlcy9jYXJ0L3VzZUFkZFRvQ2FydCc7XG5leHBvcnQgZnVuY3Rpb24gdXNlUHVyY2hhc2VTZWxlY3Rpb24obmZ0OiBOZnQpIHtcbiAgY29uc3QgW2VkaXRpb25JZCwgc2V0RWRpdGlvbklkXSA9IHVzZVN0YXRlKFxuICAgIG5mdC5lZGl0aW9ucy5maW5kKChlZGl0aW9uKSA9PiBlZGl0aW9uLmF2YWlsYWJsZSA+IDApPy5pZCA/PyAnJyxcbiAgKTtcbiAgY29uc3QgW3JlcXVlc3RlZFF1YW50aXR5LCBzZXRRdWFudGl0eV0gPSB1c2VTdGF0ZSgxKTtcbiAgY29uc3QgbXV0YXRpb24gPSB1c2VBZGRUb0NhcnQoKTtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICBjb25zdCBlZGl0aW9uID0gbmZ0LmVkaXRpb25zLmZpbmQoKGVudHJ5KSA9PiBlbnRyeS5pZCA9PT0gZWRpdGlvbklkKTtcbiAgY29uc3QgYXZhaWxhYmxlID0gZWRpdGlvbj8uYXZhaWxhYmxlID8/IDA7XG4gIGNvbnN0IHF1YW50aXR5ID0gTWF0aC5taW4ocmVxdWVzdGVkUXVhbnRpdHksIE1hdGgubWF4KGF2YWlsYWJsZSwgMSkpO1xuICBjb25zdCBhZGQgPSAocHVyY2hhc2UgPSBmYWxzZSkgPT4ge1xuICAgIGlmICghYXZhaWxhYmxlIHx8IG11dGF0aW9uLmlzUGVuZGluZykgcmV0dXJuO1xuICAgIG11dGF0aW9uLm11dGF0ZShcbiAgICAgIHsgbmZ0SWQ6IG5mdC5pZCwgZWRpdGlvbklkLCBxdWFudGl0eSB9LFxuICAgICAge1xuICAgICAgICBvblN1Y2Nlc3M6ICgpID0+IHtcbiAgICAgICAgICBpZiAocHVyY2hhc2UpIHZvaWQgbmF2aWdhdGUoeyB0bzogJy9jYXJ0JyB9KTtcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgKTtcbiAgfTtcbiAgY29uc3QgYWN0aW9ucyA9IHtcbiAgICBwZW5kaW5nOiBtdXRhdGlvbi5pc1BlbmRpbmcsXG4gICAgZGlzYWJsZWQ6IGF2YWlsYWJsZSA9PT0gMCxcbiAgICBwdXJjaGFzZTogKCkgPT4ge1xuICAgICAgYWRkKHRydWUpO1xuICAgIH0sXG4gICAgYWRkOiAoKSA9PiB7XG4gICAgICBhZGQoKTtcbiAgICB9LFxuICB9O1xuICByZXR1cm4geyBlZGl0aW9uSWQsIHNldEVkaXRpb25JZCwgcXVhbnRpdHksIHNldFF1YW50aXR5LCBhdmFpbGFibGUsIGFjdGlvbnMgfTtcbn1cbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxnQkFBZ0I7QUFHekIsU0FBUyxvQkFBb0I7QUFDdEIsZ0JBQVMscUJBQXFCLEtBQVU7QUFDN0MsUUFBTSxDQUFDLFdBQVcsWUFBWSxJQUFJO0FBQUEsSUFDaEMsSUFBSSxTQUFTLEtBQUssQ0FBQ0EsYUFBWUEsU0FBUSxZQUFZLENBQUMsR0FBRyxNQUFNO0FBQUEsRUFDL0Q7QUFDQSxRQUFNLENBQUMsbUJBQW1CLFdBQVcsSUFBSSxTQUFTLENBQUM7QUFDbkQsUUFBTSxXQUFXLGFBQWE7QUFDOUIsUUFBTSxXQUFXLFlBQVk7QUFDN0IsUUFBTSxVQUFVLElBQUksU0FBUyxLQUFLLENBQUMsVUFBVSxNQUFNLE9BQU8sU0FBUztBQUNuRSxRQUFNLFlBQVksU0FBUyxhQUFhO0FBQ3hDLFFBQU0sV0FBVyxLQUFLLElBQUksbUJBQW1CLEtBQUssSUFBSSxXQUFXLENBQUMsQ0FBQztBQUNuRSxRQUFNLE1BQU0sQ0FBQyxXQUFXLFVBQVU7QUFDaEMsUUFBSSxDQUFDLGFBQWEsU0FBUyxVQUFXO0FBQ3RDLGFBQVM7QUFBQSxNQUNQLEVBQUUsT0FBTyxJQUFJLElBQUksV0FBVyxTQUFTO0FBQUEsTUFDckM7QUFBQSxRQUNFLFdBQVcsTUFBTTtBQUNmLGNBQUksU0FBVSxNQUFLLFNBQVMsRUFBRSxJQUFJLFFBQVEsQ0FBQztBQUFBLFFBQzdDO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsUUFBTSxVQUFVO0FBQUEsSUFDZCxTQUFTLFNBQVM7QUFBQSxJQUNsQixVQUFVLGNBQWM7QUFBQSxJQUN4QixVQUFVLE1BQU07QUFDZCxVQUFJLElBQUk7QUFBQSxJQUNWO0FBQUEsSUFDQSxLQUFLLE1BQU07QUFDVCxVQUFJO0FBQUEsSUFDTjtBQUFBLEVBQ0Y7QUFDQSxTQUFPLEVBQUUsV0FBVyxjQUFjLFVBQVUsYUFBYSxXQUFXLFFBQVE7QUFDOUU7IiwibmFtZXMiOlsiZWRpdGlvbiJdfQ==