import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/ShareNftAction.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { Copy } from "/node_modules/.vite/deps/lucide-react.js?v=970a124b";
import { FigmaIcon } from "/src/components/icons/FigmaIcon.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { useShareDestinations } from "/src/features/nft-detail/useShareDestinations.ts";
import { useShareLink } from "/src/features/nft-detail/useShareLink.ts";
export function ShareNftAction() {
  _s();
  const share = useShareLink();
  const links = useShareDestinations();
  return /* @__PURE__ */ jsxDEV("div", { className: "hidden flex-wrap items-center gap-1 text-body-sm md:flex lg:mt-auto", children: [
    /* @__PURE__ */ jsxDEV("span", { className: "mr-2 font-bold", children: "Compartilhar este NFT:" }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ShareNftAction.tsx",
      lineNumber: 13,
      columnNumber: 7
    }, this),
    links.map(
      ({ icon, label, href }) => /* @__PURE__ */ jsxDEV(Button, { asChild: true, variant: "ghost", size: "icon-sm", children: /* @__PURE__ */ jsxDEV("a", { href, target: "_blank", rel: "noopener noreferrer", "aria-label": label, children: /* @__PURE__ */ jsxDEV(FigmaIcon, { name: icon, size: 15 }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ShareNftAction.tsx",
        lineNumber: 17,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ShareNftAction.tsx",
        lineNumber: 16,
        columnNumber: 11
      }, this) }, icon, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ShareNftAction.tsx",
        lineNumber: 15,
        columnNumber: 7
      }, this)
    ),
    /* @__PURE__ */ jsxDEV(
      Button,
      {
        variant: "ghost",
        size: "icon-sm",
        "aria-label": "Compartilhar NFT",
        onClick: () => {
          share.mutate();
        },
        children: /* @__PURE__ */ jsxDEV(Copy, { "aria-hidden": "true" }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ShareNftAction.tsx",
          lineNumber: 29,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ShareNftAction.tsx",
        lineNumber: 21,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ShareNftAction.tsx",
    lineNumber: 12,
    columnNumber: 5
  }, this);
}
_s(ShareNftAction, "Uxj8V1mdsVvetc2d71/41HlzJME=", false, function() {
  return [useShareLink, useShareDestinations];
});
_c = ShareNftAction;
var _c;
$RefreshReg$(_c, "ShareNftAction");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ShareNftAction.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ShareNftAction.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ShareNftAction.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWU07O0FBWk4sU0FBU0EsWUFBWTtBQUVyQixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyw0QkFBNEI7QUFDckMsU0FBU0Msb0JBQW9CO0FBRXRCLGdCQUFTQyxpQkFBaUI7QUFBQUMsS0FBQTtBQUMvQixRQUFNQyxRQUFRSCxhQUFhO0FBQzNCLFFBQU1JLFFBQVFMLHFCQUFxQjtBQUNuQyxTQUNFLHVCQUFDLFNBQUksV0FBVSx1RUFDYjtBQUFBLDJCQUFDLFVBQUssV0FBVSxrQkFBaUIsc0NBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUQ7QUFBQSxJQUN0REssTUFBTUM7QUFBQUEsTUFBSSxDQUFDLEVBQUVDLE1BQU1DLE9BQU9DLEtBQUssTUFDOUIsdUJBQUMsVUFBa0IsU0FBTyxNQUFDLFNBQVEsU0FBUSxNQUFLLFdBQzlDLGlDQUFDLE9BQUUsTUFBWSxRQUFPLFVBQVMsS0FBSSx1QkFBc0IsY0FBWUQsT0FDbkUsaUNBQUMsYUFBVSxNQUFNRCxNQUFNLE1BQU0sTUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQyxLQURsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsS0FIV0EsTUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxJQUNEO0FBQUEsSUFDRDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsU0FBUTtBQUFBLFFBQ1IsTUFBSztBQUFBLFFBQ0wsY0FBVztBQUFBLFFBQ1gsU0FBUyxNQUFNO0FBQ2JILGdCQUFNTSxPQUFPO0FBQUEsUUFDZjtBQUFBLFFBRUEsaUNBQUMsUUFBSyxlQUFZLFVBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0I7QUFBQTtBQUFBLE1BUjFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVNBO0FBQUEsT0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1CQTtBQUVKO0FBQUNQLEdBekJlRCxnQkFBYztBQUFBLFVBQ2RELGNBQ0FELG9CQUFvQjtBQUFBO0FBQUEsS0FGcEJFO0FBQWMsSUFBQVM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiQ29weSIsIkZpZ21hSWNvbiIsIkJ1dHRvbiIsInVzZVNoYXJlRGVzdGluYXRpb25zIiwidXNlU2hhcmVMaW5rIiwiU2hhcmVOZnRBY3Rpb24iLCJfcyIsInNoYXJlIiwibGlua3MiLCJtYXAiLCJpY29uIiwibGFiZWwiLCJocmVmIiwibXV0YXRlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU2hhcmVOZnRBY3Rpb24udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvcHkgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5pbXBvcnQgeyBGaWdtYUljb24gfSBmcm9tICdAL2NvbXBvbmVudHMvaWNvbnMvRmlnbWFJY29uJztcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nO1xuaW1wb3J0IHsgdXNlU2hhcmVEZXN0aW5hdGlvbnMgfSBmcm9tICdAL2ZlYXR1cmVzL25mdC1kZXRhaWwvdXNlU2hhcmVEZXN0aW5hdGlvbnMnO1xuaW1wb3J0IHsgdXNlU2hhcmVMaW5rIH0gZnJvbSAnQC9mZWF0dXJlcy9uZnQtZGV0YWlsL3VzZVNoYXJlTGluayc7XG5cbmV4cG9ydCBmdW5jdGlvbiBTaGFyZU5mdEFjdGlvbigpIHtcbiAgY29uc3Qgc2hhcmUgPSB1c2VTaGFyZUxpbmsoKTtcbiAgY29uc3QgbGlua3MgPSB1c2VTaGFyZURlc3RpbmF0aW9ucygpO1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC1ib2R5LXNtIG1kOmZsZXggbGc6bXQtYXV0b1wiPlxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibXItMiBmb250LWJvbGRcIj5Db21wYXJ0aWxoYXIgZXN0ZSBORlQ6PC9zcGFuPlxuICAgICAge2xpbmtzLm1hcCgoeyBpY29uLCBsYWJlbCwgaHJlZiB9KSA9PiAoXG4gICAgICAgIDxCdXR0b24ga2V5PXtpY29ufSBhc0NoaWxkIHZhcmlhbnQ9XCJnaG9zdFwiIHNpemU9XCJpY29uLXNtXCI+XG4gICAgICAgICAgPGEgaHJlZj17aHJlZn0gdGFyZ2V0PVwiX2JsYW5rXCIgcmVsPVwibm9vcGVuZXIgbm9yZWZlcnJlclwiIGFyaWEtbGFiZWw9e2xhYmVsfT5cbiAgICAgICAgICAgIDxGaWdtYUljb24gbmFtZT17aWNvbn0gc2l6ZT17MTV9IC8+XG4gICAgICAgICAgPC9hPlxuICAgICAgICA8L0J1dHRvbj5cbiAgICAgICkpfVxuICAgICAgPEJ1dHRvblxuICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxuICAgICAgICBzaXplPVwiaWNvbi1zbVwiXG4gICAgICAgIGFyaWEtbGFiZWw9XCJDb21wYXJ0aWxoYXIgTkZUXCJcbiAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgIHNoYXJlLm11dGF0ZSgpO1xuICAgICAgICB9fVxuICAgICAgPlxuICAgICAgICA8Q29weSBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgPC9CdXR0b24+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9maWxpcGVjYXZhbGNhbnRlL0RvY3VtZW50cy9KdW5nbGVHYW1pbmdUZXN0ZS9zcmMvZmVhdHVyZXMvbmZ0LWRldGFpbC9jb21wb25lbnRzL1NoYXJlTmZ0QWN0aW9uLnRzeCJ9