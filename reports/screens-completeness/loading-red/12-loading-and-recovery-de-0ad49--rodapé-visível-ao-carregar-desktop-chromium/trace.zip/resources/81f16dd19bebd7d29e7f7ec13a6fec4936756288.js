import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/nfts.$nftId.tsx?tsr-split=component");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=970a124b";
import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=970a124b";
import { DetailSkeleton } from "/src/components/feedback/DetailSkeleton.tsx";
import { EmptyState } from "/src/components/feedback/EmptyState.tsx";
import { ErrorState } from "/src/components/feedback/ErrorState.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { nftDetailQueryOptions } from "/src/features/catalog/queries.ts";
import { NftDetailPage } from "/src/features/nft-detail/components/NftDetailPage.tsx";
import { ApiError } from "/src/lib/errors.ts";
import { Route } from "/src/routes/nfts.$nftId.tsx";
function Detail() {
  _s();
  const {
    nftId
  } = Route.useParams();
  const query = useQuery(nftDetailQueryOptions(nftId));
  if (query.isPending) return /* @__PURE__ */ jsxDEV(DetailSkeleton, {}, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/routes/nfts.$nftId.tsx?tsr-split=component",
    lineNumber: 16,
    columnNumber: 31
  }, this);
  if (query.error instanceof ApiError && query.error.status === 404) return /* @__PURE__ */ jsxDEV(EmptyState, { title: "NFT não encontrado", description: "Esta peça não faz parte do catálogo disponível.", action: /* @__PURE__ */ jsxDEV(Button, { asChild: true, children: /* @__PURE__ */ jsxDEV(Link, { to: "/", children: "Voltar para Início" }, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/routes/nfts.$nftId.tsx?tsr-split=component",
    lineNumber: 18,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/routes/nfts.$nftId.tsx?tsr-split=component",
    lineNumber: 17,
    columnNumber: 186
  }, this) }, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/routes/nfts.$nftId.tsx?tsr-split=component",
    lineNumber: 17,
    columnNumber: 77
  }, this);
  if (query.isError) return /* @__PURE__ */ jsxDEV(ErrorState, { error: query.error, retry: () => {
    void query.refetch();
  } }, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/routes/nfts.$nftId.tsx?tsr-split=component",
    lineNumber: 20,
    columnNumber: 29
  }, this);
  return /* @__PURE__ */ jsxDEV(NftDetailPage, { nft: query.data }, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/routes/nfts.$nftId.tsx?tsr-split=component",
    lineNumber: 23,
    columnNumber: 10
  }, this);
}
_s(Detail, "79f3f7UxQgR5P3WQxPTbNCovDnA=", false, function() {
  return [Route.useParams, useQuery];
});
_c = Detail;
export { Detail as component };
var _c;
$RefreshReg$(_c, "Detail");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/routes/nfts.$nftId.tsx?tsr-split=component", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/routes/nfts.$nftId.tsx?tsr-split=component", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/routes/nfts.$nftId.tsx?tsr-split=component " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0M4Qjs7QUFsQzlCLFNBQVNBLGdCQUFnQjtBQUN6QixTQUVFQyxZQUdLO0FBR1AsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsY0FBYztBQUN2QixTQUFTQyw2QkFBNkI7QUFDdEMsU0FBU0MscUJBQXFCO0FBRTlCLFNBQVNDLGdCQUE4QjtBQUFlLFNBQUFDLGFBQUE7QUFldEQsU0FBU0MsU0FBUztBQUFBQyxLQUFBO0FBQ2hCLFFBQU07QUFBQSxJQUFFQztBQUFBQSxFQUFNLElBQUlILE1BQU1JLFVBQVU7QUFDbEMsUUFBTUMsUUFBUWQsU0FBU00sc0JBQXNCTSxLQUFLLENBQUM7QUFDbkQsTUFBSUUsTUFBTUMsVUFBVyxRQUFPLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZTtBQUMzQyxNQUFJRCxNQUFNRSxpQkFBaUJSLFlBQVlNLE1BQU1FLE1BQU1DLFdBQVcsSUFDNUQsUUFDRSx1QkFBQyxjQUNDLE9BQU0sc0JBQ04sYUFBWSxtREFDWixRQUNFLHVCQUFDLFVBQU8sU0FBTyxNQUNiLGlDQUFDLFFBQUssSUFBRyxLQUFJLGtDQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBK0IsS0FEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBLEtBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU9HO0FBR1AsTUFBSUgsTUFBTUksUUFDUixRQUNFLHVCQUFDLGNBQ0MsT0FBT0osTUFBTUUsT0FDYixPQUFPLE1BQU07QUFDWCxTQUFLRixNQUFNSyxRQUFRO0FBQUEsRUFDckIsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBSUk7QUFHUixTQUFPLHVCQUFDLGlCQUFjLEtBQUtMLE1BQU1NLFFBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBK0I7QUFDeEM7QUFBQVQsR0ExQlNELFFBQU1BO0FBQUFBLFVBQ0tELE1BQU1JLFdBQ1ZiLFFBQVE7QUFBQTtBQUFBLEtBRmZVO0FBMEJSLFNBQUFBLFVBQUFXO0FBQUEsSUFBQUM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlUXVlcnkiLCJMaW5rIiwiRGV0YWlsU2tlbGV0b24iLCJFbXB0eVN0YXRlIiwiRXJyb3JTdGF0ZSIsIkJ1dHRvbiIsIm5mdERldGFpbFF1ZXJ5T3B0aW9ucyIsIk5mdERldGFpbFBhZ2UiLCJBcGlFcnJvciIsIlJvdXRlIiwiRGV0YWlsIiwiX3MiLCJuZnRJZCIsInVzZVBhcmFtcyIsInF1ZXJ5IiwiaXNQZW5kaW5nIiwiZXJyb3IiLCJzdGF0dXMiLCJpc0Vycm9yIiwicmVmZXRjaCIsImRhdGEiLCJjb21wb25lbnQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJuZnRzLiRuZnRJZC50c3g/dHNyLXNwbGl0PWNvbXBvbmVudCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSc7XG5pbXBvcnQge1xuICBjcmVhdGVGaWxlUm91dGUsXG4gIExpbmssXG4gIHN0cmlwU2VhcmNoUGFyYW1zLFxuICB0eXBlIFNlYXJjaFNjaGVtYUlucHV0LFxufSBmcm9tICdAdGFuc3RhY2svcmVhY3Qtcm91dGVyJztcblxuaW1wb3J0IHsgYW5ub3VuY2UgfSBmcm9tICdAL2NvbXBvbmVudHMvZmVlZGJhY2svYW5ub3VuY2UnO1xuaW1wb3J0IHsgRGV0YWlsU2tlbGV0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvZmVlZGJhY2svRGV0YWlsU2tlbGV0b24nO1xuaW1wb3J0IHsgRW1wdHlTdGF0ZSB9IGZyb20gJ0AvY29tcG9uZW50cy9mZWVkYmFjay9FbXB0eVN0YXRlJztcbmltcG9ydCB7IEVycm9yU3RhdGUgfSBmcm9tICdAL2NvbXBvbmVudHMvZmVlZGJhY2svRXJyb3JTdGF0ZSc7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJztcbmltcG9ydCB7IG5mdERldGFpbFF1ZXJ5T3B0aW9ucyB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy9xdWVyaWVzJztcbmltcG9ydCB7IE5mdERldGFpbFBhZ2UgfSBmcm9tICdAL2ZlYXR1cmVzL25mdC1kZXRhaWwvY29tcG9uZW50cy9OZnREZXRhaWxQYWdlJztcbmltcG9ydCB7IGRldGFpbFNlYXJjaFNjaGVtYSB9IGZyb20gJ0AvZmVhdHVyZXMvbmZ0LWRldGFpbC9zZWFyY2gtcGFyYW1zJztcbmltcG9ydCB7IEFwaUVycm9yLCBlcnJvck1lc3NhZ2UgfSBmcm9tICdAL2xpYi9lcnJvcnMnO1xuXG5leHBvcnQgY29uc3QgUm91dGUgPSBjcmVhdGVGaWxlUm91dGUoJy9uZnRzLyRuZnRJZCcpKHtcbiAgdmFsaWRhdGVTZWFyY2g6IChpbnB1dDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gJiBTZWFyY2hTY2hlbWFJbnB1dCkgPT5cbiAgICBkZXRhaWxTZWFyY2hTY2hlbWEucGFyc2UoaW5wdXQpLFxuICBzZWFyY2g6IHsgbWlkZGxld2FyZXM6IFtzdHJpcFNlYXJjaFBhcmFtcyh7IHRhYjogJ2RldGFpbHMnLCByZXZpZXdQYWdlOiAxIH0pXSB9LFxuICBsb2FkZXI6ICh7IGNvbnRleHQsIHBhcmFtcyB9KSA9PiB7XG4gICAgdm9pZCBjb250ZXh0LnF1ZXJ5Q2xpZW50LnF1ZXJ5KG5mdERldGFpbFF1ZXJ5T3B0aW9ucyhwYXJhbXMubmZ0SWQpKS5jYXRjaCgoZXJyb3I6IHVua25vd24pID0+IHtcbiAgICAgIGFubm91bmNlKGVycm9yTWVzc2FnZShlcnJvcikpO1xuICAgIH0pO1xuICB9LFxuICBwZW5kaW5nQ29tcG9uZW50OiBEZXRhaWxTa2VsZXRvbixcbiAgZXJyb3JDb21wb25lbnQ6ICh7IGVycm9yLCByZXNldCB9KSA9PiA8RXJyb3JTdGF0ZSBlcnJvcj17ZXJyb3J9IHJldHJ5PXtyZXNldH0gLz4sXG4gIGNvbXBvbmVudDogRGV0YWlsLFxufSk7XG5mdW5jdGlvbiBEZXRhaWwoKSB7XG4gIGNvbnN0IHsgbmZ0SWQgfSA9IFJvdXRlLnVzZVBhcmFtcygpO1xuICBjb25zdCBxdWVyeSA9IHVzZVF1ZXJ5KG5mdERldGFpbFF1ZXJ5T3B0aW9ucyhuZnRJZCkpO1xuICBpZiAocXVlcnkuaXNQZW5kaW5nKSByZXR1cm4gPERldGFpbFNrZWxldG9uIC8+O1xuICBpZiAocXVlcnkuZXJyb3IgaW5zdGFuY2VvZiBBcGlFcnJvciAmJiBxdWVyeS5lcnJvci5zdGF0dXMgPT09IDQwNClcbiAgICByZXR1cm4gKFxuICAgICAgPEVtcHR5U3RhdGVcbiAgICAgICAgdGl0bGU9XCJORlQgbsOjbyBlbmNvbnRyYWRvXCJcbiAgICAgICAgZGVzY3JpcHRpb249XCJFc3RhIHBlw6dhIG7Do28gZmF6IHBhcnRlIGRvIGNhdMOhbG9nbyBkaXNwb27DrXZlbC5cIlxuICAgICAgICBhY3Rpb249e1xuICAgICAgICAgIDxCdXR0b24gYXNDaGlsZD5cbiAgICAgICAgICAgIDxMaW5rIHRvPVwiL1wiPlZvbHRhciBwYXJhIEluw61jaW88L0xpbms+XG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgIH1cbiAgICAgIC8+XG4gICAgKTtcbiAgaWYgKHF1ZXJ5LmlzRXJyb3IpXG4gICAgcmV0dXJuIChcbiAgICAgIDxFcnJvclN0YXRlXG4gICAgICAgIGVycm9yPXtxdWVyeS5lcnJvcn1cbiAgICAgICAgcmV0cnk9eygpID0+IHtcbiAgICAgICAgICB2b2lkIHF1ZXJ5LnJlZmV0Y2goKTtcbiAgICAgICAgfX1cbiAgICAgIC8+XG4gICAgKTtcbiAgcmV0dXJuIDxOZnREZXRhaWxQYWdlIG5mdD17cXVlcnkuZGF0YX0gLz47XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9maWxpcGVjYXZhbGNhbnRlL0RvY3VtZW50cy9KdW5nbGVHYW1pbmdUZXN0ZS9zcmMvcm91dGVzL25mdHMuJG5mdElkLnRzeCJ9