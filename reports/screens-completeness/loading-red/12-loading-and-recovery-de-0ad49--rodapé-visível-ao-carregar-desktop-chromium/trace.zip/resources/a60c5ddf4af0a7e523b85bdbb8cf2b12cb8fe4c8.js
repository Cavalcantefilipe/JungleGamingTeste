import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/RelatedSkeleton.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Skeleton } from "/src/components/ui/skeleton.tsx";
import { detailMessages } from "/src/features/nft-detail/messages.ts";
export function RelatedSkeleton() {
  return /* @__PURE__ */ jsxDEV("section", { role: "status", "aria-label": "Carregando coleção", className: "space-y-6", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "text-section font-bold text-text-accent", children: detailMessages.related }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/RelatedSkeleton.tsx",
      lineNumber: 8,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-5 md:grid-cols-3 xl:grid-cols-5", children: Array.from(
      { length: 5 },
      (_, index) => /* @__PURE__ */ jsxDEV(
        Skeleton,
        {
          className: `aspect-[220/310] ${index > 2 ? "hidden xl:block" : index > 1 ? "hidden md:block" : ""}`
        },
        index,
        false,
        {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/RelatedSkeleton.tsx",
          lineNumber: 11,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/RelatedSkeleton.tsx",
      lineNumber: 9,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/RelatedSkeleton.tsx",
    lineNumber: 7,
    columnNumber: 5
  }, this);
}
_c = RelatedSkeleton;
var _c;
$RefreshReg$(_c, "RelatedSkeleton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/RelatedSkeleton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/RelatedSkeleton.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/RelatedSkeleton.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT007QUFQTixTQUFTQSxnQkFBZ0I7QUFFekIsU0FBU0Msc0JBQXNCO0FBRXhCLGdCQUFTQyxrQkFBa0I7QUFDaEMsU0FDRSx1QkFBQyxhQUFRLE1BQUssVUFBUyxjQUFXLHNCQUFxQixXQUFVLGFBQy9EO0FBQUEsMkJBQUMsUUFBRyxXQUFVLDJDQUEyQ0QseUJBQWVFLFdBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0Y7QUFBQSxJQUNoRix1QkFBQyxTQUFJLFdBQVUsd0RBQ1pDLGdCQUFNQztBQUFBQSxNQUFLLEVBQUVDLFFBQVEsRUFBRTtBQUFBLE1BQUcsQ0FBQ0MsR0FBR0MsVUFDN0I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVDLFdBQVcsb0JBQW9CQSxRQUFRLElBQUksb0JBQW9CQSxRQUFRLElBQUksb0JBQW9CLEVBQUU7QUFBQTtBQUFBLFFBRDVGQTtBQUFBQSxRQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFFc0c7QUFBQSxJQUV2RyxLQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLE9BVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVVBO0FBRUo7QUFBQ0MsS0FkZVA7QUFBZSxJQUFBTztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJTa2VsZXRvbiIsImRldGFpbE1lc3NhZ2VzIiwiUmVsYXRlZFNrZWxldG9uIiwicmVsYXRlZCIsIkFycmF5IiwiZnJvbSIsImxlbmd0aCIsIl8iLCJpbmRleCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlJlbGF0ZWRTa2VsZXRvbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU2tlbGV0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvc2tlbGV0b24nO1xuXG5pbXBvcnQgeyBkZXRhaWxNZXNzYWdlcyB9IGZyb20gJy4uL21lc3NhZ2VzJztcblxuZXhwb3J0IGZ1bmN0aW9uIFJlbGF0ZWRTa2VsZXRvbigpIHtcbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiByb2xlPVwic3RhdHVzXCIgYXJpYS1sYWJlbD1cIkNhcnJlZ2FuZG8gY29sZcOnw6NvXCIgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1zZWN0aW9uIGZvbnQtYm9sZCB0ZXh0LXRleHQtYWNjZW50XCI+e2RldGFpbE1lc3NhZ2VzLnJlbGF0ZWR9PC9oMj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtNSBtZDpncmlkLWNvbHMtMyB4bDpncmlkLWNvbHMtNVwiPlxuICAgICAgICB7QXJyYXkuZnJvbSh7IGxlbmd0aDogNSB9LCAoXywgaW5kZXgpID0+IChcbiAgICAgICAgICA8U2tlbGV0b25cbiAgICAgICAgICAgIGtleT17aW5kZXh9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2Bhc3BlY3QtWzIyMC8zMTBdICR7aW5kZXggPiAyID8gJ2hpZGRlbiB4bDpibG9jaycgOiBpbmRleCA+IDEgPyAnaGlkZGVuIG1kOmJsb2NrJyA6ICcnfWB9XG4gICAgICAgICAgLz5cbiAgICAgICAgKSl9XG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9maWxpcGVjYXZhbGNhbnRlL0RvY3VtZW50cy9KdW5nbGVHYW1pbmdUZXN0ZS9zcmMvZmVhdHVyZXMvbmZ0LWRldGFpbC9jb21wb25lbnRzL1JlbGF0ZWRTa2VsZXRvbi50c3gifQ==