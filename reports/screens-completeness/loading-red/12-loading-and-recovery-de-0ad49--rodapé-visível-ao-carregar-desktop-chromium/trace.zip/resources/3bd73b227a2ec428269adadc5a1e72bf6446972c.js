import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=970a124b"; const useEffect = __vite__cjsImport0_react["useEffect"]; const useEffectEvent = __vite__cjsImport0_react["useEffectEvent"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];
export function useCarouselAutoplay({ page, pages, goTo }) {
  const container = useRef(null);
  const [playing, setPlaying] = useState(true);
  const advance = useEffectEvent(() => {
    const element = container.current;
    const focused = document.activeElement;
    if (!element || document.hidden || matchMedia("(prefers-reduced-motion: reduce)").matches)
      return;
    if (element.matches(":hover")) return;
    if (element.contains(focused) && !focused?.hasAttribute("data-carousel-playback")) return;
    goTo((page + 1) % pages);
  });
  useEffect(() => {
    const element = container.current;
    if (!element || !playing || pages < 2) return;
    let visible = false;
    const observer = new IntersectionObserver(
      ([entry]) => {
        visible = entry?.isIntersecting ?? false;
      },
      { threshold: 0.25 }
    );
    observer.observe(element);
    const timer = window.setInterval(() => {
      if (visible) advance();
    }, 5e3);
    return () => {
      observer.disconnect();
      window.clearInterval(timer);
    };
  }, [playing, pages]);
  return {
    container,
    playing,
    toggle: () => {
      setPlaying((value) => !value);
    }
  };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZUNhcm91c2VsQXV0b3BsYXkudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VFZmZlY3RFdmVudCwgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcblxuaW1wb3J0IHR5cGUgeyBDYXJvdXNlbE5hdmlnYXRpb25TdGF0ZSB9IGZyb20gJy4vdXNlQ2Fyb3VzZWwnO1xuXG5leHBvcnQgZnVuY3Rpb24gdXNlQ2Fyb3VzZWxBdXRvcGxheSh7IHBhZ2UsIHBhZ2VzLCBnb1RvIH06IENhcm91c2VsTmF2aWdhdGlvblN0YXRlKSB7XG4gIGNvbnN0IGNvbnRhaW5lciA9IHVzZVJlZjxIVE1MRWxlbWVudD4obnVsbCk7XG4gIGNvbnN0IFtwbGF5aW5nLCBzZXRQbGF5aW5nXSA9IHVzZVN0YXRlKHRydWUpO1xuICBjb25zdCBhZHZhbmNlID0gdXNlRWZmZWN0RXZlbnQoKCkgPT4ge1xuICAgIGNvbnN0IGVsZW1lbnQgPSBjb250YWluZXIuY3VycmVudDtcbiAgICBjb25zdCBmb2N1c2VkID0gZG9jdW1lbnQuYWN0aXZlRWxlbWVudDtcbiAgICBpZiAoIWVsZW1lbnQgfHwgZG9jdW1lbnQuaGlkZGVuIHx8IG1hdGNoTWVkaWEoJyhwcmVmZXJzLXJlZHVjZWQtbW90aW9uOiByZWR1Y2UpJykubWF0Y2hlcylcbiAgICAgIHJldHVybjtcbiAgICBpZiAoZWxlbWVudC5tYXRjaGVzKCc6aG92ZXInKSkgcmV0dXJuO1xuICAgIGlmIChlbGVtZW50LmNvbnRhaW5zKGZvY3VzZWQpICYmICFmb2N1c2VkPy5oYXNBdHRyaWJ1dGUoJ2RhdGEtY2Fyb3VzZWwtcGxheWJhY2snKSkgcmV0dXJuO1xuICAgIGdvVG8oKHBhZ2UgKyAxKSAlIHBhZ2VzKTtcbiAgfSk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgZWxlbWVudCA9IGNvbnRhaW5lci5jdXJyZW50O1xuICAgIGlmICghZWxlbWVudCB8fCAhcGxheWluZyB8fCBwYWdlcyA8IDIpIHJldHVybjtcbiAgICBsZXQgdmlzaWJsZSA9IGZhbHNlO1xuICAgIGNvbnN0IG9ic2VydmVyID0gbmV3IEludGVyc2VjdGlvbk9ic2VydmVyKFxuICAgICAgKFtlbnRyeV0pID0+IHtcbiAgICAgICAgdmlzaWJsZSA9IGVudHJ5Py5pc0ludGVyc2VjdGluZyA/PyBmYWxzZTtcbiAgICAgIH0sXG4gICAgICB7IHRocmVzaG9sZDogMC4yNSB9LFxuICAgICk7XG4gICAgb2JzZXJ2ZXIub2JzZXJ2ZShlbGVtZW50KTtcbiAgICBjb25zdCB0aW1lciA9IHdpbmRvdy5zZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgICBpZiAodmlzaWJsZSkgYWR2YW5jZSgpO1xuICAgIH0sIDUwMDApO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBvYnNlcnZlci5kaXNjb25uZWN0KCk7XG4gICAgICB3aW5kb3cuY2xlYXJJbnRlcnZhbCh0aW1lcik7XG4gICAgfTtcbiAgfSwgW3BsYXlpbmcsIHBhZ2VzXSk7XG4gIHJldHVybiB7XG4gICAgY29udGFpbmVyLFxuICAgIHBsYXlpbmcsXG4gICAgdG9nZ2xlOiAoKSA9PiB7XG4gICAgICBzZXRQbGF5aW5nKCh2YWx1ZSkgPT4gIXZhbHVlKTtcbiAgICB9LFxuICB9O1xufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLFdBQVcsZ0JBQWdCLFFBQVEsZ0JBQWdCO0FBSXJELGdCQUFTLG9CQUFvQixFQUFFLE1BQU0sT0FBTyxLQUFLLEdBQTRCO0FBQ2xGLFFBQU0sWUFBWSxPQUFvQixJQUFJO0FBQzFDLFFBQU0sQ0FBQyxTQUFTLFVBQVUsSUFBSSxTQUFTLElBQUk7QUFDM0MsUUFBTSxVQUFVLGVBQWUsTUFBTTtBQUNuQyxVQUFNLFVBQVUsVUFBVTtBQUMxQixVQUFNLFVBQVUsU0FBUztBQUN6QixRQUFJLENBQUMsV0FBVyxTQUFTLFVBQVUsV0FBVyxrQ0FBa0MsRUFBRTtBQUNoRjtBQUNGLFFBQUksUUFBUSxRQUFRLFFBQVEsRUFBRztBQUMvQixRQUFJLFFBQVEsU0FBUyxPQUFPLEtBQUssQ0FBQyxTQUFTLGFBQWEsd0JBQXdCLEVBQUc7QUFDbkYsVUFBTSxPQUFPLEtBQUssS0FBSztBQUFBLEVBQ3pCLENBQUM7QUFDRCxZQUFVLE1BQU07QUFDZCxVQUFNLFVBQVUsVUFBVTtBQUMxQixRQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsUUFBUSxFQUFHO0FBQ3ZDLFFBQUksVUFBVTtBQUNkLFVBQU0sV0FBVyxJQUFJO0FBQUEsTUFDbkIsQ0FBQyxDQUFDLEtBQUssTUFBTTtBQUNYLGtCQUFVLE9BQU8sa0JBQWtCO0FBQUEsTUFDckM7QUFBQSxNQUNBLEVBQUUsV0FBVyxLQUFLO0FBQUEsSUFDcEI7QUFDQSxhQUFTLFFBQVEsT0FBTztBQUN4QixVQUFNLFFBQVEsT0FBTyxZQUFZLE1BQU07QUFDckMsVUFBSSxRQUFTLFNBQVE7QUFBQSxJQUN2QixHQUFHLEdBQUk7QUFDUCxXQUFPLE1BQU07QUFDWCxlQUFTLFdBQVc7QUFDcEIsYUFBTyxjQUFjLEtBQUs7QUFBQSxJQUM1QjtBQUFBLEVBQ0YsR0FBRyxDQUFDLFNBQVMsS0FBSyxDQUFDO0FBQ25CLFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQTtBQUFBLElBQ0EsUUFBUSxNQUFNO0FBQ1osaUJBQVcsQ0FBQyxVQUFVLENBQUMsS0FBSztBQUFBLElBQzlCO0FBQUEsRUFDRjtBQUNGOyIsIm5hbWVzIjpbXX0=