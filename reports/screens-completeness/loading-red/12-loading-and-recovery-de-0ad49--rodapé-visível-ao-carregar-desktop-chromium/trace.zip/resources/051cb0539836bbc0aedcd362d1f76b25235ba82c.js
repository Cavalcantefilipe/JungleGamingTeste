import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/QuantityButton.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Button } from "/src/components/ui/button.tsx";
export function QuantityButton({ decrease = false, tone, disabled, change }) {
  return /* @__PURE__ */ jsxDEV(
    Button,
    {
      variant: tone === "cart" ? "quantity-cart" : "quantity",
      size: tone === "cart" ? "quantity" : "quantity-purchase",
      "aria-label": decrease ? "Diminuir quantidade" : "Aumentar quantidade",
      disabled,
      onClick: change,
      children: /* @__PURE__ */ jsxDEV("span", { "aria-hidden": "true", className: "relative text-[21px] leading-4", children: decrease ? "−" : "+" }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/QuantityButton.tsx",
        lineNumber: 18,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/QuantityButton.tsx",
      lineNumber: 11,
      columnNumber: 5
    },
    this
  );
}
_c = QuantityButton;
var _c;
$RefreshReg$(_c, "QuantityButton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/QuantityButton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/QuantityButton.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/QuantityButton.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJNO0FBakJOLFNBQVNBLGNBQWM7QUFRaEIsZ0JBQVNDLGVBQWUsRUFBRUMsV0FBVyxPQUFPQyxNQUFNQyxVQUFVQyxPQUE0QixHQUFHO0FBQ2hHLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFNBQVNGLFNBQVMsU0FBUyxrQkFBa0I7QUFBQSxNQUM3QyxNQUFNQSxTQUFTLFNBQVMsYUFBYTtBQUFBLE1BQ3JDLGNBQVlELFdBQVcsd0JBQXdCO0FBQUEsTUFDL0M7QUFBQSxNQUNBLFNBQVNHO0FBQUFBLE1BRVQsaUNBQUMsVUFBSyxlQUFZLFFBQU8sV0FBVSxrQ0FDaENILHFCQUFXLE1BQU0sT0FEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUE7QUFBQSxJQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVVBO0FBRUo7QUFBQ0ksS0FkZUw7QUFBYyxJQUFBSztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJCdXR0b24iLCJRdWFudGl0eUJ1dHRvbiIsImRlY3JlYXNlIiwidG9uZSIsImRpc2FibGVkIiwiY2hhbmdlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUXVhbnRpdHlCdXR0b24udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nO1xuXG5pbnRlcmZhY2UgUXVhbnRpdHlCdXR0b25Qcm9wcyB7XG4gIGRlY3JlYXNlPzogYm9vbGVhbjtcbiAgdG9uZTogJ3B1cmNoYXNlJyB8ICdjYXJ0JztcbiAgZGlzYWJsZWQ6IGJvb2xlYW47XG4gIGNoYW5nZTogKCkgPT4gdm9pZDtcbn1cbmV4cG9ydCBmdW5jdGlvbiBRdWFudGl0eUJ1dHRvbih7IGRlY3JlYXNlID0gZmFsc2UsIHRvbmUsIGRpc2FibGVkLCBjaGFuZ2UgfTogUXVhbnRpdHlCdXR0b25Qcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxCdXR0b25cbiAgICAgIHZhcmlhbnQ9e3RvbmUgPT09ICdjYXJ0JyA/ICdxdWFudGl0eS1jYXJ0JyA6ICdxdWFudGl0eSd9XG4gICAgICBzaXplPXt0b25lID09PSAnY2FydCcgPyAncXVhbnRpdHknIDogJ3F1YW50aXR5LXB1cmNoYXNlJ31cbiAgICAgIGFyaWEtbGFiZWw9e2RlY3JlYXNlID8gJ0RpbWludWlyIHF1YW50aWRhZGUnIDogJ0F1bWVudGFyIHF1YW50aWRhZGUnfVxuICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxuICAgICAgb25DbGljaz17Y2hhbmdlfVxuICAgID5cbiAgICAgIDxzcGFuIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIGNsYXNzTmFtZT1cInJlbGF0aXZlIHRleHQtWzIxcHhdIGxlYWRpbmctNFwiPlxuICAgICAgICB7ZGVjcmVhc2UgPyAn4oiSJyA6ICcrJ31cbiAgICAgIDwvc3Bhbj5cbiAgICA8L0J1dHRvbj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2ZpbGlwZWNhdmFsY2FudGUvRG9jdW1lbnRzL0p1bmdsZUdhbWluZ1Rlc3RlL3NyYy9mZWF0dXJlcy9uZnQtZGV0YWlsL2NvbXBvbmVudHMvUXVhbnRpdHlCdXR0b24udHN4In0=