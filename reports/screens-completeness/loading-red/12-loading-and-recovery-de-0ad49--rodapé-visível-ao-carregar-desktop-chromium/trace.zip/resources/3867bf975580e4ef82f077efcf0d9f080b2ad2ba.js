import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/CarouselTrack.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { NftCard } from "/src/features/catalog/components/NftCard.tsx";
export function CarouselTrack({
  title,
  items,
  track,
  onScroll
}) {
  return /* @__PURE__ */ jsxDEV(
    "ul",
    {
      ref: track,
      onScroll,
      "aria-label": title,
      className: "relative flex snap-x snap-mandatory scroll-px-2 [scrollbar-width:none] gap-5 overflow-x-auto px-2 py-4",
      children: items.map(
        (nft) => /* @__PURE__ */ jsxDEV(
          "li",
          {
            className: "relative w-[calc((100%-1.25rem)/2)] shrink-0 snap-start transition-transform duration-200 focus-within:z-10 focus-within:scale-[1.04] hover:z-10 hover:scale-[1.04] motion-reduce:transition-none md:w-[calc((100%-2.5rem)/3)] xl:w-[calc((100%-5rem)/5)]",
            children: /* @__PURE__ */ jsxDEV(NftCard, { nft, variant: "carousel" }, void 0, false, {
              fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CarouselTrack.tsx",
              lineNumber: 30,
              columnNumber: 11
            }, this)
          },
          nft.id,
          false,
          {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CarouselTrack.tsx",
            lineNumber: 26,
            columnNumber: 7
          },
          this
        )
      )
    },
    void 0,
    false,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CarouselTrack.tsx",
      lineNumber: 19,
      columnNumber: 5
    },
    this
  );
}
_c = CarouselTrack;
var _c;
$RefreshReg$(_c, "CarouselTrack");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CarouselTrack.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CarouselTrack.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CarouselTrack.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJVO0FBM0JWLFNBQVNBLGVBQWU7QUFJakIsZ0JBQVNDLGNBQWM7QUFBQSxFQUM1QkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFNRixHQUFHO0FBQ0QsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsS0FBS0Q7QUFBQUEsTUFDTDtBQUFBLE1BQ0EsY0FBWUY7QUFBQUEsTUFDWixXQUFVO0FBQUEsTUFFVEMsZ0JBQU1HO0FBQUFBLFFBQUksQ0FBQ0MsUUFDVjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUMsV0FBVTtBQUFBLFlBRVYsaUNBQUMsV0FBUSxLQUFVLFNBQVEsY0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUM7QUFBQTtBQUFBLFVBSGhDQSxJQUFJQztBQUFBQSxVQURYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLE1BQ0Q7QUFBQTtBQUFBLElBYkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBY0E7QUFFSjtBQUFDQyxLQTVCZVI7QUFBYSxJQUFBUTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJOZnRDYXJkIiwiQ2Fyb3VzZWxUcmFjayIsInRpdGxlIiwiaXRlbXMiLCJ0cmFjayIsIm9uU2Nyb2xsIiwibWFwIiwibmZ0IiwiaWQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDYXJvdXNlbFRyYWNrLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IE5mdCB9IGZyb20gJ0AvY29udHJhY3RzL25mdCc7XG5cbmltcG9ydCB7IE5mdENhcmQgfSBmcm9tICcuL05mdENhcmQnO1xuXG5pbXBvcnQgdHlwZSB7IFJlZk9iamVjdCB9IGZyb20gJ3JlYWN0JztcblxuZXhwb3J0IGZ1bmN0aW9uIENhcm91c2VsVHJhY2soe1xuICB0aXRsZSxcbiAgaXRlbXMsXG4gIHRyYWNrLFxuICBvblNjcm9sbCxcbn06IHtcbiAgdGl0bGU6IHN0cmluZztcbiAgaXRlbXM6IE5mdFtdO1xuICB0cmFjazogUmVmT2JqZWN0PEhUTUxVTGlzdEVsZW1lbnQgfCBudWxsPjtcbiAgb25TY3JvbGw6ICgpID0+IHZvaWQ7XG59KSB7XG4gIHJldHVybiAoXG4gICAgPHVsXG4gICAgICByZWY9e3RyYWNrfVxuICAgICAgb25TY3JvbGw9e29uU2Nyb2xsfVxuICAgICAgYXJpYS1sYWJlbD17dGl0bGV9XG4gICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IHNuYXAteCBzbmFwLW1hbmRhdG9yeSBzY3JvbGwtcHgtMiBbc2Nyb2xsYmFyLXdpZHRoOm5vbmVdIGdhcC01IG92ZXJmbG93LXgtYXV0byBweC0yIHB5LTRcIlxuICAgID5cbiAgICAgIHtpdGVtcy5tYXAoKG5mdCkgPT4gKFxuICAgICAgICA8bGlcbiAgICAgICAgICBrZXk9e25mdC5pZH1cbiAgICAgICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LVtjYWxjKCgxMDAlLTEuMjVyZW0pLzIpXSBzaHJpbmstMCBzbmFwLXN0YXJ0IHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTIwMCBmb2N1cy13aXRoaW46ei0xMCBmb2N1cy13aXRoaW46c2NhbGUtWzEuMDRdIGhvdmVyOnotMTAgaG92ZXI6c2NhbGUtWzEuMDRdIG1vdGlvbi1yZWR1Y2U6dHJhbnNpdGlvbi1ub25lIG1kOnctW2NhbGMoKDEwMCUtMi41cmVtKS8zKV0geGw6dy1bY2FsYygoMTAwJS01cmVtKS81KV1cIlxuICAgICAgICA+XG4gICAgICAgICAgPE5mdENhcmQgbmZ0PXtuZnR9IHZhcmlhbnQ9XCJjYXJvdXNlbFwiIC8+XG4gICAgICAgIDwvbGk+XG4gICAgICApKX1cbiAgICA8L3VsPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvZmlsaXBlY2F2YWxjYW50ZS9Eb2N1bWVudHMvSnVuZ2xlR2FtaW5nVGVzdGUvc3JjL2ZlYXR1cmVzL2NhdGFsb2cvY29tcG9uZW50cy9DYXJvdXNlbFRyYWNrLnRzeCJ9