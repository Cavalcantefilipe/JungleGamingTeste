import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/DetailMetadata.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { nftIdentityMessages } from "/src/components/media/messages.ts";
export function DetailMetadata({ nft }) {
  return /* @__PURE__ */ jsxDEV("dl", { className: "space-y-3 text-body-sm leading-5 text-secondary md:pt-1", children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("dt", { className: "inline", children: [
        nftIdentityMessages.tokenId,
        " "
      ] }, void 0, true, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailMetadata.tsx",
        lineNumber: 8,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("dd", { className: "inline", children: [
        "#",
        nft.tokenId.padStart(4, "0")
      ] }, void 0, true, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailMetadata.tsx",
        lineNumber: 9,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailMetadata.tsx",
      lineNumber: 7,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("dt", { className: "inline", children: "Coleção: " }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailMetadata.tsx",
        lineNumber: 12,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("dd", { className: "inline", children: nft.collection }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailMetadata.tsx",
        lineNumber: 13,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailMetadata.tsx",
      lineNumber: 11,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("dt", { className: "inline", children: "Atributos: " }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailMetadata.tsx",
        lineNumber: 16,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("dd", { className: "inline", children: nft.attributes.map((attribute) => attribute.value).join(", ") }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailMetadata.tsx",
        lineNumber: 17,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailMetadata.tsx",
      lineNumber: 15,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailMetadata.tsx",
    lineNumber: 6,
    columnNumber: 5
  }, this);
}
_c = DetailMetadata;
var _c;
$RefreshReg$(_c, "DetailMetadata");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailMetadata.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailMetadata.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailMetadata.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT1E7QUFQUixTQUFTQSwyQkFBMkI7QUFHN0IsZ0JBQVNDLGVBQWUsRUFBRUMsSUFBa0IsR0FBRztBQUNwRCxTQUNFLHVCQUFDLFFBQUcsV0FBVSwyREFDWjtBQUFBLDJCQUFDLFNBQ0M7QUFBQSw2QkFBQyxRQUFHLFdBQVUsVUFBVUY7QUFBQUEsNEJBQW9CRztBQUFBQSxRQUFRO0FBQUEsV0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRDtBQUFBLE1BQ3JELHVCQUFDLFFBQUcsV0FBVSxVQUFTO0FBQUE7QUFBQSxRQUFFRCxJQUFJQyxRQUFRQyxTQUFTLEdBQUcsR0FBRztBQUFBLFdBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0Q7QUFBQSxTQUZ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUNBLHVCQUFDLFNBQ0M7QUFBQSw2QkFBQyxRQUFHLFdBQVUsVUFBUyx5QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQztBQUFBLE1BQ2hDLHVCQUFDLFFBQUcsV0FBVSxVQUFVRixjQUFJRyxjQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVDO0FBQUEsU0FGekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxTQUNDO0FBQUEsNkJBQUMsUUFBRyxXQUFVLFVBQVMsMkJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0M7QUFBQSxNQUNsQyx1QkFBQyxRQUFHLFdBQVUsVUFBVUgsY0FBSUksV0FBV0MsSUFBSSxDQUFDQyxjQUFjQSxVQUFVQyxLQUFLLEVBQUVDLEtBQUssSUFBSSxLQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNGO0FBQUEsU0FGeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsT0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBYUE7QUFFSjtBQUFDQyxLQWpCZVY7QUFBYyxJQUFBVTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJuZnRJZGVudGl0eU1lc3NhZ2VzIiwiRGV0YWlsTWV0YWRhdGEiLCJuZnQiLCJ0b2tlbklkIiwicGFkU3RhcnQiLCJjb2xsZWN0aW9uIiwiYXR0cmlidXRlcyIsIm1hcCIsImF0dHJpYnV0ZSIsInZhbHVlIiwiam9pbiIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkRldGFpbE1ldGFkYXRhLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBuZnRJZGVudGl0eU1lc3NhZ2VzIH0gZnJvbSAnQC9jb21wb25lbnRzL21lZGlhL21lc3NhZ2VzJztcbmltcG9ydCB0eXBlIHsgTmZ0IH0gZnJvbSAnQC9jb250cmFjdHMvbmZ0JztcblxuZXhwb3J0IGZ1bmN0aW9uIERldGFpbE1ldGFkYXRhKHsgbmZ0IH06IHsgbmZ0OiBOZnQgfSkge1xuICByZXR1cm4gKFxuICAgIDxkbCBjbGFzc05hbWU9XCJzcGFjZS15LTMgdGV4dC1ib2R5LXNtIGxlYWRpbmctNSB0ZXh0LXNlY29uZGFyeSBtZDpwdC0xXCI+XG4gICAgICA8ZGl2PlxuICAgICAgICA8ZHQgY2xhc3NOYW1lPVwiaW5saW5lXCI+e25mdElkZW50aXR5TWVzc2FnZXMudG9rZW5JZH0gPC9kdD5cbiAgICAgICAgPGRkIGNsYXNzTmFtZT1cImlubGluZVwiPiN7bmZ0LnRva2VuSWQucGFkU3RhcnQoNCwgJzAnKX08L2RkPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2PlxuICAgICAgICA8ZHQgY2xhc3NOYW1lPVwiaW5saW5lXCI+Q29sZcOnw6NvOiA8L2R0PlxuICAgICAgICA8ZGQgY2xhc3NOYW1lPVwiaW5saW5lXCI+e25mdC5jb2xsZWN0aW9ufTwvZGQ+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXY+XG4gICAgICAgIDxkdCBjbGFzc05hbWU9XCJpbmxpbmVcIj5BdHJpYnV0b3M6IDwvZHQ+XG4gICAgICAgIDxkZCBjbGFzc05hbWU9XCJpbmxpbmVcIj57bmZ0LmF0dHJpYnV0ZXMubWFwKChhdHRyaWJ1dGUpID0+IGF0dHJpYnV0ZS52YWx1ZSkuam9pbignLCAnKX08L2RkPlxuICAgICAgPC9kaXY+XG4gICAgPC9kbD5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2ZpbGlwZWNhdmFsY2FudGUvRG9jdW1lbnRzL0p1bmdsZUdhbWluZ1Rlc3RlL3NyYy9mZWF0dXJlcy9uZnQtZGV0YWlsL2NvbXBvbmVudHMvRGV0YWlsTWV0YWRhdGEudHN4In0=