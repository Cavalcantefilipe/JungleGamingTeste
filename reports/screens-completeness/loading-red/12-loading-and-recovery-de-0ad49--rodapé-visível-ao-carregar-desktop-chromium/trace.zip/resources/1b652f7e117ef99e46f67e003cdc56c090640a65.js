import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/GalleryThumbnails.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { ArtworkImage } from "/src/components/media/ArtworkImage.tsx";
import { cn } from "/src/lib/cn.ts";
export function GalleryThumbnails({
  images,
  selected,
  onSelect
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: "hidden w-[100px] shrink-0 flex-col gap-4 lg:flex", children: images.map(
    (thumbnail, index) => /* @__PURE__ */ jsxDEV(
      "button",
      {
        "aria-label": `Ver imagem ${index + 1}`,
        "aria-pressed": index === selected,
        onClick: () => {
          onSelect(index);
        },
        className: cn(
          "cursor-pointer overflow-hidden rounded-control border-0 outline-2 outline-transparent transition-colors hover:outline-primary-light focus-visible:ring-2 focus-visible:ring-primary active:opacity-80",
          index === selected && "outline-primary"
        ),
        children: /* @__PURE__ */ jsxDEV(
          ArtworkImage,
          {
            sizes: "100px",
            src: thumbnail.src,
            alt: "",
            width: 100,
            height: 100,
            className: "aspect-square size-[100px] object-cover"
          },
          void 0,
          false,
          {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/GalleryThumbnails.tsx",
            lineNumber: 29,
            columnNumber: 11
          },
          this
        )
      },
      `${thumbnail.src}-${index}`,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/GalleryThumbnails.tsx",
        lineNumber: 17,
        columnNumber: 7
      },
      this
    )
  ) }, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/GalleryThumbnails.tsx",
    lineNumber: 15,
    columnNumber: 5
  }, this);
}
_c = GalleryThumbnails;
var _c;
$RefreshReg$(_c, "GalleryThumbnails");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/GalleryThumbnails.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/GalleryThumbnails.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/GalleryThumbnails.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEJVO0FBNUJWLFNBQVNBLG9CQUFvQjtBQUU3QixTQUFTQyxVQUFVO0FBRVosZ0JBQVNDLGtCQUFrQjtBQUFBLEVBQ2hDQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUtGLEdBQUc7QUFDRCxTQUNFLHVCQUFDLFNBQUksV0FBVSxvREFDWkYsaUJBQU9HO0FBQUFBLElBQUksQ0FBQ0MsV0FBV0MsVUFDdEI7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUVDLGNBQVksY0FBY0EsUUFBUSxDQUFDO0FBQUEsUUFDbkMsZ0JBQWNBLFVBQVVKO0FBQUFBLFFBQ3hCLFNBQVMsTUFBTTtBQUNiQyxtQkFBU0csS0FBSztBQUFBLFFBQ2hCO0FBQUEsUUFDQSxXQUFXUDtBQUFBQSxVQUNUO0FBQUEsVUFDQU8sVUFBVUosWUFBWTtBQUFBLFFBQ3hCO0FBQUEsUUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sS0FBS0csVUFBVUU7QUFBQUEsWUFDZixLQUFJO0FBQUEsWUFDSixPQUFPO0FBQUEsWUFDUCxRQUFRO0FBQUEsWUFDUixXQUFVO0FBQUE7QUFBQSxVQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1xRDtBQUFBO0FBQUEsTUFqQmhELEdBQUdGLFVBQVVFLEdBQUcsSUFBSUQsS0FBSztBQUFBLE1BRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFvQkE7QUFBQSxFQUNELEtBdkJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3QkE7QUFFSjtBQUFDRSxLQXBDZVI7QUFBaUIsSUFBQVE7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiQXJ0d29ya0ltYWdlIiwiY24iLCJHYWxsZXJ5VGh1bWJuYWlscyIsImltYWdlcyIsInNlbGVjdGVkIiwib25TZWxlY3QiLCJtYXAiLCJ0aHVtYm5haWwiLCJpbmRleCIsInNyYyIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkdhbGxlcnlUaHVtYm5haWxzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBcnR3b3JrSW1hZ2UgfSBmcm9tICdAL2NvbXBvbmVudHMvbWVkaWEvQXJ0d29ya0ltYWdlJztcbmltcG9ydCB0eXBlIHsgTmZ0SW1hZ2UgfSBmcm9tICdAL2NvbnRyYWN0cy9uZnQnO1xuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi9jbic7XG5cbmV4cG9ydCBmdW5jdGlvbiBHYWxsZXJ5VGh1bWJuYWlscyh7XG4gIGltYWdlcyxcbiAgc2VsZWN0ZWQsXG4gIG9uU2VsZWN0LFxufToge1xuICBpbWFnZXM6IE5mdEltYWdlW107XG4gIHNlbGVjdGVkOiBudW1iZXI7XG4gIG9uU2VsZWN0OiAoaW5kZXg6IG51bWJlcikgPT4gdm9pZDtcbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiB3LVsxMDBweF0gc2hyaW5rLTAgZmxleC1jb2wgZ2FwLTQgbGc6ZmxleFwiPlxuICAgICAge2ltYWdlcy5tYXAoKHRodW1ibmFpbCwgaW5kZXgpID0+IChcbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIGtleT17YCR7dGh1bWJuYWlsLnNyY30tJHtpbmRleH1gfVxuICAgICAgICAgIGFyaWEtbGFiZWw9e2BWZXIgaW1hZ2VtICR7aW5kZXggKyAxfWB9XG4gICAgICAgICAgYXJpYS1wcmVzc2VkPXtpbmRleCA9PT0gc2VsZWN0ZWR9XG4gICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgb25TZWxlY3QoaW5kZXgpO1xuICAgICAgICAgIH19XG4gICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICdjdXJzb3ItcG9pbnRlciBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1jb250cm9sIGJvcmRlci0wIG91dGxpbmUtMiBvdXRsaW5lLXRyYW5zcGFyZW50IHRyYW5zaXRpb24tY29sb3JzIGhvdmVyOm91dGxpbmUtcHJpbWFyeS1saWdodCBmb2N1cy12aXNpYmxlOnJpbmctMiBmb2N1cy12aXNpYmxlOnJpbmctcHJpbWFyeSBhY3RpdmU6b3BhY2l0eS04MCcsXG4gICAgICAgICAgICBpbmRleCA9PT0gc2VsZWN0ZWQgJiYgJ291dGxpbmUtcHJpbWFyeScsXG4gICAgICAgICAgKX1cbiAgICAgICAgPlxuICAgICAgICAgIDxBcnR3b3JrSW1hZ2VcbiAgICAgICAgICAgIHNpemVzPVwiMTAwcHhcIlxuICAgICAgICAgICAgc3JjPXt0aHVtYm5haWwuc3JjfVxuICAgICAgICAgICAgYWx0PVwiXCJcbiAgICAgICAgICAgIHdpZHRoPXsxMDB9XG4gICAgICAgICAgICBoZWlnaHQ9ezEwMH1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImFzcGVjdC1zcXVhcmUgc2l6ZS1bMTAwcHhdIG9iamVjdC1jb3ZlclwiXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICApKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2ZpbGlwZWNhdmFsY2FudGUvRG9jdW1lbnRzL0p1bmdsZUdhbWluZ1Rlc3RlL3NyYy9mZWF0dXJlcy9uZnQtZGV0YWlsL2NvbXBvbmVudHMvR2FsbGVyeVRodW1ibmFpbHMudHN4In0=