import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/favorites/components/FavoriteButton.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { FigmaIcon } from "/src/components/icons/FigmaIcon.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { cn } from "/src/lib/cn.ts";
import { useFavoriteControl } from "/src/features/favorites/useFavoriteControl.ts";
export function FavoriteButton({
  nftId,
  name,
  className,
  showLabel = false,
  context = "card"
}) {
  _s();
  const { selected, pending, disabled, toggle } = useFavoriteControl(nftId);
  return /* @__PURE__ */ jsxDEV(
    Button,
    {
      variant: showLabel ? "favorite-label" : context === "detail" ? "detail-round" : "favorite",
      size: showLabel ? "favorite-label" : context === "detail" ? "detail-icon" : "icon",
      "aria-label": `Favoritar ${name}`,
      "aria-pressed": selected,
      "aria-busy": pending,
      disabled,
      onClick: toggle,
      className: cn("text-text-accent hover:text-primary", selected && "text-primary", className),
      children: [
        /* @__PURE__ */ jsxDEV(
          FigmaIcon,
          {
            name: selected ? "heart-solid" : showLabel ? "heart-detail" : "heart",
            size: showLabel ? 20 : 16,
            className: showLabel ? "text-primary" : void 0
          },
          void 0,
          false,
          {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/favorites/components/FavoriteButton.tsx",
            lineNumber: 32,
            columnNumber: 7
          },
          this
        ),
        showLabel && "Favoritar"
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/favorites/components/FavoriteButton.tsx",
      lineNumber: 22,
      columnNumber: 5
    },
    this
  );
}
_s(FavoriteButton, "75+pmtD9Fw+EQqVNNaG+jUqmSxI=", false, function() {
  return [useFavoriteControl];
});
_c = FavoriteButton;
var _c;
$RefreshReg$(_c, "FavoriteButton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/favorites/components/FavoriteButton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/favorites/components/FavoriteButton.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/favorites/components/FavoriteButton.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0JNOztBQS9CTixTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxVQUFVO0FBRW5CLFNBQVNDLDBCQUEwQjtBQUU1QixnQkFBU0MsZUFBZTtBQUFBLEVBQzdCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxZQUFZO0FBQUEsRUFDWkMsVUFBVTtBQU9aLEdBQUc7QUFBQUMsS0FBQTtBQUNELFFBQU0sRUFBRUMsVUFBVUMsU0FBU0MsVUFBVUMsT0FBTyxJQUFJWCxtQkFBbUJFLEtBQUs7QUFDeEUsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsU0FBU0csWUFBWSxtQkFBbUJDLFlBQVksV0FBVyxpQkFBaUI7QUFBQSxNQUNoRixNQUFNRCxZQUFZLG1CQUFtQkMsWUFBWSxXQUFXLGdCQUFnQjtBQUFBLE1BQzVFLGNBQVksYUFBYUgsSUFBSTtBQUFBLE1BQzdCLGdCQUFjSztBQUFBQSxNQUNkLGFBQVdDO0FBQUFBLE1BQ1g7QUFBQSxNQUNBLFNBQVNFO0FBQUFBLE1BQ1QsV0FBV1osR0FBRyx1Q0FBdUNTLFlBQVksZ0JBQWdCSixTQUFTO0FBQUEsTUFFMUY7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBTUksV0FBVyxnQkFBZ0JILFlBQVksaUJBQWlCO0FBQUEsWUFDOUQsTUFBTUEsWUFBWSxLQUFLO0FBQUEsWUFDdkIsV0FBV0EsWUFBWSxpQkFBaUJPO0FBQUFBO0FBQUFBLFVBSDFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUdvRDtBQUFBLFFBRW5EUCxhQUFhO0FBQUE7QUFBQTtBQUFBLElBZmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWdCQTtBQUVKO0FBQUNFLEdBakNlTixnQkFBYztBQUFBLFVBYW9CRCxrQkFBa0I7QUFBQTtBQUFBLEtBYnBEQztBQUFjLElBQUFZO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkZpZ21hSWNvbiIsIkJ1dHRvbiIsImNuIiwidXNlRmF2b3JpdGVDb250cm9sIiwiRmF2b3JpdGVCdXR0b24iLCJuZnRJZCIsIm5hbWUiLCJjbGFzc05hbWUiLCJzaG93TGFiZWwiLCJjb250ZXh0IiwiX3MiLCJzZWxlY3RlZCIsInBlbmRpbmciLCJkaXNhYmxlZCIsInRvZ2dsZSIsInVuZGVmaW5lZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkZhdm9yaXRlQnV0dG9uLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGaWdtYUljb24gfSBmcm9tICdAL2NvbXBvbmVudHMvaWNvbnMvRmlnbWFJY29uJztcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nO1xuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi9jbic7XG5cbmltcG9ydCB7IHVzZUZhdm9yaXRlQ29udHJvbCB9IGZyb20gJy4uL3VzZUZhdm9yaXRlQ29udHJvbCc7XG5cbmV4cG9ydCBmdW5jdGlvbiBGYXZvcml0ZUJ1dHRvbih7XG4gIG5mdElkLFxuICBuYW1lLFxuICBjbGFzc05hbWUsXG4gIHNob3dMYWJlbCA9IGZhbHNlLFxuICBjb250ZXh0ID0gJ2NhcmQnLFxufToge1xuICBuZnRJZDogc3RyaW5nO1xuICBuYW1lOiBzdHJpbmc7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbiAgc2hvd0xhYmVsPzogYm9vbGVhbjtcbiAgY29udGV4dD86ICdjYXJkJyB8ICdkZXRhaWwnO1xufSkge1xuICBjb25zdCB7IHNlbGVjdGVkLCBwZW5kaW5nLCBkaXNhYmxlZCwgdG9nZ2xlIH0gPSB1c2VGYXZvcml0ZUNvbnRyb2wobmZ0SWQpO1xuICByZXR1cm4gKFxuICAgIDxCdXR0b25cbiAgICAgIHZhcmlhbnQ9e3Nob3dMYWJlbCA/ICdmYXZvcml0ZS1sYWJlbCcgOiBjb250ZXh0ID09PSAnZGV0YWlsJyA/ICdkZXRhaWwtcm91bmQnIDogJ2Zhdm9yaXRlJ31cbiAgICAgIHNpemU9e3Nob3dMYWJlbCA/ICdmYXZvcml0ZS1sYWJlbCcgOiBjb250ZXh0ID09PSAnZGV0YWlsJyA/ICdkZXRhaWwtaWNvbicgOiAnaWNvbid9XG4gICAgICBhcmlhLWxhYmVsPXtgRmF2b3JpdGFyICR7bmFtZX1gfVxuICAgICAgYXJpYS1wcmVzc2VkPXtzZWxlY3RlZH1cbiAgICAgIGFyaWEtYnVzeT17cGVuZGluZ31cbiAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cbiAgICAgIG9uQ2xpY2s9e3RvZ2dsZX1cbiAgICAgIGNsYXNzTmFtZT17Y24oJ3RleHQtdGV4dC1hY2NlbnQgaG92ZXI6dGV4dC1wcmltYXJ5Jywgc2VsZWN0ZWQgJiYgJ3RleHQtcHJpbWFyeScsIGNsYXNzTmFtZSl9XG4gICAgPlxuICAgICAgPEZpZ21hSWNvblxuICAgICAgICBuYW1lPXtzZWxlY3RlZCA/ICdoZWFydC1zb2xpZCcgOiBzaG93TGFiZWwgPyAnaGVhcnQtZGV0YWlsJyA6ICdoZWFydCd9XG4gICAgICAgIHNpemU9e3Nob3dMYWJlbCA/IDIwIDogMTZ9XG4gICAgICAgIGNsYXNzTmFtZT17c2hvd0xhYmVsID8gJ3RleHQtcHJpbWFyeScgOiB1bmRlZmluZWR9XG4gICAgICAvPlxuICAgICAge3Nob3dMYWJlbCAmJiAnRmF2b3JpdGFyJ31cbiAgICA8L0J1dHRvbj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2ZpbGlwZWNhdmFsY2FudGUvRG9jdW1lbnRzL0p1bmdsZUdhbWluZ1Rlc3RlL3NyYy9mZWF0dXJlcy9mYXZvcml0ZXMvY29tcG9uZW50cy9GYXZvcml0ZUJ1dHRvbi50c3gifQ==