import { useNavigate, useSearch } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=970a124b";
export function useDetailNavigation() {
  const search = useSearch({ from: "/nfts/$nftId" });
  const navigate = useNavigate({ from: "/nfts/$nftId" });
  return {
    ...search,
    setTab: (tab) => {
      void navigate({
        search: { ...search, tab: tab === "reviews" ? "reviews" : "details" },
        resetScroll: false
      });
    },
    setPage: (reviewPage) => {
      void navigate({ search: { tab: "reviews", reviewPage }, resetScroll: false });
    }
  };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZURldGFpbE5hdmlnYXRpb24udHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTmF2aWdhdGUsIHVzZVNlYXJjaCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInO1xuXG5leHBvcnQgZnVuY3Rpb24gdXNlRGV0YWlsTmF2aWdhdGlvbigpIHtcbiAgY29uc3Qgc2VhcmNoID0gdXNlU2VhcmNoKHsgZnJvbTogJy9uZnRzLyRuZnRJZCcgfSk7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoeyBmcm9tOiAnL25mdHMvJG5mdElkJyB9KTtcbiAgcmV0dXJuIHtcbiAgICAuLi5zZWFyY2gsXG4gICAgc2V0VGFiOiAodGFiOiBzdHJpbmcpID0+IHtcbiAgICAgIHZvaWQgbmF2aWdhdGUoe1xuICAgICAgICBzZWFyY2g6IHsgLi4uc2VhcmNoLCB0YWI6IHRhYiA9PT0gJ3Jldmlld3MnID8gJ3Jldmlld3MnIDogJ2RldGFpbHMnIH0sXG4gICAgICAgIHJlc2V0U2Nyb2xsOiBmYWxzZSxcbiAgICAgIH0pO1xuICAgIH0sXG4gICAgc2V0UGFnZTogKHJldmlld1BhZ2U6IG51bWJlcikgPT4ge1xuICAgICAgdm9pZCBuYXZpZ2F0ZSh7IHNlYXJjaDogeyB0YWI6ICdyZXZpZXdzJywgcmV2aWV3UGFnZSB9LCByZXNldFNjcm9sbDogZmFsc2UgfSk7XG4gICAgfSxcbiAgfTtcbn1cbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhLGlCQUFpQjtBQUVoQyxnQkFBUyxzQkFBc0I7QUFDcEMsUUFBTSxTQUFTLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUNqRCxRQUFNLFdBQVcsWUFBWSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ3JELFNBQU87QUFBQSxJQUNMLEdBQUc7QUFBQSxJQUNILFFBQVEsQ0FBQyxRQUFnQjtBQUN2QixXQUFLLFNBQVM7QUFBQSxRQUNaLFFBQVEsRUFBRSxHQUFHLFFBQVEsS0FBSyxRQUFRLFlBQVksWUFBWSxVQUFVO0FBQUEsUUFDcEUsYUFBYTtBQUFBLE1BQ2YsQ0FBQztBQUFBLElBQ0g7QUFBQSxJQUNBLFNBQVMsQ0FBQyxlQUF1QjtBQUMvQixXQUFLLFNBQVMsRUFBRSxRQUFRLEVBQUUsS0FBSyxXQUFXLFdBQVcsR0FBRyxhQUFhLE1BQU0sQ0FBQztBQUFBLElBQzlFO0FBQUEsRUFDRjtBQUNGOyIsIm5hbWVzIjpbXX0=