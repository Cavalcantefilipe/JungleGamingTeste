import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/ReviewCard.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { RatingStars } from "/src/features/nft-detail/components/RatingStars.tsx";
export function ReviewCard({ review }) {
  const date = new Intl.DateTimeFormat("pt-BR", { dateStyle: "medium", timeZone: "UTC" }).format(
    new Date(review.createdAt)
  );
  return /* @__PURE__ */ jsxDEV(
    "article",
    {
      "aria-label": `Avaliação de ${review.author}, ${date}`,
      className: "space-y-4 rounded-control border border-border bg-surface-card p-5",
      children: [
        /* @__PURE__ */ jsxDEV("header", { className: "flex flex-wrap items-start justify-between gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "font-bold", children: review.author }, void 0, false, {
              fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewCard.tsx",
              lineNumber: 16,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-text-secondary", children: [
              "Edição ",
              review.edition
            ] }, void 0, true, {
              fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewCard.tsx",
              lineNumber: 17,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewCard.tsx",
            lineNumber: 15,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(RatingStars, { rating: { average: review.rating, count: 1 } }, void 0, false, {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewCard.tsx",
            lineNumber: 19,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewCard.tsx",
          lineNumber: 14,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm leading-6 text-text-secondary", children: review.comment }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewCard.tsx",
          lineNumber: 21,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("time", { dateTime: review.createdAt, className: "block text-xs text-text-secondary", children: date }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewCard.tsx",
          lineNumber: 22,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewCard.tsx",
      lineNumber: 10,
      columnNumber: 5
    },
    this
  );
}
_c = ReviewCard;
var _c;
$RefreshReg$(_c, "ReviewCard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewCard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewCard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewCard.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZVU7QUFiVixTQUFTQSxtQkFBbUI7QUFFckIsZ0JBQVNDLFdBQVcsRUFBRUMsT0FBMkIsR0FBRztBQUN6RCxRQUFNQyxPQUFPLElBQUlDLEtBQUtDLGVBQWUsU0FBUyxFQUFFQyxXQUFXLFVBQVVDLFVBQVUsTUFBTSxDQUFDLEVBQUVDO0FBQUFBLElBQ3RGLElBQUlDLEtBQUtQLE9BQU9RLFNBQVM7QUFBQSxFQUMzQjtBQUNBLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLGNBQVksZ0JBQWdCUixPQUFPUyxNQUFNLEtBQUtSLElBQUk7QUFBQSxNQUNsRCxXQUFVO0FBQUEsTUFFVjtBQUFBLCtCQUFDLFlBQU8sV0FBVSxvREFDaEI7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSxhQUFhRCxpQkFBT1MsVUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUM7QUFBQSxZQUN6Qyx1QkFBQyxPQUFFLFdBQVUsK0JBQThCO0FBQUE7QUFBQSxjQUFRVCxPQUFPVTtBQUFBQSxpQkFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0U7QUFBQSxlQUZwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxlQUFZLFFBQVEsRUFBRUMsU0FBU1gsT0FBT1ksUUFBUUMsT0FBTyxFQUFFLEtBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBEO0FBQUEsYUFMNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUseUNBQXlDYixpQkFBT2MsV0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRTtBQUFBLFFBQ3JFLHVCQUFDLFVBQUssVUFBVWQsT0FBT1EsV0FBVyxXQUFVLHFDQUN6Q1Asa0JBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUE7QUFBQTtBQUFBLElBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBZUE7QUFFSjtBQUFDYyxLQXRCZWhCO0FBQVUsSUFBQWdCO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlJhdGluZ1N0YXJzIiwiUmV2aWV3Q2FyZCIsInJldmlldyIsImRhdGUiLCJJbnRsIiwiRGF0ZVRpbWVGb3JtYXQiLCJkYXRlU3R5bGUiLCJ0aW1lWm9uZSIsImZvcm1hdCIsIkRhdGUiLCJjcmVhdGVkQXQiLCJhdXRob3IiLCJlZGl0aW9uIiwiYXZlcmFnZSIsInJhdGluZyIsImNvdW50IiwiY29tbWVudCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlJldmlld0NhcmQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgUmV2aWV3IH0gZnJvbSAnQC9jb250cmFjdHMvcmV2aWV3JztcblxuaW1wb3J0IHsgUmF0aW5nU3RhcnMgfSBmcm9tICcuL1JhdGluZ1N0YXJzJztcblxuZXhwb3J0IGZ1bmN0aW9uIFJldmlld0NhcmQoeyByZXZpZXcgfTogeyByZXZpZXc6IFJldmlldyB9KSB7XG4gIGNvbnN0IGRhdGUgPSBuZXcgSW50bC5EYXRlVGltZUZvcm1hdCgncHQtQlInLCB7IGRhdGVTdHlsZTogJ21lZGl1bScsIHRpbWVab25lOiAnVVRDJyB9KS5mb3JtYXQoXG4gICAgbmV3IERhdGUocmV2aWV3LmNyZWF0ZWRBdCksXG4gICk7XG4gIHJldHVybiAoXG4gICAgPGFydGljbGVcbiAgICAgIGFyaWEtbGFiZWw9e2BBdmFsaWHDp8OjbyBkZSAke3Jldmlldy5hdXRob3J9LCAke2RhdGV9YH1cbiAgICAgIGNsYXNzTmFtZT1cInNwYWNlLXktNCByb3VuZGVkLWNvbnRyb2wgYm9yZGVyIGJvcmRlci1ib3JkZXIgYmctc3VyZmFjZS1jYXJkIHAtNVwiXG4gICAgPlxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkXCI+e3Jldmlldy5hdXRob3J9PC9oMz5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtdGV4dC1zZWNvbmRhcnlcIj5FZGnDp8OjbyB7cmV2aWV3LmVkaXRpb259PC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPFJhdGluZ1N0YXJzIHJhdGluZz17eyBhdmVyYWdlOiByZXZpZXcucmF0aW5nLCBjb3VudDogMSB9fSAvPlxuICAgICAgPC9oZWFkZXI+XG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGxlYWRpbmctNiB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+e3Jldmlldy5jb21tZW50fTwvcD5cbiAgICAgIDx0aW1lIGRhdGVUaW1lPXtyZXZpZXcuY3JlYXRlZEF0fSBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIHRleHQtdGV4dC1zZWNvbmRhcnlcIj5cbiAgICAgICAge2RhdGV9XG4gICAgICA8L3RpbWU+XG4gICAgPC9hcnRpY2xlPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvZmlsaXBlY2F2YWxjYW50ZS9Eb2N1bWVudHMvSnVuZ2xlR2FtaW5nVGVzdGUvc3JjL2ZlYXR1cmVzL25mdC1kZXRhaWwvY29tcG9uZW50cy9SZXZpZXdDYXJkLnRzeCJ9