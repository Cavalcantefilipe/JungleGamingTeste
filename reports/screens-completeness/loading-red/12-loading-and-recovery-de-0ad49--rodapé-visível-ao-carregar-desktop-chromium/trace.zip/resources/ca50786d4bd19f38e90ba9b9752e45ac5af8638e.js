import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/RelatedCarousel.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { ErrorState } from "/src/components/feedback/ErrorState.tsx";
import { NftCarousel } from "/src/features/catalog/components/NftCarousel.tsx";
import { detailMessages } from "/src/features/nft-detail/messages.ts";
import { useRelatedNfts } from "/src/features/nft-detail/useRelatedNfts.ts";
import { RelatedSkeleton } from "/src/features/nft-detail/components/RelatedSkeleton.tsx";
export function RelatedCarousel({ nft }) {
  _s();
  const { items, query } = useRelatedNfts(nft);
  return /* @__PURE__ */ jsxDEV("div", { className: "mt-section", children: query.isPending ? /* @__PURE__ */ jsxDEV(RelatedSkeleton, {}, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/RelatedCarousel.tsx",
    lineNumber: 14,
    columnNumber: 7
  }, this) : query.isError ? /* @__PURE__ */ jsxDEV("section", { "aria-label": detailMessages.related, children: /* @__PURE__ */ jsxDEV(
    ErrorState,
    {
      error: query.error,
      retry: () => {
        void query.refetch();
      }
    },
    void 0,
    false,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/RelatedCarousel.tsx",
      lineNumber: 17,
      columnNumber: 11
    },
    this
  ) }, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/RelatedCarousel.tsx",
    lineNumber: 16,
    columnNumber: 7
  }, this) : items.length > 0 ? /* @__PURE__ */ jsxDEV(NftCarousel, { title: detailMessages.related, items }, nft.id, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/RelatedCarousel.tsx",
    lineNumber: 25,
    columnNumber: 7
  }, this) : null }, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/RelatedCarousel.tsx",
    lineNumber: 12,
    columnNumber: 5
  }, this);
}
_s(RelatedCarousel, "9CUHr1h3RMMV3ALvVVmA+hANDAI=", false, function() {
  return [useRelatedNfts];
});
_c = RelatedCarousel;
var _c;
$RefreshReg$(_c, "RelatedCarousel");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/RelatedCarousel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/RelatedCarousel.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/RelatedCarousel.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYVE7O0FBYlIsU0FBU0Esa0JBQWtCO0FBRTNCLFNBQVNDLG1CQUFtQjtBQUU1QixTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLHVCQUF1QjtBQUV6QixnQkFBU0MsZ0JBQWdCLEVBQUVDLElBQWtCLEdBQUc7QUFBQUMsS0FBQTtBQUNyRCxRQUFNLEVBQUVDLE9BQU9DLE1BQU0sSUFBSU4sZUFBZUcsR0FBRztBQUMzQyxTQUNFLHVCQUFDLFNBQUksV0FBVSxjQUNaRyxnQkFBTUMsWUFDTCx1QkFBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWdCLElBQ2RELE1BQU1FLFVBQ1IsdUJBQUMsYUFBUSxjQUFZVCxlQUFlVSxTQUNsQztBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsT0FBT0gsTUFBTUk7QUFBQUEsTUFDYixPQUFPLE1BQU07QUFDWCxhQUFLSixNQUFNSyxRQUFRO0FBQUEsTUFDckI7QUFBQTtBQUFBLElBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUksS0FMTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBT0EsSUFDRU4sTUFBTU8sU0FBUyxJQUNqQix1QkFBQyxlQUF5QixPQUFPYixlQUFlVSxTQUFTLFNBQXZDTixJQUFJVSxJQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXNFLElBQ3BFLFFBZE47QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWVBO0FBRUo7QUFBQ1QsR0FwQmVGLGlCQUFlO0FBQUEsVUFDSkYsY0FBYztBQUFBO0FBQUEsS0FEekJFO0FBQWUsSUFBQVk7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiRXJyb3JTdGF0ZSIsIk5mdENhcm91c2VsIiwiZGV0YWlsTWVzc2FnZXMiLCJ1c2VSZWxhdGVkTmZ0cyIsIlJlbGF0ZWRTa2VsZXRvbiIsIlJlbGF0ZWRDYXJvdXNlbCIsIm5mdCIsIl9zIiwiaXRlbXMiLCJxdWVyeSIsImlzUGVuZGluZyIsImlzRXJyb3IiLCJyZWxhdGVkIiwiZXJyb3IiLCJyZWZldGNoIiwibGVuZ3RoIiwiaWQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJSZWxhdGVkQ2Fyb3VzZWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEVycm9yU3RhdGUgfSBmcm9tICdAL2NvbXBvbmVudHMvZmVlZGJhY2svRXJyb3JTdGF0ZSc7XG5pbXBvcnQgdHlwZSB7IE5mdCB9IGZyb20gJ0AvY29udHJhY3RzL25mdCc7XG5pbXBvcnQgeyBOZnRDYXJvdXNlbCB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy9jb21wb25lbnRzL05mdENhcm91c2VsJztcblxuaW1wb3J0IHsgZGV0YWlsTWVzc2FnZXMgfSBmcm9tICcuLi9tZXNzYWdlcyc7XG5pbXBvcnQgeyB1c2VSZWxhdGVkTmZ0cyB9IGZyb20gJy4uL3VzZVJlbGF0ZWROZnRzJztcbmltcG9ydCB7IFJlbGF0ZWRTa2VsZXRvbiB9IGZyb20gJy4vUmVsYXRlZFNrZWxldG9uJztcblxuZXhwb3J0IGZ1bmN0aW9uIFJlbGF0ZWRDYXJvdXNlbCh7IG5mdCB9OiB7IG5mdDogTmZ0IH0pIHtcbiAgY29uc3QgeyBpdGVtcywgcXVlcnkgfSA9IHVzZVJlbGF0ZWROZnRzKG5mdCk7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtdC1zZWN0aW9uXCI+XG4gICAgICB7cXVlcnkuaXNQZW5kaW5nID8gKFxuICAgICAgICA8UmVsYXRlZFNrZWxldG9uIC8+XG4gICAgICApIDogcXVlcnkuaXNFcnJvciA/IChcbiAgICAgICAgPHNlY3Rpb24gYXJpYS1sYWJlbD17ZGV0YWlsTWVzc2FnZXMucmVsYXRlZH0+XG4gICAgICAgICAgPEVycm9yU3RhdGVcbiAgICAgICAgICAgIGVycm9yPXtxdWVyeS5lcnJvcn1cbiAgICAgICAgICAgIHJldHJ5PXsoKSA9PiB7XG4gICAgICAgICAgICAgIHZvaWQgcXVlcnkucmVmZXRjaCgpO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L3NlY3Rpb24+XG4gICAgICApIDogaXRlbXMubGVuZ3RoID4gMCA/IChcbiAgICAgICAgPE5mdENhcm91c2VsIGtleT17bmZ0LmlkfSB0aXRsZT17ZGV0YWlsTWVzc2FnZXMucmVsYXRlZH0gaXRlbXM9e2l0ZW1zfSAvPlxuICAgICAgKSA6IG51bGx9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9maWxpcGVjYXZhbGNhbnRlL0RvY3VtZW50cy9KdW5nbGVHYW1pbmdUZXN0ZS9zcmMvZmVhdHVyZXMvbmZ0LWRldGFpbC9jb21wb25lbnRzL1JlbGF0ZWRDYXJvdXNlbC50c3gifQ==