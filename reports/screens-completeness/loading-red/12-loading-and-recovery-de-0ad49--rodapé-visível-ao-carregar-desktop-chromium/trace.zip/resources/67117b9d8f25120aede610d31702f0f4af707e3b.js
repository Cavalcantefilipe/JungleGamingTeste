import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/CarouselDots.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { cn } from "/src/lib/cn.ts";
export function CarouselDots({ page, pages, goTo }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap justify-center", "aria-label": "Páginas das recomendações", children: Array.from(
    { length: pages },
    (_, index) => /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        "aria-label": `Ir para página ${index + 1} das recomendações`,
        "aria-current": page === index ? "page" : void 0,
        onClick: () => {
          goTo(index);
        },
        className: "grid size-11 place-items-center rounded-control hover:bg-surface-card active:bg-surface-raised",
        children: /* @__PURE__ */ jsxDEV(
          "span",
          {
            className: cn(
              "size-3 rounded-full border-2 border-primary",
              page === index && "bg-primary"
            )
          },
          void 0,
          false,
          {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CarouselDots.tsx",
            lineNumber: 19,
            columnNumber: 11
          },
          this
        )
      },
      index,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CarouselDots.tsx",
        lineNumber: 9,
        columnNumber: 7
      },
      this
    )
  ) }, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CarouselDots.tsx",
    lineNumber: 7,
    columnNumber: 5
  }, this);
}
_c = CarouselDots;
var _c;
$RefreshReg$(_c, "CarouselDots");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CarouselDots.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CarouselDots.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CarouselDots.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JVO0FBbEJWLFNBQVNBLFVBQVU7QUFJWixnQkFBU0MsYUFBYSxFQUFFQyxNQUFNQyxPQUFPQyxLQUE4QixHQUFHO0FBQzNFLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGlDQUFnQyxjQUFXLDZCQUN2REMsZ0JBQU1DO0FBQUFBLElBQUssRUFBRUMsUUFBUUosTUFBTTtBQUFBLElBQUcsQ0FBQ0ssR0FBR0MsVUFDakM7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUVDLE1BQUs7QUFBQSxRQUNMLGNBQVksa0JBQWtCQSxRQUFRLENBQUM7QUFBQSxRQUN2QyxnQkFBY1AsU0FBU08sUUFBUSxTQUFTQztBQUFBQSxRQUN4QyxTQUFTLE1BQU07QUFDYk4sZUFBS0ssS0FBSztBQUFBLFFBQ1o7QUFBQSxRQUNBLFdBQVU7QUFBQSxRQUVWO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFXVDtBQUFBQSxjQUNUO0FBQUEsY0FDQUUsU0FBU08sU0FBUztBQUFBLFlBQ3BCO0FBQUE7QUFBQSxVQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUlJO0FBQUE7QUFBQSxNQWJDQTtBQUFBQSxNQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFnQkE7QUFBQSxFQUNELEtBbkJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvQkE7QUFFSjtBQUFDRSxLQXhCZVY7QUFBWSxJQUFBVTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJjbiIsIkNhcm91c2VsRG90cyIsInBhZ2UiLCJwYWdlcyIsImdvVG8iLCJBcnJheSIsImZyb20iLCJsZW5ndGgiLCJfIiwiaW5kZXgiLCJ1bmRlZmluZWQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDYXJvdXNlbERvdHMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNuIH0gZnJvbSAnQC9saWIvY24nO1xuXG5pbXBvcnQgdHlwZSB7IENhcm91c2VsTmF2aWdhdGlvblN0YXRlIH0gZnJvbSAnLi4vdXNlQ2Fyb3VzZWwnO1xuXG5leHBvcnQgZnVuY3Rpb24gQ2Fyb3VzZWxEb3RzKHsgcGFnZSwgcGFnZXMsIGdvVG8gfTogQ2Fyb3VzZWxOYXZpZ2F0aW9uU3RhdGUpIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGp1c3RpZnktY2VudGVyXCIgYXJpYS1sYWJlbD1cIlDDoWdpbmFzIGRhcyByZWNvbWVuZGHDp8O1ZXNcIj5cbiAgICAgIHtBcnJheS5mcm9tKHsgbGVuZ3RoOiBwYWdlcyB9LCAoXywgaW5kZXgpID0+IChcbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIGtleT17aW5kZXh9XG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgYXJpYS1sYWJlbD17YElyIHBhcmEgcMOhZ2luYSAke2luZGV4ICsgMX0gZGFzIHJlY29tZW5kYcOnw7Vlc2B9XG4gICAgICAgICAgYXJpYS1jdXJyZW50PXtwYWdlID09PSBpbmRleCA/ICdwYWdlJyA6IHVuZGVmaW5lZH1cbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICBnb1RvKGluZGV4KTtcbiAgICAgICAgICB9fVxuICAgICAgICAgIGNsYXNzTmFtZT1cImdyaWQgc2l6ZS0xMSBwbGFjZS1pdGVtcy1jZW50ZXIgcm91bmRlZC1jb250cm9sIGhvdmVyOmJnLXN1cmZhY2UtY2FyZCBhY3RpdmU6Ymctc3VyZmFjZS1yYWlzZWRcIlxuICAgICAgICA+XG4gICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICdzaXplLTMgcm91bmRlZC1mdWxsIGJvcmRlci0yIGJvcmRlci1wcmltYXJ5JyxcbiAgICAgICAgICAgICAgcGFnZSA9PT0gaW5kZXggJiYgJ2JnLXByaW1hcnknLFxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgICkpfVxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvZmlsaXBlY2F2YWxjYW50ZS9Eb2N1bWVudHMvSnVuZ2xlR2FtaW5nVGVzdGUvc3JjL2ZlYXR1cmVzL2NhdGFsb2cvY29tcG9uZW50cy9DYXJvdXNlbERvdHMudHN4In0=