import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/NftCard.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=970a124b";
import { FavoriteButton } from "/src/features/favorites/components/FavoriteButton.tsx";
import { NftCardInfo } from "/src/features/catalog/components/NftCardInfo.tsx";
import { NftCardMedia } from "/src/features/catalog/components/NftCardMedia.tsx";
export function NftCard({
  nft,
  priority = false,
  variant = "catalog"
}) {
  return /* @__PURE__ */ jsxDEV("article", { className: "group relative grid min-w-0", children: [
    /* @__PURE__ */ jsxDEV(
      Link,
      {
        to: "/nfts/$nftId",
        params: { nftId: nft.id },
        className: "col-start-1 row-start-1 block space-y-3 rounded-xl",
        children: [
          /* @__PURE__ */ jsxDEV(NftCardMedia, { nft, priority }, void 0, false, {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCard.tsx",
            lineNumber: 25,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(NftCardInfo, { nft, variant }, void 0, false, {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCard.tsx",
            lineNumber: 26,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCard.tsx",
        lineNumber: 20,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "pointer-events-none col-start-1 row-start-1 flex aspect-[174/200] items-center self-start px-1 lg:aspect-[258/300]", children: /* @__PURE__ */ jsxDEV("div", { className: "relative aspect-square w-full", children: /* @__PURE__ */ jsxDEV(
      FavoriteButton,
      {
        nftId: nft.id,
        name: nft.name,
        className: "pointer-events-auto absolute -top-2 right-0 size-11 reveal-on-hover sm:size-11"
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCard.tsx",
        lineNumber: 30,
        columnNumber: 11
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCard.tsx",
      lineNumber: 29,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCard.tsx",
      lineNumber: 28,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCard.tsx",
    lineNumber: 19,
    columnNumber: 5
  }, this);
}
_c = NftCard;
var _c;
$RefreshReg$(_c, "NftCard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCard.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0JRO0FBeEJSLFNBQVNBLFlBQVk7QUFHckIsU0FBU0Msc0JBQXNCO0FBRS9CLFNBQVNDLG1CQUF3QztBQUNqRCxTQUFTQyxvQkFBb0I7QUFFdEIsZ0JBQVNDLFFBQVE7QUFBQSxFQUN0QkM7QUFBQUEsRUFDQUMsV0FBVztBQUFBLEVBQ1hDLFVBQVU7QUFLWixHQUFHO0FBQ0QsU0FDRSx1QkFBQyxhQUFRLFdBQVUsK0JBQ2pCO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLElBQUc7QUFBQSxRQUNILFFBQVEsRUFBRUMsT0FBT0gsSUFBSUksR0FBRztBQUFBLFFBQ3hCLFdBQVU7QUFBQSxRQUVWO0FBQUEsaUNBQUMsZ0JBQWEsS0FBVSxZQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQztBQUFBLFVBQzNDLHVCQUFDLGVBQVksS0FBVSxXQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3QztBQUFBO0FBQUE7QUFBQSxNQU4xQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFPQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFVLHNIQUNiLGlDQUFDLFNBQUksV0FBVSxpQ0FDYjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBT0osSUFBSUk7QUFBQUEsUUFDWCxNQUFNSixJQUFJSztBQUFBQSxRQUNWLFdBQVU7QUFBQTtBQUFBLE1BSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRzRGLEtBSjlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLE9BakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrQkE7QUFFSjtBQUFDQyxLQTlCZVA7QUFBTyxJQUFBTztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJMaW5rIiwiRmF2b3JpdGVCdXR0b24iLCJOZnRDYXJkSW5mbyIsIk5mdENhcmRNZWRpYSIsIk5mdENhcmQiLCJuZnQiLCJwcmlvcml0eSIsInZhcmlhbnQiLCJuZnRJZCIsImlkIiwibmFtZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk5mdENhcmQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmsgfSBmcm9tICdAdGFuc3RhY2svcmVhY3Qtcm91dGVyJztcblxuaW1wb3J0IHR5cGUgeyBOZnQgfSBmcm9tICdAL2NvbnRyYWN0cy9uZnQnO1xuaW1wb3J0IHsgRmF2b3JpdGVCdXR0b24gfSBmcm9tICdAL2ZlYXR1cmVzL2Zhdm9yaXRlcy9jb21wb25lbnRzL0Zhdm9yaXRlQnV0dG9uJztcblxuaW1wb3J0IHsgTmZ0Q2FyZEluZm8sIHR5cGUgTmZ0Q2FyZFZhcmlhbnQgfSBmcm9tICcuL05mdENhcmRJbmZvJztcbmltcG9ydCB7IE5mdENhcmRNZWRpYSB9IGZyb20gJy4vTmZ0Q2FyZE1lZGlhJztcblxuZXhwb3J0IGZ1bmN0aW9uIE5mdENhcmQoe1xuICBuZnQsXG4gIHByaW9yaXR5ID0gZmFsc2UsXG4gIHZhcmlhbnQgPSAnY2F0YWxvZycsXG59OiB7XG4gIG5mdDogTmZ0O1xuICBwcmlvcml0eT86IGJvb2xlYW47XG4gIHZhcmlhbnQ/OiBOZnRDYXJkVmFyaWFudDtcbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8YXJ0aWNsZSBjbGFzc05hbWU9XCJncm91cCByZWxhdGl2ZSBncmlkIG1pbi13LTBcIj5cbiAgICAgIDxMaW5rXG4gICAgICAgIHRvPVwiL25mdHMvJG5mdElkXCJcbiAgICAgICAgcGFyYW1zPXt7IG5mdElkOiBuZnQuaWQgfX1cbiAgICAgICAgY2xhc3NOYW1lPVwiY29sLXN0YXJ0LTEgcm93LXN0YXJ0LTEgYmxvY2sgc3BhY2UteS0zIHJvdW5kZWQteGxcIlxuICAgICAgPlxuICAgICAgICA8TmZ0Q2FyZE1lZGlhIG5mdD17bmZ0fSBwcmlvcml0eT17cHJpb3JpdHl9IC8+XG4gICAgICAgIDxOZnRDYXJkSW5mbyBuZnQ9e25mdH0gdmFyaWFudD17dmFyaWFudH0gLz5cbiAgICAgIDwvTGluaz5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtbm9uZSBjb2wtc3RhcnQtMSByb3ctc3RhcnQtMSBmbGV4IGFzcGVjdC1bMTc0LzIwMF0gaXRlbXMtY2VudGVyIHNlbGYtc3RhcnQgcHgtMSBsZzphc3BlY3QtWzI1OC8zMDBdXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgYXNwZWN0LXNxdWFyZSB3LWZ1bGxcIj5cbiAgICAgICAgICA8RmF2b3JpdGVCdXR0b25cbiAgICAgICAgICAgIG5mdElkPXtuZnQuaWR9XG4gICAgICAgICAgICBuYW1lPXtuZnQubmFtZX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInBvaW50ZXItZXZlbnRzLWF1dG8gYWJzb2x1dGUgLXRvcC0yIHJpZ2h0LTAgc2l6ZS0xMSByZXZlYWwtb24taG92ZXIgc206c2l6ZS0xMVwiXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2FydGljbGU+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9maWxpcGVjYXZhbGNhbnRlL0RvY3VtZW50cy9KdW5nbGVHYW1pbmdUZXN0ZS9zcmMvZmVhdHVyZXMvY2F0YWxvZy9jb21wb25lbnRzL05mdENhcmQudHN4In0=