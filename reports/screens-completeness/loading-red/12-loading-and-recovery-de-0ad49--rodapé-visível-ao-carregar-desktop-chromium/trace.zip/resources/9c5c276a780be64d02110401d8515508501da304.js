import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/Gallery.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=970a124b"; const useState = __vite__cjsImport1_react["useState"];
import { ArtworkImage } from "/src/components/media/ArtworkImage.tsx";
import { GalleryThumbnails } from "/src/features/nft-detail/components/GalleryThumbnails.tsx";
import { GalleryZoom } from "/src/features/nft-detail/components/GalleryZoom.tsx";
export function Gallery({ images }) {
  _s();
  const [selected, setSelected] = useState(0);
  const image = images[selected] ?? images[0];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center lg:gap-[29px]", children: [
    /* @__PURE__ */ jsxDEV(GalleryThumbnails, { images, selected, onSelect: setSelected }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/Gallery.tsx",
      lineNumber: 14,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        "data-testid": "gallery-frame",
        className: "relative ml-1 w-[calc(100%-5px)] min-w-0 md:ml-0 md:w-full lg:flex lg:size-[444px] lg:shrink-0 lg:items-center lg:justify-center lg:rounded-control lg:bg-surface-card lg:p-4",
        children: [
          /* @__PURE__ */ jsxDEV(
            ArtworkImage,
            {
              sizes: "(min-width: 1024px) 404px, (min-width: 768px) calc(100vw - 48px), calc(100vw - 48px)",
              loading: "eager",
              "data-testid": "gallery-image",
              src: image?.src,
              alt: image?.alt ?? "",
              width: 404,
              height: 404,
              fetchPriority: "high",
              className: "aspect-[361/356] w-full rounded-3xl object-cover md:aspect-square lg:size-[404px]"
            },
            void 0,
            false,
            {
              fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/Gallery.tsx",
              lineNumber: 19,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(GalleryZoom, { image }, void 0, false, {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/Gallery.tsx",
            lineNumber: 30,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/Gallery.tsx",
        lineNumber: 15,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/Gallery.tsx",
    lineNumber: 13,
    columnNumber: 5
  }, this);
}
_s(Gallery, "gGT9ux4E8pnUkSZL1bYkDrfRDO0=");
_c = Gallery;
var _c;
$RefreshReg$(_c, "Gallery");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/Gallery.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/Gallery.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/Gallery.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYU07O0FBYk4sU0FBU0EsZ0JBQWdCO0FBRXpCLFNBQVNDLG9CQUFvQjtBQUc3QixTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0MsbUJBQW1CO0FBRXJCLGdCQUFTQyxRQUFRLEVBQUVDLE9BQStCLEdBQUc7QUFBQUMsS0FBQTtBQUMxRCxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSVIsU0FBUyxDQUFDO0FBQzFDLFFBQU1TLFFBQVFKLE9BQU9FLFFBQVEsS0FBS0YsT0FBTyxDQUFDO0FBQzFDLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLG1DQUNiO0FBQUEsMkJBQUMscUJBQWtCLFFBQWdCLFVBQW9CLFVBQVVHLGVBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkU7QUFBQSxJQUM3RTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsZUFBWTtBQUFBLFFBQ1osV0FBVTtBQUFBLFFBRVY7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sU0FBUTtBQUFBLGNBQ1IsZUFBWTtBQUFBLGNBQ1osS0FBS0MsT0FBT0M7QUFBQUEsY0FDWixLQUFLRCxPQUFPRSxPQUFPO0FBQUEsY0FDbkIsT0FBTztBQUFBLGNBQ1AsUUFBUTtBQUFBLGNBQ1IsZUFBYztBQUFBLGNBQ2QsV0FBVTtBQUFBO0FBQUEsWUFUWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFTK0Y7QUFBQSxVQUUvRix1QkFBQyxlQUFZLFNBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEI7QUFBQTtBQUFBO0FBQUEsTUFmNUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBZ0JBO0FBQUEsT0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1CQTtBQUVKO0FBQUNMLEdBekJlRixTQUFPO0FBQUEsS0FBUEE7QUFBTyxJQUFBUTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkFydHdvcmtJbWFnZSIsIkdhbGxlcnlUaHVtYm5haWxzIiwiR2FsbGVyeVpvb20iLCJHYWxsZXJ5IiwiaW1hZ2VzIiwiX3MiLCJzZWxlY3RlZCIsInNldFNlbGVjdGVkIiwiaW1hZ2UiLCJzcmMiLCJhbHQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJHYWxsZXJ5LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcblxuaW1wb3J0IHsgQXJ0d29ya0ltYWdlIH0gZnJvbSAnQC9jb21wb25lbnRzL21lZGlhL0FydHdvcmtJbWFnZSc7XG5pbXBvcnQgdHlwZSB7IE5mdEltYWdlIH0gZnJvbSAnQC9jb250cmFjdHMvbmZ0JztcblxuaW1wb3J0IHsgR2FsbGVyeVRodW1ibmFpbHMgfSBmcm9tICcuL0dhbGxlcnlUaHVtYm5haWxzJztcbmltcG9ydCB7IEdhbGxlcnlab29tIH0gZnJvbSAnLi9HYWxsZXJ5Wm9vbSc7XG5cbmV4cG9ydCBmdW5jdGlvbiBHYWxsZXJ5KHsgaW1hZ2VzIH06IHsgaW1hZ2VzOiBOZnRJbWFnZVtdIH0pIHtcbiAgY29uc3QgW3NlbGVjdGVkLCBzZXRTZWxlY3RlZF0gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3QgaW1hZ2UgPSBpbWFnZXNbc2VsZWN0ZWRdID8/IGltYWdlc1swXTtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGxnOmdhcC1bMjlweF1cIj5cbiAgICAgIDxHYWxsZXJ5VGh1bWJuYWlscyBpbWFnZXM9e2ltYWdlc30gc2VsZWN0ZWQ9e3NlbGVjdGVkfSBvblNlbGVjdD17c2V0U2VsZWN0ZWR9IC8+XG4gICAgICA8ZGl2XG4gICAgICAgIGRhdGEtdGVzdGlkPVwiZ2FsbGVyeS1mcmFtZVwiXG4gICAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlIG1sLTEgdy1bY2FsYygxMDAlLTVweCldIG1pbi13LTAgbWQ6bWwtMCBtZDp3LWZ1bGwgbGc6ZmxleCBsZzpzaXplLVs0NDRweF0gbGc6c2hyaW5rLTAgbGc6aXRlbXMtY2VudGVyIGxnOmp1c3RpZnktY2VudGVyIGxnOnJvdW5kZWQtY29udHJvbCBsZzpiZy1zdXJmYWNlLWNhcmQgbGc6cC00XCJcbiAgICAgID5cbiAgICAgICAgPEFydHdvcmtJbWFnZVxuICAgICAgICAgIHNpemVzPVwiKG1pbi13aWR0aDogMTAyNHB4KSA0MDRweCwgKG1pbi13aWR0aDogNzY4cHgpIGNhbGMoMTAwdncgLSA0OHB4KSwgY2FsYygxMDB2dyAtIDQ4cHgpXCJcbiAgICAgICAgICBsb2FkaW5nPVwiZWFnZXJcIlxuICAgICAgICAgIGRhdGEtdGVzdGlkPVwiZ2FsbGVyeS1pbWFnZVwiXG4gICAgICAgICAgc3JjPXtpbWFnZT8uc3JjfVxuICAgICAgICAgIGFsdD17aW1hZ2U/LmFsdCA/PyAnJ31cbiAgICAgICAgICB3aWR0aD17NDA0fVxuICAgICAgICAgIGhlaWdodD17NDA0fVxuICAgICAgICAgIGZldGNoUHJpb3JpdHk9XCJoaWdoXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJhc3BlY3QtWzM2MS8zNTZdIHctZnVsbCByb3VuZGVkLTN4bCBvYmplY3QtY292ZXIgbWQ6YXNwZWN0LXNxdWFyZSBsZzpzaXplLVs0MDRweF1cIlxuICAgICAgICAvPlxuICAgICAgICA8R2FsbGVyeVpvb20gaW1hZ2U9e2ltYWdlfSAvPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9maWxpcGVjYXZhbGNhbnRlL0RvY3VtZW50cy9KdW5nbGVHYW1pbmdUZXN0ZS9zcmMvZmVhdHVyZXMvbmZ0LWRldGFpbC9jb21wb25lbnRzL0dhbGxlcnkudHN4In0=