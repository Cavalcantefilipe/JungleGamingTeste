import { useMutation } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=970a124b";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=970a124b";
export function useShareLink() {
  return useMutation({
    mutationFn: () => navigator.clipboard.writeText(location.href),
    onSuccess: () => toast.success("Link copiado"),
    onError: () => toast.error("Não foi possível copiar o link")
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZVNoYXJlTGluay50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VNdXRhdGlvbiB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3Nvbm5lcic7XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VTaGFyZUxpbmsoKSB7XG4gIHJldHVybiB1c2VNdXRhdGlvbih7XG4gICAgbXV0YXRpb25GbjogKCkgPT4gbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQobG9jYXRpb24uaHJlZiksXG4gICAgb25TdWNjZXNzOiAoKSA9PiB0b2FzdC5zdWNjZXNzKCdMaW5rIGNvcGlhZG8nKSxcbiAgICBvbkVycm9yOiAoKSA9PiB0b2FzdC5lcnJvcignTsOjbyBmb2kgcG9zc8OtdmVsIGNvcGlhciBvIGxpbmsnKSxcbiAgfSk7XG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsYUFBYTtBQUVmLGdCQUFTLGVBQWU7QUFDN0IsU0FBTyxZQUFZO0FBQUEsSUFDakIsWUFBWSxNQUFNLFVBQVUsVUFBVSxVQUFVLFNBQVMsSUFBSTtBQUFBLElBQzdELFdBQVcsTUFBTSxNQUFNLFFBQVEsY0FBYztBQUFBLElBQzdDLFNBQVMsTUFBTSxNQUFNLE1BQU0sZ0NBQWdDO0FBQUEsRUFDN0QsQ0FBQztBQUNIOyIsIm5hbWVzIjpbXX0=