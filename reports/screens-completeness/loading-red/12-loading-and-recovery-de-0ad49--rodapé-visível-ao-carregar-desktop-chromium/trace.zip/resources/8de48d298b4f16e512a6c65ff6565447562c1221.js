import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/PurchaseActions.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { FigmaIcon } from "/src/components/icons/FigmaIcon.tsx";
import { Button } from "/src/components/ui/button.tsx";
export function PurchaseActions({
  pending,
  disabled,
  purchase,
  add
}) {
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      Button,
      {
        disabled: pending || disabled,
        onClick: purchase,
        size: "purchase",
        className: "w-[196px] max-w-[calc(100%-72px)] lg:ml-auto lg:w-[130px] lg:max-w-none",
        children: [
          /* @__PURE__ */ jsxDEV("span", { className: "lg:hidden", children: "Comprar NFT" }, void 0, false, {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/PurchaseActions.tsx",
            lineNumber: 23,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "hidden lg:inline", children: "COMPRAR" }, void 0, false, {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/PurchaseActions.tsx",
            lineNumber: 24,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/PurchaseActions.tsx",
        lineNumber: 17,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Button,
      {
        variant: "basket",
        size: "purchase-icon",
        "aria-label": "Adicionar ao carrinho",
        disabled: pending || disabled,
        onClick: add,
        children: /* @__PURE__ */ jsxDEV(FigmaIcon, { name: "cart-solid", "aria-hidden": "true", size: 20 }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/PurchaseActions.tsx",
          lineNumber: 33,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/PurchaseActions.tsx",
        lineNumber: 26,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/PurchaseActions.tsx",
    lineNumber: 16,
    columnNumber: 5
  }, this);
}
_c = PurchaseActions;
var _c;
$RefreshReg$(_c, "PurchaseActions");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/PurchaseActions.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/PurchaseActions.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/PurchaseActions.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZUksbUJBT0ksY0FQSjtBQWZKLFNBQVNBLGlCQUFpQjtBQUMxQixTQUFTQyxjQUFjO0FBRWhCLGdCQUFTQyxnQkFBZ0I7QUFBQSxFQUM5QkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFNRixHQUFHO0FBQ0QsU0FDRSxtQ0FDRTtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxVQUFVSCxXQUFXQztBQUFBQSxRQUNyQixTQUFTQztBQUFBQSxRQUNULE1BQUs7QUFBQSxRQUNMLFdBQVU7QUFBQSxRQUVWO0FBQUEsaUNBQUMsVUFBSyxXQUFVLGFBQVksMkJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVDO0FBQUEsVUFDdkMsdUJBQUMsVUFBSyxXQUFVLG9CQUFtQix1QkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEM7QUFBQTtBQUFBO0FBQUEsTUFQNUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBUUE7QUFBQSxJQUNBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFRO0FBQUEsUUFDUixNQUFLO0FBQUEsUUFDTCxjQUFXO0FBQUEsUUFDWCxVQUFVRixXQUFXQztBQUFBQSxRQUNyQixTQUFTRTtBQUFBQSxRQUVULGlDQUFDLGFBQVUsTUFBSyxjQUFhLGVBQVksUUFBTyxNQUFNLE1BQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUQ7QUFBQTtBQUFBLE1BUDNEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVFBO0FBQUEsT0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1CQTtBQUVKO0FBQUNDLEtBakNlTDtBQUFlLElBQUFLO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkZpZ21hSWNvbiIsIkJ1dHRvbiIsIlB1cmNoYXNlQWN0aW9ucyIsInBlbmRpbmciLCJkaXNhYmxlZCIsInB1cmNoYXNlIiwiYWRkIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUHVyY2hhc2VBY3Rpb25zLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGaWdtYUljb24gfSBmcm9tICdAL2NvbXBvbmVudHMvaWNvbnMvRmlnbWFJY29uJztcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nO1xuXG5leHBvcnQgZnVuY3Rpb24gUHVyY2hhc2VBY3Rpb25zKHtcbiAgcGVuZGluZyxcbiAgZGlzYWJsZWQsXG4gIHB1cmNoYXNlLFxuICBhZGQsXG59OiB7XG4gIHBlbmRpbmc6IGJvb2xlYW47XG4gIGRpc2FibGVkOiBib29sZWFuO1xuICBwdXJjaGFzZTogKCkgPT4gdm9pZDtcbiAgYWRkOiAoKSA9PiB2b2lkO1xufSkge1xuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8QnV0dG9uXG4gICAgICAgIGRpc2FibGVkPXtwZW5kaW5nIHx8IGRpc2FibGVkfVxuICAgICAgICBvbkNsaWNrPXtwdXJjaGFzZX1cbiAgICAgICAgc2l6ZT1cInB1cmNoYXNlXCJcbiAgICAgICAgY2xhc3NOYW1lPVwidy1bMTk2cHhdIG1heC13LVtjYWxjKDEwMCUtNzJweCldIGxnOm1sLWF1dG8gbGc6dy1bMTMwcHhdIGxnOm1heC13LW5vbmVcIlxuICAgICAgPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsZzpoaWRkZW5cIj5Db21wcmFyIE5GVDwvc3Bhbj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIGxnOmlubGluZVwiPkNPTVBSQVI8L3NwYW4+XG4gICAgICA8L0J1dHRvbj5cbiAgICAgIDxCdXR0b25cbiAgICAgICAgdmFyaWFudD1cImJhc2tldFwiXG4gICAgICAgIHNpemU9XCJwdXJjaGFzZS1pY29uXCJcbiAgICAgICAgYXJpYS1sYWJlbD1cIkFkaWNpb25hciBhbyBjYXJyaW5ob1wiXG4gICAgICAgIGRpc2FibGVkPXtwZW5kaW5nIHx8IGRpc2FibGVkfVxuICAgICAgICBvbkNsaWNrPXthZGR9XG4gICAgICA+XG4gICAgICAgIDxGaWdtYUljb24gbmFtZT1cImNhcnQtc29saWRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiBzaXplPXsyMH0gLz5cbiAgICAgIDwvQnV0dG9uPlxuICAgIDwvPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvZmlsaXBlY2F2YWxjYW50ZS9Eb2N1bWVudHMvSnVuZ2xlR2FtaW5nVGVzdGUvc3JjL2ZlYXR1cmVzL25mdC1kZXRhaWwvY29tcG9uZW50cy9QdXJjaGFzZUFjdGlvbnMudHN4In0=