import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/media/ArtworkImage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
export function ArtworkImage({
  src,
  alt,
  sizes,
  loading = "lazy",
  ...props
}) {
  const base = src?.match(/^(\/images\/nfts\/[^/]+)-800\.webp$/)?.[1];
  const sources = (format) => `${base}-400.${format} 400w, ${base}-800.${format} 800w`;
  return /* @__PURE__ */ jsxDEV("picture", { className: "contents", children: [
    base && /* @__PURE__ */ jsxDEV("source", { className: "hidden", type: "image/avif", srcSet: sources("avif"), sizes }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/media/ArtworkImage.tsx",
      lineNumber: 19,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "img",
      {
        ...props,
        src,
        alt,
        loading,
        sizes: base ? sizes : void 0,
        srcSet: base ? sources("webp") : void 0
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/media/ArtworkImage.tsx",
        lineNumber: 21,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/media/ArtworkImage.tsx",
    lineNumber: 17,
    columnNumber: 5
  }, this);
}
_c = ArtworkImage;
var _c;
$RefreshReg$(_c, "ArtworkImage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/media/ArtworkImage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/media/ArtworkImage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/media/ArtworkImage.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JRO0FBaEJELGdCQUFTQSxhQUFhO0FBQUEsRUFDM0JDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDLFVBQVU7QUFBQSxFQUNWLEdBQUdDO0FBS0wsR0FBRztBQUNELFFBQU1DLE9BQU9MLEtBQUtNLE1BQU0scUNBQXFDLElBQUksQ0FBQztBQUNsRSxRQUFNQyxVQUFVQSxDQUFDQyxXQUFtQixHQUFHSCxJQUFJLFFBQVFHLE1BQU0sVUFBVUgsSUFBSSxRQUFRRyxNQUFNO0FBQ3JGLFNBQ0UsdUJBQUMsYUFBUSxXQUFVLFlBQ2hCSDtBQUFBQSxZQUNDLHVCQUFDLFlBQU8sV0FBVSxVQUFTLE1BQUssY0FBYSxRQUFRRSxRQUFRLE1BQU0sR0FBRyxTQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1GO0FBQUEsSUFFckY7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLEdBQUlIO0FBQUFBLFFBQ0o7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0EsT0FBT0MsT0FBT0gsUUFBUU87QUFBQUEsUUFDdEIsUUFBUUosT0FBT0UsUUFBUSxNQUFNLElBQUlFO0FBQUFBO0FBQUFBLE1BTm5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU02QztBQUFBLE9BVi9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FZQTtBQUVKO0FBQUNDLEtBNUJlWDtBQUFZLElBQUFXO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkFydHdvcmtJbWFnZSIsInNyYyIsImFsdCIsInNpemVzIiwibG9hZGluZyIsInByb3BzIiwiYmFzZSIsIm1hdGNoIiwic291cmNlcyIsImZvcm1hdCIsInVuZGVmaW5lZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkFydHdvcmtJbWFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBDb21wb25lbnRQcm9wcyB9IGZyb20gJ3JlYWN0JztcblxuZXhwb3J0IGZ1bmN0aW9uIEFydHdvcmtJbWFnZSh7XG4gIHNyYyxcbiAgYWx0LFxuICBzaXplcyxcbiAgbG9hZGluZyA9ICdsYXp5JyxcbiAgLi4ucHJvcHNcbn06IE9taXQ8Q29tcG9uZW50UHJvcHM8J2ltZyc+LCAnc3JjJyB8ICdhbHQnIHwgJ3NpemVzJz4gJiB7XG4gIHNyYzogc3RyaW5nIHwgdW5kZWZpbmVkO1xuICBhbHQ6IHN0cmluZztcbiAgc2l6ZXM6IHN0cmluZztcbn0pIHtcbiAgY29uc3QgYmFzZSA9IHNyYz8ubWF0Y2goL14oXFwvaW1hZ2VzXFwvbmZ0c1xcL1teL10rKS04MDBcXC53ZWJwJC8pPy5bMV07XG4gIGNvbnN0IHNvdXJjZXMgPSAoZm9ybWF0OiBzdHJpbmcpID0+IGAke2Jhc2V9LTQwMC4ke2Zvcm1hdH0gNDAwdywgJHtiYXNlfS04MDAuJHtmb3JtYXR9IDgwMHdgO1xuICByZXR1cm4gKFxuICAgIDxwaWN0dXJlIGNsYXNzTmFtZT1cImNvbnRlbnRzXCI+XG4gICAgICB7YmFzZSAmJiAoXG4gICAgICAgIDxzb3VyY2UgY2xhc3NOYW1lPVwiaGlkZGVuXCIgdHlwZT1cImltYWdlL2F2aWZcIiBzcmNTZXQ9e3NvdXJjZXMoJ2F2aWYnKX0gc2l6ZXM9e3NpemVzfSAvPlxuICAgICAgKX1cbiAgICAgIDxpbWdcbiAgICAgICAgey4uLnByb3BzfVxuICAgICAgICBzcmM9e3NyY31cbiAgICAgICAgYWx0PXthbHR9XG4gICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XG4gICAgICAgIHNpemVzPXtiYXNlID8gc2l6ZXMgOiB1bmRlZmluZWR9XG4gICAgICAgIHNyY1NldD17YmFzZSA/IHNvdXJjZXMoJ3dlYnAnKSA6IHVuZGVmaW5lZH1cbiAgICAgIC8+XG4gICAgPC9waWN0dXJlPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvZmlsaXBlY2F2YWxjYW50ZS9Eb2N1bWVudHMvSnVuZ2xlR2FtaW5nVGVzdGUvc3JjL2NvbXBvbmVudHMvbWVkaWEvQXJ0d29ya0ltYWdlLnRzeCJ9