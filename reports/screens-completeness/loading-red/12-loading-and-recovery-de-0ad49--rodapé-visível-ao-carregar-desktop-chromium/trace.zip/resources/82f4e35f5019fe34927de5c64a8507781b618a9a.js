import { useMutation, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=970a124b";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=970a124b";
import { sessionStore, useSession } from "/src/features/auth/session-store.ts";
import { ApiError } from "/src/lib/errors.ts";
import { queryKeys } from "/src/lib/query-keys.ts";
import { setFavorite } from "/src/features/favorites/api.ts";
import { getFavoriteToggle, invalidateFavoriteLists, updateFavoriteCache } from "/src/features/favorites/favorite-cache.ts";
import { favoriteMessages } from "/src/features/favorites/messages.ts";
export function useToggleFavorite() {
  const session = useSession();
  const userId = session?.user.id ?? "";
  const client = useQueryClient();
  const key = queryKeys.favorites(userId);
  const mutationKey = ["favorite-mutation", userId];
  const isCurrentUser = () => Boolean(session && sessionStore.getSnapshot()?.token === session.token);
  const update = (nftId, remove) => {
    updateFavoriteCache(client, userId, nftId, remove);
  };
  const mutation = useMutation({
    mutationKey,
    mutationFn: ({ nftId, remove }) => {
      if (!isCurrentUser()) throw new ApiError("UNAUTHENTICATED", 401);
      return setFavorite(nftId, remove);
    },
    onMutate: async ({ nftId, remove }) => {
      await client.cancelQueries({ queryKey: key });
      if (!isCurrentUser()) return;
      update(nftId, remove);
    },
    onError: (_error, { nftId, remove }) => {
      if (!isCurrentUser()) return;
      update(nftId, !remove);
      toast.error(favoriteMessages.updateFailed);
    },
    onSettled: async () => {
      if (!isCurrentUser() || client.isMutating({ mutationKey }) !== 1) return;
      await invalidateFavoriteLists(client, userId);
    }
  });
  return {
    ...mutation,
    mutate: (nftId) => {
      mutation.mutate(getFavoriteToggle(client, userId, nftId));
    }
  };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZVRvZ2dsZUZhdm9yaXRlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3Nvbm5lcic7XG5cbmltcG9ydCB7IHNlc3Npb25TdG9yZSwgdXNlU2Vzc2lvbiB9IGZyb20gJ0AvZmVhdHVyZXMvYXV0aC9zZXNzaW9uLXN0b3JlJztcbmltcG9ydCB7IEFwaUVycm9yIH0gZnJvbSAnQC9saWIvZXJyb3JzJztcbmltcG9ydCB7IHF1ZXJ5S2V5cyB9IGZyb20gJ0AvbGliL3F1ZXJ5LWtleXMnO1xuXG5pbXBvcnQgeyBzZXRGYXZvcml0ZSB9IGZyb20gJy4vYXBpJztcbmltcG9ydCB7IGdldEZhdm9yaXRlVG9nZ2xlLCBpbnZhbGlkYXRlRmF2b3JpdGVMaXN0cywgdXBkYXRlRmF2b3JpdGVDYWNoZSB9IGZyb20gJy4vZmF2b3JpdGUtY2FjaGUnO1xuaW1wb3J0IHsgZmF2b3JpdGVNZXNzYWdlcyB9IGZyb20gJy4vbWVzc2FnZXMnO1xuXG5leHBvcnQgZnVuY3Rpb24gdXNlVG9nZ2xlRmF2b3JpdGUoKSB7XG4gIGNvbnN0IHNlc3Npb24gPSB1c2VTZXNzaW9uKCk7XG4gIGNvbnN0IHVzZXJJZCA9IHNlc3Npb24/LnVzZXIuaWQgPz8gJyc7XG4gIGNvbnN0IGNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KCk7XG4gIGNvbnN0IGtleSA9IHF1ZXJ5S2V5cy5mYXZvcml0ZXModXNlcklkKTtcbiAgY29uc3QgbXV0YXRpb25LZXkgPSBbJ2Zhdm9yaXRlLW11dGF0aW9uJywgdXNlcklkXTtcbiAgY29uc3QgaXNDdXJyZW50VXNlciA9ICgpID0+XG4gICAgQm9vbGVhbihzZXNzaW9uICYmIHNlc3Npb25TdG9yZS5nZXRTbmFwc2hvdCgpPy50b2tlbiA9PT0gc2Vzc2lvbi50b2tlbik7XG4gIGNvbnN0IHVwZGF0ZSA9IChuZnRJZDogc3RyaW5nLCByZW1vdmU6IGJvb2xlYW4pID0+IHtcbiAgICB1cGRhdGVGYXZvcml0ZUNhY2hlKGNsaWVudCwgdXNlcklkLCBuZnRJZCwgcmVtb3ZlKTtcbiAgfTtcbiAgY29uc3QgbXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XG4gICAgbXV0YXRpb25LZXksXG4gICAgbXV0YXRpb25GbjogKHsgbmZ0SWQsIHJlbW92ZSB9OiB7IG5mdElkOiBzdHJpbmc7IHJlbW92ZTogYm9vbGVhbiB9KSA9PiB7XG4gICAgICBpZiAoIWlzQ3VycmVudFVzZXIoKSkgdGhyb3cgbmV3IEFwaUVycm9yKCdVTkFVVEhFTlRJQ0FURUQnLCA0MDEpO1xuICAgICAgcmV0dXJuIHNldEZhdm9yaXRlKG5mdElkLCByZW1vdmUpO1xuICAgIH0sXG4gICAgb25NdXRhdGU6IGFzeW5jICh7IG5mdElkLCByZW1vdmUgfSkgPT4ge1xuICAgICAgYXdhaXQgY2xpZW50LmNhbmNlbFF1ZXJpZXMoeyBxdWVyeUtleToga2V5IH0pO1xuICAgICAgaWYgKCFpc0N1cnJlbnRVc2VyKCkpIHJldHVybjtcbiAgICAgIHVwZGF0ZShuZnRJZCwgcmVtb3ZlKTtcbiAgICB9LFxuICAgIG9uRXJyb3I6IChfZXJyb3IsIHsgbmZ0SWQsIHJlbW92ZSB9KSA9PiB7XG4gICAgICBpZiAoIWlzQ3VycmVudFVzZXIoKSkgcmV0dXJuO1xuICAgICAgdXBkYXRlKG5mdElkLCAhcmVtb3ZlKTtcbiAgICAgIHRvYXN0LmVycm9yKGZhdm9yaXRlTWVzc2FnZXMudXBkYXRlRmFpbGVkKTtcbiAgICB9LFxuICAgIG9uU2V0dGxlZDogYXN5bmMgKCkgPT4ge1xuICAgICAgaWYgKCFpc0N1cnJlbnRVc2VyKCkgfHwgY2xpZW50LmlzTXV0YXRpbmcoeyBtdXRhdGlvbktleSB9KSAhPT0gMSkgcmV0dXJuO1xuICAgICAgYXdhaXQgaW52YWxpZGF0ZUZhdm9yaXRlTGlzdHMoY2xpZW50LCB1c2VySWQpO1xuICAgIH0sXG4gIH0pO1xuICByZXR1cm4ge1xuICAgIC4uLm11dGF0aW9uLFxuICAgIG11dGF0ZTogKG5mdElkOiBzdHJpbmcpID0+IHtcbiAgICAgIG11dGF0aW9uLm11dGF0ZShnZXRGYXZvcml0ZVRvZ2dsZShjbGllbnQsIHVzZXJJZCwgbmZ0SWQpKTtcbiAgICB9LFxuICB9O1xufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLGFBQWEsc0JBQXNCO0FBQzVDLFNBQVMsYUFBYTtBQUV0QixTQUFTLGNBQWMsa0JBQWtCO0FBQ3pDLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsaUJBQWlCO0FBRTFCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsbUJBQW1CLHlCQUF5QiwyQkFBMkI7QUFDaEYsU0FBUyx3QkFBd0I7QUFFMUIsZ0JBQVMsb0JBQW9CO0FBQ2xDLFFBQU0sVUFBVSxXQUFXO0FBQzNCLFFBQU0sU0FBUyxTQUFTLEtBQUssTUFBTTtBQUNuQyxRQUFNLFNBQVMsZUFBZTtBQUM5QixRQUFNLE1BQU0sVUFBVSxVQUFVLE1BQU07QUFDdEMsUUFBTSxjQUFjLENBQUMscUJBQXFCLE1BQU07QUFDaEQsUUFBTSxnQkFBZ0IsTUFDcEIsUUFBUSxXQUFXLGFBQWEsWUFBWSxHQUFHLFVBQVUsUUFBUSxLQUFLO0FBQ3hFLFFBQU0sU0FBUyxDQUFDLE9BQWUsV0FBb0I7QUFDakQsd0JBQW9CLFFBQVEsUUFBUSxPQUFPLE1BQU07QUFBQSxFQUNuRDtBQUNBLFFBQU0sV0FBVyxZQUFZO0FBQUEsSUFDM0I7QUFBQSxJQUNBLFlBQVksQ0FBQyxFQUFFLE9BQU8sT0FBTyxNQUEwQztBQUNyRSxVQUFJLENBQUMsY0FBYyxFQUFHLE9BQU0sSUFBSSxTQUFTLG1CQUFtQixHQUFHO0FBQy9ELGFBQU8sWUFBWSxPQUFPLE1BQU07QUFBQSxJQUNsQztBQUFBLElBQ0EsVUFBVSxPQUFPLEVBQUUsT0FBTyxPQUFPLE1BQU07QUFDckMsWUFBTSxPQUFPLGNBQWMsRUFBRSxVQUFVLElBQUksQ0FBQztBQUM1QyxVQUFJLENBQUMsY0FBYyxFQUFHO0FBQ3RCLGFBQU8sT0FBTyxNQUFNO0FBQUEsSUFDdEI7QUFBQSxJQUNBLFNBQVMsQ0FBQyxRQUFRLEVBQUUsT0FBTyxPQUFPLE1BQU07QUFDdEMsVUFBSSxDQUFDLGNBQWMsRUFBRztBQUN0QixhQUFPLE9BQU8sQ0FBQyxNQUFNO0FBQ3JCLFlBQU0sTUFBTSxpQkFBaUIsWUFBWTtBQUFBLElBQzNDO0FBQUEsSUFDQSxXQUFXLFlBQVk7QUFDckIsVUFBSSxDQUFDLGNBQWMsS0FBSyxPQUFPLFdBQVcsRUFBRSxZQUFZLENBQUMsTUFBTSxFQUFHO0FBQ2xFLFlBQU0sd0JBQXdCLFFBQVEsTUFBTTtBQUFBLElBQzlDO0FBQUEsRUFDRixDQUFDO0FBQ0QsU0FBTztBQUFBLElBQ0wsR0FBRztBQUFBLElBQ0gsUUFBUSxDQUFDLFVBQWtCO0FBQ3pCLGVBQVMsT0FBTyxrQkFBa0IsUUFBUSxRQUFRLEtBQUssQ0FBQztBQUFBLElBQzFEO0FBQUEsRUFDRjtBQUNGOyIsIm5hbWVzIjpbXX0=