import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/DetailMobileNavigation.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=970a124b";
import { FigmaIcon } from "/src/components/icons/FigmaIcon.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { FavoriteButton } from "/src/features/favorites/components/FavoriteButton.tsx";
export function DetailMobileNavigation({ nft }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "-mr-1 mb-1 flex items-center justify-between lg:hidden", children: [
    /* @__PURE__ */ jsxDEV(Button, { asChild: true, variant: "detail-round", size: "detail-icon", className: "text-text-secondary", children: /* @__PURE__ */ jsxDEV(Link, { to: "/", "aria-label": "Voltar para o catálogo", children: /* @__PURE__ */ jsxDEV(FigmaIcon, { name: "chevron-left", size: 20 }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailMobileNavigation.tsx",
      lineNumber: 13,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailMobileNavigation.tsx",
      lineNumber: 12,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailMobileNavigation.tsx",
      lineNumber: 11,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(FavoriteButton, { nftId: nft.id, name: nft.name, context: "detail" }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailMobileNavigation.tsx",
      lineNumber: 16,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailMobileNavigation.tsx",
    lineNumber: 10,
    columnNumber: 5
  }, this);
}
_c = DetailMobileNavigation;
var _c;
$RefreshReg$(_c, "DetailMobileNavigation");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailMobileNavigation.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailMobileNavigation.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailMobileNavigation.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWVU7QUFaVixTQUFTQSxZQUFZO0FBRXJCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxjQUFjO0FBRXZCLFNBQVNDLHNCQUFzQjtBQUV4QixnQkFBU0MsdUJBQXVCLEVBQUVDLElBQWtCLEdBQUc7QUFDNUQsU0FDRSx1QkFBQyxTQUFJLFdBQVUsMERBQ2I7QUFBQSwyQkFBQyxVQUFPLFNBQU8sTUFBQyxTQUFRLGdCQUFlLE1BQUssZUFBYyxXQUFVLHVCQUNsRSxpQ0FBQyxRQUFLLElBQUcsS0FBSSxjQUFXLDBCQUN0QixpQ0FBQyxhQUFVLE1BQUssZ0JBQWUsTUFBTSxNQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdDLEtBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLElBQ0EsdUJBQUMsa0JBQWUsT0FBT0EsSUFBSUMsSUFBSSxNQUFNRCxJQUFJRSxNQUFNLFNBQVEsWUFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErRDtBQUFBLE9BTmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FPQTtBQUVKO0FBQUNDLEtBWGVKO0FBQXNCLElBQUFJO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkxpbmsiLCJGaWdtYUljb24iLCJCdXR0b24iLCJGYXZvcml0ZUJ1dHRvbiIsIkRldGFpbE1vYmlsZU5hdmlnYXRpb24iLCJuZnQiLCJpZCIsIm5hbWUiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJEZXRhaWxNb2JpbGVOYXZpZ2F0aW9uLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcic7XG5cbmltcG9ydCB7IEZpZ21hSWNvbiB9IGZyb20gJ0AvY29tcG9uZW50cy9pY29ucy9GaWdtYUljb24nO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbic7XG5pbXBvcnQgdHlwZSB7IE5mdCB9IGZyb20gJ0AvY29udHJhY3RzL25mdCc7XG5pbXBvcnQgeyBGYXZvcml0ZUJ1dHRvbiB9IGZyb20gJ0AvZmVhdHVyZXMvZmF2b3JpdGVzL2NvbXBvbmVudHMvRmF2b3JpdGVCdXR0b24nO1xuXG5leHBvcnQgZnVuY3Rpb24gRGV0YWlsTW9iaWxlTmF2aWdhdGlvbih7IG5mdCB9OiB7IG5mdDogTmZ0IH0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIi1tci0xIG1iLTEgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGxnOmhpZGRlblwiPlxuICAgICAgPEJ1dHRvbiBhc0NoaWxkIHZhcmlhbnQ9XCJkZXRhaWwtcm91bmRcIiBzaXplPVwiZGV0YWlsLWljb25cIiBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+XG4gICAgICAgIDxMaW5rIHRvPVwiL1wiIGFyaWEtbGFiZWw9XCJWb2x0YXIgcGFyYSBvIGNhdMOhbG9nb1wiPlxuICAgICAgICAgIDxGaWdtYUljb24gbmFtZT1cImNoZXZyb24tbGVmdFwiIHNpemU9ezIwfSAvPlxuICAgICAgICA8L0xpbms+XG4gICAgICA8L0J1dHRvbj5cbiAgICAgIDxGYXZvcml0ZUJ1dHRvbiBuZnRJZD17bmZ0LmlkfSBuYW1lPXtuZnQubmFtZX0gY29udGV4dD1cImRldGFpbFwiIC8+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9maWxpcGVjYXZhbGNhbnRlL0RvY3VtZW50cy9KdW5nbGVHYW1pbmdUZXN0ZS9zcmMvZmVhdHVyZXMvbmZ0LWRldGFpbC9jb21wb25lbnRzL0RldGFpbE1vYmlsZU5hdmlnYXRpb24udHN4In0=