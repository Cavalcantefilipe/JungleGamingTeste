import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/ReviewsSkeleton.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Skeleton } from "/src/components/ui/skeleton.tsx";
export function ReviewsSkeleton() {
  return /* @__PURE__ */ jsxDEV("div", { role: "status", "aria-label": "Carregando avaliações", className: "grid gap-5 md:grid-cols-2", children: Array.from(
    { length: 4 },
    (_, index) => /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-56" }, index, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewsSkeleton.tsx",
      lineNumber: 7,
      columnNumber: 7
    }, this)
  ) }, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewsSkeleton.tsx",
    lineNumber: 5,
    columnNumber: 5
  }, this);
}
_c = ReviewsSkeleton;
var _c;
$RefreshReg$(_c, "ReviewsSkeleton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewsSkeleton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewsSkeleton.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewsSkeleton.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBTVE7QUFOUixTQUFTQSxnQkFBZ0I7QUFFbEIsZ0JBQVNDLGtCQUFrQjtBQUNoQyxTQUNFLHVCQUFDLFNBQUksTUFBSyxVQUFTLGNBQVcseUJBQXdCLFdBQVUsNkJBQzdEQyxnQkFBTUM7QUFBQUEsSUFBSyxFQUFFQyxRQUFRLEVBQUU7QUFBQSxJQUFHLENBQUNDLEdBQUdDLFVBQzdCLHVCQUFDLFlBQXFCLFdBQVUsVUFBakJBLE9BQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzQztBQUFBLEVBQ3ZDLEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUlBO0FBRUo7QUFBQ0MsS0FSZU47QUFBZSxJQUFBTTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJTa2VsZXRvbiIsIlJldmlld3NTa2VsZXRvbiIsIkFycmF5IiwiZnJvbSIsImxlbmd0aCIsIl8iLCJpbmRleCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlJldmlld3NTa2VsZXRvbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU2tlbGV0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvc2tlbGV0b24nO1xuXG5leHBvcnQgZnVuY3Rpb24gUmV2aWV3c1NrZWxldG9uKCkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgcm9sZT1cInN0YXR1c1wiIGFyaWEtbGFiZWw9XCJDYXJyZWdhbmRvIGF2YWxpYcOnw7Vlc1wiIGNsYXNzTmFtZT1cImdyaWQgZ2FwLTUgbWQ6Z3JpZC1jb2xzLTJcIj5cbiAgICAgIHtBcnJheS5mcm9tKHsgbGVuZ3RoOiA0IH0sIChfLCBpbmRleCkgPT4gKFxuICAgICAgICA8U2tlbGV0b24ga2V5PXtpbmRleH0gY2xhc3NOYW1lPVwiaC01NlwiIC8+XG4gICAgICApKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2ZpbGlwZWNhdmFsY2FudGUvRG9jdW1lbnRzL0p1bmdsZUdhbWluZ1Rlc3RlL3NyYy9mZWF0dXJlcy9uZnQtZGV0YWlsL2NvbXBvbmVudHMvUmV2aWV3c1NrZWxldG9uLnRzeCJ9