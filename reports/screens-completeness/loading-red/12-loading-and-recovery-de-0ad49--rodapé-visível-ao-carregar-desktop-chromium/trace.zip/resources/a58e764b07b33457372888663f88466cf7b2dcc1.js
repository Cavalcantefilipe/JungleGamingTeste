import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/PurchasePanel.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { FavoriteButton } from "/src/features/favorites/components/FavoriteButton.tsx";
import { usePurchaseSelection } from "/src/features/nft-detail/usePurchaseSelection.ts";
import { EditionPicker } from "/src/features/nft-detail/components/EditionPicker.tsx";
import { MobilePurchaseBar } from "/src/features/nft-detail/components/MobilePurchaseBar.tsx";
import { PurchaseActions } from "/src/features/nft-detail/components/PurchaseActions.tsx";
import { QuantityStepper } from "/src/features/nft-detail/components/QuantityStepper.tsx";
export function PurchasePanel({ nft }) {
  _s();
  const { editionId, setEditionId, quantity, setQuantity, available, actions } = usePurchaseSelection(nft);
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-5 lg:space-y-3", children: [
    /* @__PURE__ */ jsxDEV(
      EditionPicker,
      {
        editions: nft.editions,
        value: editionId,
        onChange: (id) => {
          setEditionId(id);
          setQuantity(1);
        }
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/PurchasePanel.tsx",
        lineNumber: 15,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("p", { className: "sr-only", children: available > 0 ? `${available} disponíveis nesta edição` : "Esta edição está esgotada" }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/PurchasePanel.tsx",
      lineNumber: 23,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "hidden flex-wrap items-center gap-2 lg:flex", children: [
      /* @__PURE__ */ jsxDEV(QuantityStepper, { value: quantity, max: available, onChange: setQuantity }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/PurchasePanel.tsx",
        lineNumber: 27,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(PurchaseActions, { ...actions }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/PurchasePanel.tsx",
        lineNumber: 28,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(FavoriteButton, { nftId: nft.id, name: nft.name, showLabel: true }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/PurchasePanel.tsx",
        lineNumber: 29,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/PurchasePanel.tsx",
      lineNumber: 26,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      MobilePurchaseBar,
      {
        nft,
        quantity,
        available,
        setQuantity,
        actions
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/PurchasePanel.tsx",
        lineNumber: 31,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/PurchasePanel.tsx",
    lineNumber: 14,
    columnNumber: 5
  }, this);
}
_s(PurchasePanel, "RjEbmvVEBqrYvqRa30o2HgMEkF0=", false, function() {
  return [usePurchaseSelection];
});
_c = PurchasePanel;
var _c;
$RefreshReg$(_c, "PurchasePanel");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/PurchasePanel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/PurchasePanel.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/PurchasePanel.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY007O0FBYk4sU0FBU0Esc0JBQXNCO0FBRS9CLFNBQVNDLDRCQUE0QjtBQUNyQyxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyx1QkFBdUI7QUFFekIsZ0JBQVNDLGNBQWMsRUFBRUMsSUFBa0IsR0FBRztBQUFBQyxLQUFBO0FBQ25ELFFBQU0sRUFBRUMsV0FBV0MsY0FBY0MsVUFBVUMsYUFBYUMsV0FBV0MsUUFBUSxJQUN6RWIscUJBQXFCTSxHQUFHO0FBQzFCLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFVBQVVBLElBQUlRO0FBQUFBLFFBQ2QsT0FBT047QUFBQUEsUUFDUCxVQUFVLENBQUNPLE9BQU87QUFDaEJOLHVCQUFhTSxFQUFFO0FBQ2ZKLHNCQUFZLENBQUM7QUFBQSxRQUNmO0FBQUE7QUFBQSxNQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1JO0FBQUEsSUFFSix1QkFBQyxPQUFFLFdBQVUsV0FDVkMsc0JBQVksSUFBSSxHQUFHQSxTQUFTLDhCQUE4QiwrQkFEN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsK0NBQ2I7QUFBQSw2QkFBQyxtQkFBZ0IsT0FBT0YsVUFBVSxLQUFLRSxXQUFXLFVBQVVELGVBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0U7QUFBQSxNQUN4RSx1QkFBQyxtQkFBZ0IsR0FBSUUsV0FBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2QjtBQUFBLE1BQzdCLHVCQUFDLGtCQUFlLE9BQU9QLElBQUlTLElBQUksTUFBTVQsSUFBSVUsTUFBTSxXQUFTLFFBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0Q7QUFBQSxTQUgxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxJQUNBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQTtBQUFBLE1BTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBS21CO0FBQUEsT0F0QnJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3QkE7QUFFSjtBQUFDVCxHQTlCZUYsZUFBYTtBQUFBLFVBRXpCTCxvQkFBb0I7QUFBQTtBQUFBLEtBRlJLO0FBQWEsSUFBQVk7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiRmF2b3JpdGVCdXR0b24iLCJ1c2VQdXJjaGFzZVNlbGVjdGlvbiIsIkVkaXRpb25QaWNrZXIiLCJNb2JpbGVQdXJjaGFzZUJhciIsIlB1cmNoYXNlQWN0aW9ucyIsIlF1YW50aXR5U3RlcHBlciIsIlB1cmNoYXNlUGFuZWwiLCJuZnQiLCJfcyIsImVkaXRpb25JZCIsInNldEVkaXRpb25JZCIsInF1YW50aXR5Iiwic2V0UXVhbnRpdHkiLCJhdmFpbGFibGUiLCJhY3Rpb25zIiwiZWRpdGlvbnMiLCJpZCIsIm5hbWUiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQdXJjaGFzZVBhbmVsLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IE5mdCB9IGZyb20gJ0AvY29udHJhY3RzL25mdCc7XG5pbXBvcnQgeyBGYXZvcml0ZUJ1dHRvbiB9IGZyb20gJ0AvZmVhdHVyZXMvZmF2b3JpdGVzL2NvbXBvbmVudHMvRmF2b3JpdGVCdXR0b24nO1xuXG5pbXBvcnQgeyB1c2VQdXJjaGFzZVNlbGVjdGlvbiB9IGZyb20gJy4uL3VzZVB1cmNoYXNlU2VsZWN0aW9uJztcbmltcG9ydCB7IEVkaXRpb25QaWNrZXIgfSBmcm9tICcuL0VkaXRpb25QaWNrZXInO1xuaW1wb3J0IHsgTW9iaWxlUHVyY2hhc2VCYXIgfSBmcm9tICcuL01vYmlsZVB1cmNoYXNlQmFyJztcbmltcG9ydCB7IFB1cmNoYXNlQWN0aW9ucyB9IGZyb20gJy4vUHVyY2hhc2VBY3Rpb25zJztcbmltcG9ydCB7IFF1YW50aXR5U3RlcHBlciB9IGZyb20gJy4vUXVhbnRpdHlTdGVwcGVyJztcblxuZXhwb3J0IGZ1bmN0aW9uIFB1cmNoYXNlUGFuZWwoeyBuZnQgfTogeyBuZnQ6IE5mdCB9KSB7XG4gIGNvbnN0IHsgZWRpdGlvbklkLCBzZXRFZGl0aW9uSWQsIHF1YW50aXR5LCBzZXRRdWFudGl0eSwgYXZhaWxhYmxlLCBhY3Rpb25zIH0gPVxuICAgIHVzZVB1cmNoYXNlU2VsZWN0aW9uKG5mdCk7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTUgbGc6c3BhY2UteS0zXCI+XG4gICAgICA8RWRpdGlvblBpY2tlclxuICAgICAgICBlZGl0aW9ucz17bmZ0LmVkaXRpb25zfVxuICAgICAgICB2YWx1ZT17ZWRpdGlvbklkfVxuICAgICAgICBvbkNoYW5nZT17KGlkKSA9PiB7XG4gICAgICAgICAgc2V0RWRpdGlvbklkKGlkKTtcbiAgICAgICAgICBzZXRRdWFudGl0eSgxKTtcbiAgICAgICAgfX1cbiAgICAgIC8+XG4gICAgICA8cCBjbGFzc05hbWU9XCJzci1vbmx5XCI+XG4gICAgICAgIHthdmFpbGFibGUgPiAwID8gYCR7YXZhaWxhYmxlfSBkaXNwb27DrXZlaXMgbmVzdGEgZWRpw6fDo29gIDogJ0VzdGEgZWRpw6fDo28gZXN0w6EgZXNnb3RhZGEnfVxuICAgICAgPC9wPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMiBsZzpmbGV4XCI+XG4gICAgICAgIDxRdWFudGl0eVN0ZXBwZXIgdmFsdWU9e3F1YW50aXR5fSBtYXg9e2F2YWlsYWJsZX0gb25DaGFuZ2U9e3NldFF1YW50aXR5fSAvPlxuICAgICAgICA8UHVyY2hhc2VBY3Rpb25zIHsuLi5hY3Rpb25zfSAvPlxuICAgICAgICA8RmF2b3JpdGVCdXR0b24gbmZ0SWQ9e25mdC5pZH0gbmFtZT17bmZ0Lm5hbWV9IHNob3dMYWJlbCAvPlxuICAgICAgPC9kaXY+XG4gICAgICA8TW9iaWxlUHVyY2hhc2VCYXJcbiAgICAgICAgbmZ0PXtuZnR9XG4gICAgICAgIHF1YW50aXR5PXtxdWFudGl0eX1cbiAgICAgICAgYXZhaWxhYmxlPXthdmFpbGFibGV9XG4gICAgICAgIHNldFF1YW50aXR5PXtzZXRRdWFudGl0eX1cbiAgICAgICAgYWN0aW9ucz17YWN0aW9uc31cbiAgICAgIC8+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9maWxpcGVjYXZhbGNhbnRlL0RvY3VtZW50cy9KdW5nbGVHYW1pbmdUZXN0ZS9zcmMvZmVhdHVyZXMvbmZ0LWRldGFpbC9jb21wb25lbnRzL1B1cmNoYXNlUGFuZWwudHN4In0=