import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/BuyerReviews.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { ErrorState } from "/src/components/feedback/ErrorState.tsx";
import { detailMessages } from "/src/features/nft-detail/messages.ts";
import { useReviews } from "/src/features/nft-detail/useReviews.ts";
import { ReviewCard } from "/src/features/nft-detail/components/ReviewCard.tsx";
import { ReviewsPagination } from "/src/features/nft-detail/components/ReviewsPagination.tsx";
import { ReviewsSkeleton } from "/src/features/nft-detail/components/ReviewsSkeleton.tsx";
import { ReviewsSummary } from "/src/features/nft-detail/components/ReviewsSummary.tsx";
export function BuyerReviews({ nft }) {
  _s();
  const { query, setPage } = useReviews(nft);
  return /* @__PURE__ */ jsxDEV("section", { className: "space-y-6 py-6", "aria-label": detailMessages.reviews, children: [
    /* @__PURE__ */ jsxDEV(ReviewsSummary, { rating: nft.rating }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/BuyerReviews.tsx",
      lineNumber: 15,
      columnNumber: 7
    }, this),
    query.isPending ? /* @__PURE__ */ jsxDEV(ReviewsSkeleton, {}, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/BuyerReviews.tsx",
      lineNumber: 17,
      columnNumber: 7
    }, this) : query.isError ? /* @__PURE__ */ jsxDEV(
      ErrorState,
      {
        error: query.error,
        retry: () => {
          void query.refetch();
        }
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/BuyerReviews.tsx",
        lineNumber: 19,
        columnNumber: 7
      },
      this
    ) : query.data.items.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "py-8 text-text-secondary", children: "Este NFT ainda não recebeu avaliações." }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/BuyerReviews.tsx",
      lineNumber: 26,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "grid gap-5 md:grid-cols-2", "aria-busy": query.isFetching, children: query.data.items.map(
      (review) => /* @__PURE__ */ jsxDEV(ReviewCard, { review }, review.id, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/BuyerReviews.tsx",
        lineNumber: 30,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/BuyerReviews.tsx",
      lineNumber: 28,
      columnNumber: 7
    }, this),
    query.data && /* @__PURE__ */ jsxDEV(
      ReviewsPagination,
      {
        page: query.data.page,
        pages: query.data.totalPages,
        change: setPage,
        pending: query.isFetching
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/BuyerReviews.tsx",
        lineNumber: 35,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/BuyerReviews.tsx",
    lineNumber: 14,
    columnNumber: 5
  }, this);
}
_s(BuyerReviews, "1ESsSAfTA7FUCPoaG0TOHHh5UT8=", false, function() {
  return [useReviews];
});
_c = BuyerReviews;
var _c;
$RefreshReg$(_c, "BuyerReviews");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/BuyerReviews.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/BuyerReviews.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/BuyerReviews.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY007O0FBZE4sU0FBU0Esa0JBQWtCO0FBRzNCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0Msc0JBQXNCO0FBRXhCLGdCQUFTQyxhQUFhLEVBQUVDLElBQWtCLEdBQUc7QUFBQUMsS0FBQTtBQUNsRCxRQUFNLEVBQUVDLE9BQU9DLFFBQVEsSUFBSVQsV0FBV00sR0FBRztBQUN6QyxTQUNFLHVCQUFDLGFBQVEsV0FBVSxrQkFBaUIsY0FBWVAsZUFBZVcsU0FDN0Q7QUFBQSwyQkFBQyxrQkFBZSxRQUFRSixJQUFJSyxVQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1DO0FBQUEsSUFDbENILE1BQU1JLFlBQ0wsdUJBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnQixJQUNkSixNQUFNSyxVQUNSO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUFPTCxNQUFNTTtBQUFBQSxRQUNiLE9BQU8sTUFBTTtBQUNYLGVBQUtOLE1BQU1PLFFBQVE7QUFBQSxRQUNyQjtBQUFBO0FBQUEsTUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJSSxJQUVGUCxNQUFNUSxLQUFLQyxNQUFNQyxXQUFXLElBQzlCLHVCQUFDLE9BQUUsV0FBVSw0QkFBMkIsc0RBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEUsSUFFOUUsdUJBQUMsU0FBSSxXQUFVLDZCQUE0QixhQUFXVixNQUFNVyxZQUN6RFgsZ0JBQU1RLEtBQUtDLE1BQU1HO0FBQUFBLE1BQUksQ0FBQ0MsV0FDckIsdUJBQUMsY0FBMkIsVUFBWEEsT0FBT0MsSUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyQztBQUFBLElBQzVDLEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsSUFFRGQsTUFBTVEsUUFDTDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTVIsTUFBTVEsS0FBS087QUFBQUEsUUFDakIsT0FBT2YsTUFBTVEsS0FBS1E7QUFBQUEsUUFDbEIsUUFBUWY7QUFBQUEsUUFDUixTQUFTRCxNQUFNVztBQUFBQTtBQUFBQSxNQUpqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJNEI7QUFBQSxPQXpCaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRCQTtBQUVKO0FBQUNaLEdBakNlRixjQUFZO0FBQUEsVUFDQ0wsVUFBVTtBQUFBO0FBQUEsS0FEdkJLO0FBQVksSUFBQW9CO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkVycm9yU3RhdGUiLCJkZXRhaWxNZXNzYWdlcyIsInVzZVJldmlld3MiLCJSZXZpZXdDYXJkIiwiUmV2aWV3c1BhZ2luYXRpb24iLCJSZXZpZXdzU2tlbGV0b24iLCJSZXZpZXdzU3VtbWFyeSIsIkJ1eWVyUmV2aWV3cyIsIm5mdCIsIl9zIiwicXVlcnkiLCJzZXRQYWdlIiwicmV2aWV3cyIsInJhdGluZyIsImlzUGVuZGluZyIsImlzRXJyb3IiLCJlcnJvciIsInJlZmV0Y2giLCJkYXRhIiwiaXRlbXMiLCJsZW5ndGgiLCJpc0ZldGNoaW5nIiwibWFwIiwicmV2aWV3IiwiaWQiLCJwYWdlIiwidG90YWxQYWdlcyIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkJ1eWVyUmV2aWV3cy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRXJyb3JTdGF0ZSB9IGZyb20gJ0AvY29tcG9uZW50cy9mZWVkYmFjay9FcnJvclN0YXRlJztcbmltcG9ydCB0eXBlIHsgTmZ0IH0gZnJvbSAnQC9jb250cmFjdHMvbmZ0JztcblxuaW1wb3J0IHsgZGV0YWlsTWVzc2FnZXMgfSBmcm9tICcuLi9tZXNzYWdlcyc7XG5pbXBvcnQgeyB1c2VSZXZpZXdzIH0gZnJvbSAnLi4vdXNlUmV2aWV3cyc7XG5pbXBvcnQgeyBSZXZpZXdDYXJkIH0gZnJvbSAnLi9SZXZpZXdDYXJkJztcbmltcG9ydCB7IFJldmlld3NQYWdpbmF0aW9uIH0gZnJvbSAnLi9SZXZpZXdzUGFnaW5hdGlvbic7XG5pbXBvcnQgeyBSZXZpZXdzU2tlbGV0b24gfSBmcm9tICcuL1Jldmlld3NTa2VsZXRvbic7XG5pbXBvcnQgeyBSZXZpZXdzU3VtbWFyeSB9IGZyb20gJy4vUmV2aWV3c1N1bW1hcnknO1xuXG5leHBvcnQgZnVuY3Rpb24gQnV5ZXJSZXZpZXdzKHsgbmZ0IH06IHsgbmZ0OiBOZnQgfSkge1xuICBjb25zdCB7IHF1ZXJ5LCBzZXRQYWdlIH0gPSB1c2VSZXZpZXdzKG5mdCk7XG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic3BhY2UteS02IHB5LTZcIiBhcmlhLWxhYmVsPXtkZXRhaWxNZXNzYWdlcy5yZXZpZXdzfT5cbiAgICAgIDxSZXZpZXdzU3VtbWFyeSByYXRpbmc9e25mdC5yYXRpbmd9IC8+XG4gICAgICB7cXVlcnkuaXNQZW5kaW5nID8gKFxuICAgICAgICA8UmV2aWV3c1NrZWxldG9uIC8+XG4gICAgICApIDogcXVlcnkuaXNFcnJvciA/IChcbiAgICAgICAgPEVycm9yU3RhdGVcbiAgICAgICAgICBlcnJvcj17cXVlcnkuZXJyb3J9XG4gICAgICAgICAgcmV0cnk9eygpID0+IHtcbiAgICAgICAgICAgIHZvaWQgcXVlcnkucmVmZXRjaCgpO1xuICAgICAgICAgIH19XG4gICAgICAgIC8+XG4gICAgICApIDogcXVlcnkuZGF0YS5pdGVtcy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInB5LTggdGV4dC10ZXh0LXNlY29uZGFyeVwiPkVzdGUgTkZUIGFpbmRhIG7Do28gcmVjZWJldSBhdmFsaWHDp8O1ZXMuPC9wPlxuICAgICAgKSA6IChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC01IG1kOmdyaWQtY29scy0yXCIgYXJpYS1idXN5PXtxdWVyeS5pc0ZldGNoaW5nfT5cbiAgICAgICAgICB7cXVlcnkuZGF0YS5pdGVtcy5tYXAoKHJldmlldykgPT4gKFxuICAgICAgICAgICAgPFJldmlld0NhcmQga2V5PXtyZXZpZXcuaWR9IHJldmlldz17cmV2aWV3fSAvPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgICB7cXVlcnkuZGF0YSAmJiAoXG4gICAgICAgIDxSZXZpZXdzUGFnaW5hdGlvblxuICAgICAgICAgIHBhZ2U9e3F1ZXJ5LmRhdGEucGFnZX1cbiAgICAgICAgICBwYWdlcz17cXVlcnkuZGF0YS50b3RhbFBhZ2VzfVxuICAgICAgICAgIGNoYW5nZT17c2V0UGFnZX1cbiAgICAgICAgICBwZW5kaW5nPXtxdWVyeS5pc0ZldGNoaW5nfVxuICAgICAgICAvPlxuICAgICAgKX1cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9maWxpcGVjYXZhbGNhbnRlL0RvY3VtZW50cy9KdW5nbGVHYW1pbmdUZXN0ZS9zcmMvZmVhdHVyZXMvbmZ0LWRldGFpbC9jb21wb25lbnRzL0J1eWVyUmV2aWV3cy50c3gifQ==