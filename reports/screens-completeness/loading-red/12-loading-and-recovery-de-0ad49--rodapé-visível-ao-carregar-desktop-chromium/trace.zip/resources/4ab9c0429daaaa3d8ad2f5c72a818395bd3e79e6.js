import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/QuantityStepper.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { QuantityButton } from "/src/features/nft-detail/components/QuantityButton.tsx";
import { QuantityInput } from "/src/features/nft-detail/components/QuantityInput.tsx";
export function QuantityStepper({
  value,
  max,
  onChange,
  disabled = false,
  tone = "purchase",
  onRemove
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: "inline-flex items-center", children: [
    /* @__PURE__ */ jsxDEV(
      QuantityButton,
      {
        decrease: true,
        tone,
        disabled: disabled || value <= 1 && !onRemove,
        change: () => {
          if (value <= 1 && onRemove) onRemove();
          else
            onChange(value - 1);
        }
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/QuantityStepper.tsx",
        lineNumber: 22,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(QuantityInput, { value, max, disabled, tone, onChange }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/QuantityStepper.tsx",
      lineNumber: 31,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      QuantityButton,
      {
        tone,
        disabled: disabled || value >= max,
        change: () => {
          onChange(value + 1);
        }
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/QuantityStepper.tsx",
        lineNumber: 32,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/QuantityStepper.tsx",
    lineNumber: 21,
    columnNumber: 5
  }, this);
}
_c = QuantityStepper;
var _c;
$RefreshReg$(_c, "QuantityStepper");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/QuantityStepper.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/QuantityStepper.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/QuantityStepper.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJNO0FBckJOLFNBQVNBLHNCQUFzQjtBQUMvQixTQUFTQyxxQkFBcUI7QUFVdkIsZ0JBQVNDLGdCQUFnQjtBQUFBLEVBQzlCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxXQUFXO0FBQUEsRUFDWEMsT0FBTztBQUFBLEVBQ1BDO0FBQ29CLEdBQUc7QUFDdkIsU0FDRSx1QkFBQyxTQUFJLFdBQVUsNEJBQ2I7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBO0FBQUEsUUFDQSxVQUFVRixZQUFhSCxTQUFTLEtBQUssQ0FBQ0s7QUFBQUEsUUFDdEMsUUFBUSxNQUFNO0FBQ1osY0FBSUwsU0FBUyxLQUFLSyxTQUFVQSxVQUFTO0FBQUE7QUFDaENILHFCQUFTRixRQUFRLENBQUM7QUFBQSxRQUN6QjtBQUFBO0FBQUEsTUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFPSTtBQUFBLElBRUosdUJBQUMsaUJBQWMsT0FBYyxLQUFVLFVBQW9CLE1BQVksWUFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwRjtBQUFBLElBQzFGO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0EsVUFBVUcsWUFBWUgsU0FBU0M7QUFBQUEsUUFDL0IsUUFBUSxNQUFNO0FBQ1pDLG1CQUFTRixRQUFRLENBQUM7QUFBQSxRQUNwQjtBQUFBO0FBQUEsTUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFLSTtBQUFBLE9BaEJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrQkE7QUFFSjtBQUFDTSxLQTdCZVA7QUFBZSxJQUFBTztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJRdWFudGl0eUJ1dHRvbiIsIlF1YW50aXR5SW5wdXQiLCJRdWFudGl0eVN0ZXBwZXIiLCJ2YWx1ZSIsIm1heCIsIm9uQ2hhbmdlIiwiZGlzYWJsZWQiLCJ0b25lIiwib25SZW1vdmUiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJRdWFudGl0eVN0ZXBwZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFF1YW50aXR5QnV0dG9uIH0gZnJvbSAnLi9RdWFudGl0eUJ1dHRvbic7XG5pbXBvcnQgeyBRdWFudGl0eUlucHV0IH0gZnJvbSAnLi9RdWFudGl0eUlucHV0JztcblxuZXhwb3J0IGludGVyZmFjZSBRdWFudGl0eVN0ZXBwZXJQcm9wcyB7XG4gIHZhbHVlOiBudW1iZXI7XG4gIG1heDogbnVtYmVyO1xuICBkaXNhYmxlZD86IGJvb2xlYW47XG4gIHRvbmU/OiAncHVyY2hhc2UnIHwgJ2NhcnQnO1xuICBvbkNoYW5nZTogKHF1YW50aXR5OiBudW1iZXIpID0+IHZvaWQ7XG4gIG9uUmVtb3ZlPzogKCkgPT4gdm9pZDtcbn1cbmV4cG9ydCBmdW5jdGlvbiBRdWFudGl0eVN0ZXBwZXIoe1xuICB2YWx1ZSxcbiAgbWF4LFxuICBvbkNoYW5nZSxcbiAgZGlzYWJsZWQgPSBmYWxzZSxcbiAgdG9uZSA9ICdwdXJjaGFzZScsXG4gIG9uUmVtb3ZlLFxufTogUXVhbnRpdHlTdGVwcGVyUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlclwiPlxuICAgICAgPFF1YW50aXR5QnV0dG9uXG4gICAgICAgIGRlY3JlYXNlXG4gICAgICAgIHRvbmU9e3RvbmV9XG4gICAgICAgIGRpc2FibGVkPXtkaXNhYmxlZCB8fCAodmFsdWUgPD0gMSAmJiAhb25SZW1vdmUpfVxuICAgICAgICBjaGFuZ2U9eygpID0+IHtcbiAgICAgICAgICBpZiAodmFsdWUgPD0gMSAmJiBvblJlbW92ZSkgb25SZW1vdmUoKTtcbiAgICAgICAgICBlbHNlIG9uQ2hhbmdlKHZhbHVlIC0gMSk7XG4gICAgICAgIH19XG4gICAgICAvPlxuICAgICAgPFF1YW50aXR5SW5wdXQgdmFsdWU9e3ZhbHVlfSBtYXg9e21heH0gZGlzYWJsZWQ9e2Rpc2FibGVkfSB0b25lPXt0b25lfSBvbkNoYW5nZT17b25DaGFuZ2V9IC8+XG4gICAgICA8UXVhbnRpdHlCdXR0b25cbiAgICAgICAgdG9uZT17dG9uZX1cbiAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkIHx8IHZhbHVlID49IG1heH1cbiAgICAgICAgY2hhbmdlPXsoKSA9PiB7XG4gICAgICAgICAgb25DaGFuZ2UodmFsdWUgKyAxKTtcbiAgICAgICAgfX1cbiAgICAgIC8+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9maWxpcGVjYXZhbGNhbnRlL0RvY3VtZW50cy9KdW5nbGVHYW1pbmdUZXN0ZS9zcmMvZmVhdHVyZXMvbmZ0LWRldGFpbC9jb21wb25lbnRzL1F1YW50aXR5U3RlcHBlci50c3gifQ==