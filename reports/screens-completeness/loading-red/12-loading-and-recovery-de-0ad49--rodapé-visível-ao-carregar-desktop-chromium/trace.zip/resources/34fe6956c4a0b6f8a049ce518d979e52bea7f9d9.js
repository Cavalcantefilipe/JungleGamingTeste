import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/tabs.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { cva } from "/node_modules/.vite/deps/class-variance-authority.js?v=970a124b";
import { Tabs as TabsPrimitive } from "/node_modules/.vite/deps/radix-ui.js?v=970a124b";
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=970a124b"; const React = ((m) => m?.__esModule ? m : {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m})(__vite__cjsImport3_react);
import { cn } from "/src/lib/cn.ts";
function Tabs({
  className,
  orientation = "horizontal",
  ...props
}) {
  return /* @__PURE__ */ jsxDEV(
    TabsPrimitive.Root,
    {
      "data-slot": "tabs",
      "data-orientation": orientation,
      orientation,
      className: cn("group/tabs flex gap-2 data-[orientation=horizontal]:flex-col", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/tabs.tsx",
      lineNumber: 13,
      columnNumber: 5
    },
    this
  );
}
_c = Tabs;
const tabsListVariants = cva(
  "group/tabs-list inline-flex w-fit items-center justify-center rounded-lg p-[3px] text-muted-foreground group-data-[orientation=horizontal]/tabs:h-9 group-data-[orientation=vertical]/tabs:h-fit group-data-[orientation=vertical]/tabs:flex-col data-[variant=line]:rounded-none",
  {
    variants: {
      variant: {
        default: "bg-muted",
        line: "gap-1 bg-transparent"
      }
    },
    defaultVariants: {
      variant: "default"
    }
  }
);
function TabsList({
  className,
  variant = "default",
  ...props
}) {
  return /* @__PURE__ */ jsxDEV(
    TabsPrimitive.List,
    {
      "data-slot": "tabs-list",
      "data-variant": variant,
      className: cn(tabsListVariants({ variant }), className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/tabs.tsx",
      lineNumber: 44,
      columnNumber: 5
    },
    this
  );
}
_c2 = TabsList;
function TabsTrigger({ className, ...props }) {
  return /* @__PURE__ */ jsxDEV(
    TabsPrimitive.Trigger,
    {
      "data-slot": "tabs-trigger",
      className: cn(
        "relative inline-flex h-[calc(100%-1px)] flex-1 items-center justify-center gap-1.5 rounded-md border border-transparent px-2 py-1 text-sm font-medium whitespace-nowrap text-foreground/60 transition-all group-data-[orientation=vertical]/tabs:w-full group-data-[orientation=vertical]/tabs:justify-start hover:text-foreground focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 focus-visible:outline-1 focus-visible:outline-ring disabled:pointer-events-none disabled:opacity-50 group-data-[variant=default]/tabs-list:data-[state=active]:shadow-sm group-data-[variant=line]/tabs-list:data-[state=active]:shadow-none dark:text-muted-foreground dark:hover:text-foreground [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
        "group-data-[variant=line]/tabs-list:bg-transparent group-data-[variant=line]/tabs-list:data-[state=active]:bg-transparent dark:group-data-[variant=line]/tabs-list:data-[state=active]:border-transparent dark:group-data-[variant=line]/tabs-list:data-[state=active]:bg-transparent",
        "data-[state=active]:bg-background data-[state=active]:text-foreground dark:data-[state=active]:border-input dark:data-[state=active]:bg-input/30 dark:data-[state=active]:text-foreground",
        "after:absolute after:bg-foreground after:opacity-0 after:transition-opacity group-data-[orientation=horizontal]/tabs:after:inset-x-0 group-data-[orientation=horizontal]/tabs:after:bottom-[-5px] group-data-[orientation=horizontal]/tabs:after:h-0.5 group-data-[orientation=vertical]/tabs:after:inset-y-0 group-data-[orientation=vertical]/tabs:after:-right-1 group-data-[orientation=vertical]/tabs:after:w-0.5 group-data-[variant=line]/tabs-list:data-[state=active]:after:opacity-100",
        className
      ),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/tabs.tsx",
      lineNumber: 55,
      columnNumber: 5
    },
    this
  );
}
_c3 = TabsTrigger;
function TabsContent({ className, ...props }) {
  return /* @__PURE__ */ jsxDEV(
    TabsPrimitive.Content,
    {
      "data-slot": "tabs-content",
      className: cn("flex-1 outline-none", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/tabs.tsx",
      lineNumber: 71,
      columnNumber: 5
    },
    this
  );
}
_c4 = TabsContent;
export { Tabs, TabsList, TabsTrigger, TabsContent, tabsListVariants };
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "Tabs");
$RefreshReg$(_c2, "TabsList");
$RefreshReg$(_c3, "TabsTrigger");
$RefreshReg$(_c4, "TabsContent");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/tabs.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/tabs.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/tabs.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWUk7QUFaSixTQUFTQSxXQUE4QjtBQUN2QyxTQUFTQyxRQUFRQyxxQkFBcUI7QUFDdEMsWUFBWUMsV0FBVztBQUV2QixTQUFTQyxVQUFVO0FBRW5CLFNBQVNILEtBQUs7QUFBQSxFQUNaSTtBQUFBQSxFQUNBQyxjQUFjO0FBQUEsRUFDZCxHQUFHQztBQUM0QyxHQUFHO0FBQ2xELFNBQ0U7QUFBQSxJQUFDLGNBQWM7QUFBQSxJQUFkO0FBQUEsTUFDQyxhQUFVO0FBQUEsTUFDVixvQkFBa0JEO0FBQUFBLE1BQ2xCO0FBQUEsTUFDQSxXQUFXRixHQUFHLGdFQUFnRUMsU0FBUztBQUFBLE1BQ3ZGLEdBQUlFO0FBQUFBO0FBQUFBLElBTE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS1k7QUFHaEI7QUFBQ0MsS0FkUVA7QUFnQlQsTUFBTVEsbUJBQW1CVDtBQUFBQSxFQUN2QjtBQUFBLEVBQ0E7QUFBQSxJQUNFVSxVQUFVO0FBQUEsTUFDUkMsU0FBUztBQUFBLFFBQ1BDLFNBQVM7QUFBQSxRQUNUQyxNQUFNO0FBQUEsTUFDUjtBQUFBLElBQ0Y7QUFBQSxJQUNBQyxpQkFBaUI7QUFBQSxNQUNmSCxTQUFTO0FBQUEsSUFDWDtBQUFBLEVBQ0Y7QUFDRjtBQUVBLFNBQVNJLFNBQVM7QUFBQSxFQUNoQlY7QUFBQUEsRUFDQU0sVUFBVTtBQUFBLEVBQ1YsR0FBR0o7QUFDb0YsR0FBRztBQUMxRixTQUNFO0FBQUEsSUFBQyxjQUFjO0FBQUEsSUFBZDtBQUFBLE1BQ0MsYUFBVTtBQUFBLE1BQ1YsZ0JBQWNJO0FBQUFBLE1BQ2QsV0FBV1AsR0FBR0ssaUJBQWlCLEVBQUVFLFFBQVEsQ0FBQyxHQUFHTixTQUFTO0FBQUEsTUFDdEQsR0FBSUU7QUFBQUE7QUFBQUEsSUFKTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJWTtBQUdoQjtBQUFDUyxNQWJRRDtBQWVULFNBQVNFLFlBQVksRUFBRVosV0FBVyxHQUFHRSxNQUEwRCxHQUFHO0FBQ2hHLFNBQ0U7QUFBQSxJQUFDLGNBQWM7QUFBQSxJQUFkO0FBQUEsTUFDQyxhQUFVO0FBQUEsTUFDVixXQUFXSDtBQUFBQSxRQUNUO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQUM7QUFBQUEsTUFDRjtBQUFBLE1BQ0EsR0FBSUU7QUFBQUE7QUFBQUEsSUFUTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFTWTtBQUdoQjtBQUFDVyxNQWRRRDtBQWdCVCxTQUFTRSxZQUFZLEVBQUVkLFdBQVcsR0FBR0UsTUFBMEQsR0FBRztBQUNoRyxTQUNFO0FBQUEsSUFBQyxjQUFjO0FBQUEsSUFBZDtBQUFBLE1BQ0MsYUFBVTtBQUFBLE1BQ1YsV0FBV0gsR0FBRyx1QkFBdUJDLFNBQVM7QUFBQSxNQUM5QyxHQUFJRTtBQUFBQTtBQUFBQSxJQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUdZO0FBR2hCO0FBQUNhLE1BUlFEO0FBVVQsU0FBU2xCLE1BQU1jLFVBQVVFLGFBQWFFLGFBQWFWO0FBQW1CLElBQUFELElBQUFRLEtBQUFFLEtBQUFFO0FBQUEsYUFBQVosSUFBQTtBQUFBLGFBQUFRLEtBQUE7QUFBQSxhQUFBRSxLQUFBO0FBQUEsYUFBQUUsS0FBQSIsIm5hbWVzIjpbImN2YSIsIlRhYnMiLCJUYWJzUHJpbWl0aXZlIiwiUmVhY3QiLCJjbiIsImNsYXNzTmFtZSIsIm9yaWVudGF0aW9uIiwicHJvcHMiLCJfYyIsInRhYnNMaXN0VmFyaWFudHMiLCJ2YXJpYW50cyIsInZhcmlhbnQiLCJkZWZhdWx0IiwibGluZSIsImRlZmF1bHRWYXJpYW50cyIsIlRhYnNMaXN0IiwiX2MyIiwiVGFic1RyaWdnZXIiLCJfYzMiLCJUYWJzQ29udGVudCIsIl9jNCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJ0YWJzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjdmEsIHR5cGUgVmFyaWFudFByb3BzIH0gZnJvbSAnY2xhc3MtdmFyaWFuY2UtYXV0aG9yaXR5JztcbmltcG9ydCB7IFRhYnMgYXMgVGFic1ByaW1pdGl2ZSB9IGZyb20gJ3JhZGl4LXVpJztcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcblxuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi9jbic7XG5cbmZ1bmN0aW9uIFRhYnMoe1xuICBjbGFzc05hbWUsXG4gIG9yaWVudGF0aW9uID0gJ2hvcml6b250YWwnLFxuICAuLi5wcm9wc1xufTogUmVhY3QuQ29tcG9uZW50UHJvcHM8dHlwZW9mIFRhYnNQcmltaXRpdmUuUm9vdD4pIHtcbiAgcmV0dXJuIChcbiAgICA8VGFic1ByaW1pdGl2ZS5Sb290XG4gICAgICBkYXRhLXNsb3Q9XCJ0YWJzXCJcbiAgICAgIGRhdGEtb3JpZW50YXRpb249e29yaWVudGF0aW9ufVxuICAgICAgb3JpZW50YXRpb249e29yaWVudGF0aW9ufVxuICAgICAgY2xhc3NOYW1lPXtjbignZ3JvdXAvdGFicyBmbGV4IGdhcC0yIGRhdGEtW29yaWVudGF0aW9uPWhvcml6b250YWxdOmZsZXgtY29sJywgY2xhc3NOYW1lKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApO1xufVxuXG5jb25zdCB0YWJzTGlzdFZhcmlhbnRzID0gY3ZhKFxuICAnZ3JvdXAvdGFicy1saXN0IGlubGluZS1mbGV4IHctZml0IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWxnIHAtWzNweF0gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGdyb3VwLWRhdGEtW29yaWVudGF0aW9uPWhvcml6b250YWxdL3RhYnM6aC05IGdyb3VwLWRhdGEtW29yaWVudGF0aW9uPXZlcnRpY2FsXS90YWJzOmgtZml0IGdyb3VwLWRhdGEtW29yaWVudGF0aW9uPXZlcnRpY2FsXS90YWJzOmZsZXgtY29sIGRhdGEtW3ZhcmlhbnQ9bGluZV06cm91bmRlZC1ub25lJyxcbiAge1xuICAgIHZhcmlhbnRzOiB7XG4gICAgICB2YXJpYW50OiB7XG4gICAgICAgIGRlZmF1bHQ6ICdiZy1tdXRlZCcsXG4gICAgICAgIGxpbmU6ICdnYXAtMSBiZy10cmFuc3BhcmVudCcsXG4gICAgICB9LFxuICAgIH0sXG4gICAgZGVmYXVsdFZhcmlhbnRzOiB7XG4gICAgICB2YXJpYW50OiAnZGVmYXVsdCcsXG4gICAgfSxcbiAgfSxcbik7XG5cbmZ1bmN0aW9uIFRhYnNMaXN0KHtcbiAgY2xhc3NOYW1lLFxuICB2YXJpYW50ID0gJ2RlZmF1bHQnLFxuICAuLi5wcm9wc1xufTogUmVhY3QuQ29tcG9uZW50UHJvcHM8dHlwZW9mIFRhYnNQcmltaXRpdmUuTGlzdD4gJiBWYXJpYW50UHJvcHM8dHlwZW9mIHRhYnNMaXN0VmFyaWFudHM+KSB7XG4gIHJldHVybiAoXG4gICAgPFRhYnNQcmltaXRpdmUuTGlzdFxuICAgICAgZGF0YS1zbG90PVwidGFicy1saXN0XCJcbiAgICAgIGRhdGEtdmFyaWFudD17dmFyaWFudH1cbiAgICAgIGNsYXNzTmFtZT17Y24odGFic0xpc3RWYXJpYW50cyh7IHZhcmlhbnQgfSksIGNsYXNzTmFtZSl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgKTtcbn1cblxuZnVuY3Rpb24gVGFic1RyaWdnZXIoeyBjbGFzc05hbWUsIC4uLnByb3BzIH06IFJlYWN0LkNvbXBvbmVudFByb3BzPHR5cGVvZiBUYWJzUHJpbWl0aXZlLlRyaWdnZXI+KSB7XG4gIHJldHVybiAoXG4gICAgPFRhYnNQcmltaXRpdmUuVHJpZ2dlclxuICAgICAgZGF0YS1zbG90PVwidGFicy10cmlnZ2VyXCJcbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwicmVsYXRpdmUgaW5saW5lLWZsZXggaC1bY2FsYygxMDAlLTFweCldIGZsZXgtMSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcHgtMiBweS0xIHRleHQtc20gZm9udC1tZWRpdW0gd2hpdGVzcGFjZS1ub3dyYXAgdGV4dC1mb3JlZ3JvdW5kLzYwIHRyYW5zaXRpb24tYWxsIGdyb3VwLWRhdGEtW29yaWVudGF0aW9uPXZlcnRpY2FsXS90YWJzOnctZnVsbCBncm91cC1kYXRhLVtvcmllbnRhdGlvbj12ZXJ0aWNhbF0vdGFiczpqdXN0aWZ5LXN0YXJ0IGhvdmVyOnRleHQtZm9yZWdyb3VuZCBmb2N1cy12aXNpYmxlOmJvcmRlci1yaW5nIGZvY3VzLXZpc2libGU6cmluZy1bM3B4XSBmb2N1cy12aXNpYmxlOnJpbmctcmluZy81MCBmb2N1cy12aXNpYmxlOm91dGxpbmUtMSBmb2N1cy12aXNpYmxlOm91dGxpbmUtcmluZyBkaXNhYmxlZDpwb2ludGVyLWV2ZW50cy1ub25lIGRpc2FibGVkOm9wYWNpdHktNTAgZ3JvdXAtZGF0YS1bdmFyaWFudD1kZWZhdWx0XS90YWJzLWxpc3Q6ZGF0YS1bc3RhdGU9YWN0aXZlXTpzaGFkb3ctc20gZ3JvdXAtZGF0YS1bdmFyaWFudD1saW5lXS90YWJzLWxpc3Q6ZGF0YS1bc3RhdGU9YWN0aXZlXTpzaGFkb3ctbm9uZSBkYXJrOnRleHQtbXV0ZWQtZm9yZWdyb3VuZCBkYXJrOmhvdmVyOnRleHQtZm9yZWdyb3VuZCBbJl9zdmddOnBvaW50ZXItZXZlbnRzLW5vbmUgWyZfc3ZnXTpzaHJpbmstMCBbJl9zdmc6bm90KFtjbGFzcyo9J3NpemUtJ10pXTpzaXplLTRcIixcbiAgICAgICAgJ2dyb3VwLWRhdGEtW3ZhcmlhbnQ9bGluZV0vdGFicy1saXN0OmJnLXRyYW5zcGFyZW50IGdyb3VwLWRhdGEtW3ZhcmlhbnQ9bGluZV0vdGFicy1saXN0OmRhdGEtW3N0YXRlPWFjdGl2ZV06YmctdHJhbnNwYXJlbnQgZGFyazpncm91cC1kYXRhLVt2YXJpYW50PWxpbmVdL3RhYnMtbGlzdDpkYXRhLVtzdGF0ZT1hY3RpdmVdOmJvcmRlci10cmFuc3BhcmVudCBkYXJrOmdyb3VwLWRhdGEtW3ZhcmlhbnQ9bGluZV0vdGFicy1saXN0OmRhdGEtW3N0YXRlPWFjdGl2ZV06YmctdHJhbnNwYXJlbnQnLFxuICAgICAgICAnZGF0YS1bc3RhdGU9YWN0aXZlXTpiZy1iYWNrZ3JvdW5kIGRhdGEtW3N0YXRlPWFjdGl2ZV06dGV4dC1mb3JlZ3JvdW5kIGRhcms6ZGF0YS1bc3RhdGU9YWN0aXZlXTpib3JkZXItaW5wdXQgZGFyazpkYXRhLVtzdGF0ZT1hY3RpdmVdOmJnLWlucHV0LzMwIGRhcms6ZGF0YS1bc3RhdGU9YWN0aXZlXTp0ZXh0LWZvcmVncm91bmQnLFxuICAgICAgICAnYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6YmctZm9yZWdyb3VuZCBhZnRlcjpvcGFjaXR5LTAgYWZ0ZXI6dHJhbnNpdGlvbi1vcGFjaXR5IGdyb3VwLWRhdGEtW29yaWVudGF0aW9uPWhvcml6b250YWxdL3RhYnM6YWZ0ZXI6aW5zZXQteC0wIGdyb3VwLWRhdGEtW29yaWVudGF0aW9uPWhvcml6b250YWxdL3RhYnM6YWZ0ZXI6Ym90dG9tLVstNXB4XSBncm91cC1kYXRhLVtvcmllbnRhdGlvbj1ob3Jpem9udGFsXS90YWJzOmFmdGVyOmgtMC41IGdyb3VwLWRhdGEtW29yaWVudGF0aW9uPXZlcnRpY2FsXS90YWJzOmFmdGVyOmluc2V0LXktMCBncm91cC1kYXRhLVtvcmllbnRhdGlvbj12ZXJ0aWNhbF0vdGFiczphZnRlcjotcmlnaHQtMSBncm91cC1kYXRhLVtvcmllbnRhdGlvbj12ZXJ0aWNhbF0vdGFiczphZnRlcjp3LTAuNSBncm91cC1kYXRhLVt2YXJpYW50PWxpbmVdL3RhYnMtbGlzdDpkYXRhLVtzdGF0ZT1hY3RpdmVdOmFmdGVyOm9wYWNpdHktMTAwJyxcbiAgICAgICAgY2xhc3NOYW1lLFxuICAgICAgKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApO1xufVxuXG5mdW5jdGlvbiBUYWJzQ29udGVudCh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfTogUmVhY3QuQ29tcG9uZW50UHJvcHM8dHlwZW9mIFRhYnNQcmltaXRpdmUuQ29udGVudD4pIHtcbiAgcmV0dXJuIChcbiAgICA8VGFic1ByaW1pdGl2ZS5Db250ZW50XG4gICAgICBkYXRhLXNsb3Q9XCJ0YWJzLWNvbnRlbnRcIlxuICAgICAgY2xhc3NOYW1lPXtjbignZmxleC0xIG91dGxpbmUtbm9uZScsIGNsYXNzTmFtZSl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgKTtcbn1cblxuZXhwb3J0IHsgVGFicywgVGFic0xpc3QsIFRhYnNUcmlnZ2VyLCBUYWJzQ29udGVudCwgdGFic0xpc3RWYXJpYW50cyB9O1xuIl0sImZpbGUiOiIvVXNlcnMvZmlsaXBlY2F2YWxjYW50ZS9Eb2N1bWVudHMvSnVuZ2xlR2FtaW5nVGVzdGUvc3JjL2NvbXBvbmVudHMvdWkvdGFicy50c3gifQ==