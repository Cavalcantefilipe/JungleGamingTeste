import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/MobilePurchaseBar.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { formatEth } from "/src/lib/money.ts";
import { PurchaseActions } from "/src/features/nft-detail/components/PurchaseActions.tsx";
import { QuantityStepper } from "/src/features/nft-detail/components/QuantityStepper.tsx";
export function MobilePurchaseBar({
  nft,
  quantity,
  available,
  setQuantity,
  actions
}) {
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      "data-testid": "mobile-purchase-bar",
      className: "fixed inset-x-0 bottom-0 z-40 space-y-3 rounded-t-[32px] bg-surface-card p-6 pt-3.5 pb-[max(34px,env(safe-area-inset-bottom))] lg:hidden",
      children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-text-secondary", children: "Qtd." }, void 0, false, {
              fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/MobilePurchaseBar.tsx",
              lineNumber: 27,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(QuantityStepper, { value: quantity, max: available, onChange: setQuantity }, void 0, false, {
              fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/MobilePurchaseBar.tsx",
              lineNumber: 28,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/MobilePurchaseBar.tsx",
            lineNumber: 26,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-bold whitespace-nowrap text-text-accent", children: formatEth(nft.price) }, void 0, false, {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/MobilePurchaseBar.tsx",
            lineNumber: 30,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/MobilePurchaseBar.tsx",
          lineNumber: 25,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: /* @__PURE__ */ jsxDEV(PurchaseActions, { ...actions }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/MobilePurchaseBar.tsx",
          lineNumber: 35,
          columnNumber: 9
        }, this) }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/MobilePurchaseBar.tsx",
          lineNumber: 34,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/MobilePurchaseBar.tsx",
      lineNumber: 21,
      columnNumber: 5
    },
    this
  );
}
_c = MobilePurchaseBar;
var _c;
$RefreshReg$(_c, "MobilePurchaseBar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/MobilePurchaseBar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/MobilePurchaseBar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/MobilePurchaseBar.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEJVO0FBekJWLFNBQVNBLGlCQUFpQjtBQUUxQixTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsdUJBQXVCO0FBUXpCLGdCQUFTQyxrQkFBa0I7QUFBQSxFQUNoQ0M7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDc0IsR0FBRztBQUN6QixTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxlQUFZO0FBQUEsTUFDWixXQUFVO0FBQUEsTUFFVjtBQUFBLCtCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLG1DQUFDLFVBQUssV0FBVSwrQkFBOEIsb0JBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtEO0FBQUEsWUFDbEQsdUJBQUMsbUJBQWdCLE9BQU9ILFVBQVUsS0FBS0MsV0FBVyxVQUFVQyxlQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RTtBQUFBLGVBRjFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSx3REFDYlAsb0JBQVVJLElBQUlLLEtBQUssS0FEdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYixpQ0FBQyxtQkFBZ0IsR0FBSUQsV0FBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2QixLQUQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQTtBQUFBO0FBQUEsSUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFnQkE7QUFFSjtBQUFDRSxLQTFCZVA7QUFBaUIsSUFBQU87QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiZm9ybWF0RXRoIiwiUHVyY2hhc2VBY3Rpb25zIiwiUXVhbnRpdHlTdGVwcGVyIiwiTW9iaWxlUHVyY2hhc2VCYXIiLCJuZnQiLCJxdWFudGl0eSIsImF2YWlsYWJsZSIsInNldFF1YW50aXR5IiwiYWN0aW9ucyIsInByaWNlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTW9iaWxlUHVyY2hhc2VCYXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgTmZ0IH0gZnJvbSAnQC9jb250cmFjdHMvbmZ0JztcbmltcG9ydCB7IGZvcm1hdEV0aCB9IGZyb20gJ0AvbGliL21vbmV5JztcblxuaW1wb3J0IHsgUHVyY2hhc2VBY3Rpb25zIH0gZnJvbSAnLi9QdXJjaGFzZUFjdGlvbnMnO1xuaW1wb3J0IHsgUXVhbnRpdHlTdGVwcGVyIH0gZnJvbSAnLi9RdWFudGl0eVN0ZXBwZXInO1xuXG5pbXBvcnQgdHlwZSB7IHVzZVB1cmNoYXNlU2VsZWN0aW9uIH0gZnJvbSAnLi4vdXNlUHVyY2hhc2VTZWxlY3Rpb24nO1xuXG50eXBlIE1vYmlsZVB1cmNoYXNlQmFyUHJvcHMgPSBQaWNrPFxuICBSZXR1cm5UeXBlPHR5cGVvZiB1c2VQdXJjaGFzZVNlbGVjdGlvbj4sXG4gICdxdWFudGl0eScgfCAnYXZhaWxhYmxlJyB8ICdzZXRRdWFudGl0eScgfCAnYWN0aW9ucydcbj4gJiB7IG5mdDogTmZ0IH07XG5leHBvcnQgZnVuY3Rpb24gTW9iaWxlUHVyY2hhc2VCYXIoe1xuICBuZnQsXG4gIHF1YW50aXR5LFxuICBhdmFpbGFibGUsXG4gIHNldFF1YW50aXR5LFxuICBhY3Rpb25zLFxufTogTW9iaWxlUHVyY2hhc2VCYXJQcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGRhdGEtdGVzdGlkPVwibW9iaWxlLXB1cmNoYXNlLWJhclwiXG4gICAgICBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC14LTAgYm90dG9tLTAgei00MCBzcGFjZS15LTMgcm91bmRlZC10LVszMnB4XSBiZy1zdXJmYWNlLWNhcmQgcC02IHB0LTMuNSBwYi1bbWF4KDM0cHgsZW52KHNhZmUtYXJlYS1pbnNldC1ib3R0b20pKV0gbGc6aGlkZGVuXCJcbiAgICA+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMlwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+UXRkLjwvc3Bhbj5cbiAgICAgICAgICA8UXVhbnRpdHlTdGVwcGVyIHZhbHVlPXtxdWFudGl0eX0gbWF4PXthdmFpbGFibGV9IG9uQ2hhbmdlPXtzZXRRdWFudGl0eX0gLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHdoaXRlc3BhY2Utbm93cmFwIHRleHQtdGV4dC1hY2NlbnRcIj5cbiAgICAgICAgICB7Zm9ybWF0RXRoKG5mdC5wcmljZSl9XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0zXCI+XG4gICAgICAgIDxQdXJjaGFzZUFjdGlvbnMgey4uLmFjdGlvbnN9IC8+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2ZpbGlwZWNhdmFsY2FudGUvRG9jdW1lbnRzL0p1bmdsZUdhbWluZ1Rlc3RlL3NyYy9mZWF0dXJlcy9uZnQtZGV0YWlsL2NvbXBvbmVudHMvTW9iaWxlUHVyY2hhc2VCYXIudHN4In0=