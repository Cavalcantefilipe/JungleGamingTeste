import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/dialog.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Dialog as DialogPrimitive } from "/node_modules/.vite/deps/radix-ui.js?v=970a124b";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=970a124b"; const React = ((m) => m?.__esModule ? m : {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m})(__vite__cjsImport2_react);
import { FigmaIcon } from "/src/components/icons/FigmaIcon.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { cn } from "/src/lib/cn.ts";
function Dialog({ ...props }) {
  return /* @__PURE__ */ jsxDEV(DialogPrimitive.Root, { "data-slot": "dialog", ...props }, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/dialog.tsx",
    lineNumber: 9,
    columnNumber: 10
  }, this);
}
_c = Dialog;
function DialogTrigger({ ...props }) {
  return /* @__PURE__ */ jsxDEV(DialogPrimitive.Trigger, { "data-slot": "dialog-trigger", ...props }, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/dialog.tsx",
    lineNumber: 13,
    columnNumber: 10
  }, this);
}
_c2 = DialogTrigger;
function DialogPortal({ ...props }) {
  return /* @__PURE__ */ jsxDEV(DialogPrimitive.Portal, { "data-slot": "dialog-portal", ...props }, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/dialog.tsx",
    lineNumber: 17,
    columnNumber: 10
  }, this);
}
_c3 = DialogPortal;
function DialogClose({ ...props }) {
  return /* @__PURE__ */ jsxDEV(DialogPrimitive.Close, { "data-slot": "dialog-close", ...props }, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/dialog.tsx",
    lineNumber: 21,
    columnNumber: 10
  }, this);
}
_c4 = DialogClose;
function DialogOverlay({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsxDEV(
    DialogPrimitive.Overlay,
    {
      "data-slot": "dialog-overlay",
      className: cn(
        "data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:animate-in data-[state=open]:fade-in-0 fixed inset-0 z-50 bg-black/50",
        className
      ),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/dialog.tsx",
      lineNumber: 29,
      columnNumber: 5
    },
    this
  );
}
_c5 = DialogOverlay;
function DialogContent({
  className,
  children,
  showCloseButton = true,
  overlayClassName,
  scrollableOverlay = false,
  ...props
}) {
  const content = /* @__PURE__ */ jsxDEV(
    DialogPrimitive.Content,
    {
      "data-slot": "dialog-content",
      className: cn(
        "data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[state=open]:animate-in data-[state=open]:fade-in-0 data-[state=open]:zoom-in-95 fixed top-[50%] left-[50%] z-50 grid w-full max-w-[calc(100%-2rem)] translate-x-[-50%] translate-y-[-50%] gap-4 rounded-lg border bg-background p-6 shadow-lg duration-200 outline-none sm:max-w-lg",
        className
      ),
      ...props,
      children: [
        children,
        showCloseButton && /* @__PURE__ */ jsxDEV(
          DialogPrimitive.Close,
          {
            "data-slot": "dialog-close",
            className: "absolute top-0 right-0 flex size-11 items-center justify-center rounded-xs text-primary ring-offset-background transition-opacity hover:bg-surface-raised focus:ring-2 focus:ring-ring focus:ring-offset-2 focus:outline-hidden active:bg-border disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
            children: [
              /* @__PURE__ */ jsxDEV(FigmaIcon, { name: "close", size: 16 }, void 0, false, {
                fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/dialog.tsx",
                lineNumber: 67,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Fechar" }, void 0, false, {
                fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/dialog.tsx",
                lineNumber: 68,
                columnNumber: 11
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/dialog.tsx",
            lineNumber: 63,
            columnNumber: 5
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/dialog.tsx",
      lineNumber: 53,
      columnNumber: 3
    },
    this
  );
  return /* @__PURE__ */ jsxDEV(DialogPortal, { "data-slot": "dialog-portal", children: scrollableOverlay ? /* @__PURE__ */ jsxDEV(DialogOverlay, { className: cn("overflow-y-auto md:pb-4", overlayClassName), children: content }, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/dialog.tsx",
    lineNumber: 76,
    columnNumber: 7
  }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(DialogOverlay, { className: overlayClassName }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/dialog.tsx",
      lineNumber: 81,
      columnNumber: 11
    }, this),
    content
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/dialog.tsx",
    lineNumber: 80,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/dialog.tsx",
    lineNumber: 74,
    columnNumber: 5
  }, this);
}
_c6 = DialogContent;
function DialogHeader({ className, ...props }) {
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      "data-slot": "dialog-header",
      className: cn("flex flex-col gap-2 text-center sm:text-left", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/dialog.tsx",
      lineNumber: 91,
      columnNumber: 5
    },
    this
  );
}
_c7 = DialogHeader;
function DialogFooter({
  className,
  showCloseButton = false,
  children,
  ...props
}) {
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      "data-slot": "dialog-footer",
      className: cn("flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", className),
      ...props,
      children: [
        children,
        showCloseButton && /* @__PURE__ */ jsxDEV(DialogPrimitive.Close, { asChild: true, children: /* @__PURE__ */ jsxDEV(Button, { variant: "outline", children: "Fechar" }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/dialog.tsx",
          lineNumber: 116,
          columnNumber: 11
        }, this) }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/dialog.tsx",
          lineNumber: 115,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/dialog.tsx",
      lineNumber: 108,
      columnNumber: 5
    },
    this
  );
}
_c8 = DialogFooter;
function DialogTitle({ className, ...props }) {
  return /* @__PURE__ */ jsxDEV(
    DialogPrimitive.Title,
    {
      "data-slot": "dialog-title",
      className: cn("text-lg leading-none font-semibold", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/dialog.tsx",
      lineNumber: 125,
      columnNumber: 5
    },
    this
  );
}
_c9 = DialogTitle;
function DialogDescription({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsxDEV(
    DialogPrimitive.Description,
    {
      "data-slot": "dialog-description",
      className: cn("text-sm text-muted-foreground", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/dialog.tsx",
      lineNumber: 138,
      columnNumber: 5
    },
    this
  );
}
_c0 = DialogDescription;
export {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogOverlay,
  DialogPortal,
  DialogTitle,
  DialogTrigger
};
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c0;
$RefreshReg$(_c, "Dialog");
$RefreshReg$(_c2, "DialogTrigger");
$RefreshReg$(_c3, "DialogPortal");
$RefreshReg$(_c4, "DialogClose");
$RefreshReg$(_c5, "DialogOverlay");
$RefreshReg$(_c6, "DialogContent");
$RefreshReg$(_c7, "DialogHeader");
$RefreshReg$(_c8, "DialogFooter");
$RefreshReg$(_c9, "DialogTitle");
$RefreshReg$(_c0, "DialogDescription");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/dialog.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/dialog.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/dialog.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUVMsU0F1RUQsVUF2RUM7QUFSVCxTQUFTQSxVQUFVQyx1QkFBdUI7QUFDMUMsWUFBWUMsV0FBVztBQUV2QixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxVQUFVO0FBRW5CLFNBQVNMLE9BQU8sRUFBRSxHQUFHTSxNQUF5RCxHQUFHO0FBQy9FLFNBQU8sdUJBQUMsZ0JBQWdCLE1BQWhCLEVBQXFCLGFBQVUsVUFBUyxHQUFJQSxTQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQW1EO0FBQzVEO0FBQUNDLEtBRlFQO0FBSVQsU0FBU1EsY0FBYyxFQUFFLEdBQUdGLE1BQTRELEdBQUc7QUFDekYsU0FBTyx1QkFBQyxnQkFBZ0IsU0FBaEIsRUFBd0IsYUFBVSxrQkFBaUIsR0FBSUEsU0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE4RDtBQUN2RTtBQUFDRyxNQUZRRDtBQUlULFNBQVNFLGFBQWEsRUFBRSxHQUFHSixNQUEyRCxHQUFHO0FBQ3ZGLFNBQU8sdUJBQUMsZ0JBQWdCLFFBQWhCLEVBQXVCLGFBQVUsaUJBQWdCLEdBQUlBLFNBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBNEQ7QUFDckU7QUFBQ0ssTUFGUUQ7QUFJVCxTQUFTRSxZQUFZLEVBQUUsR0FBR04sTUFBMEQsR0FBRztBQUNyRixTQUFPLHVCQUFDLGdCQUFnQixPQUFoQixFQUFzQixhQUFVLGdCQUFlLEdBQUlBLFNBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMEQ7QUFDbkU7QUFBQ08sTUFGUUQ7QUFJVCxTQUFTRSxjQUFjO0FBQUEsRUFDckJDO0FBQUFBLEVBQ0EsR0FBR1Q7QUFDaUQsR0FBRztBQUN2RCxTQUNFO0FBQUEsSUFBQyxnQkFBZ0I7QUFBQSxJQUFoQjtBQUFBLE1BQ0MsYUFBVTtBQUFBLE1BQ1YsV0FBV0Q7QUFBQUEsUUFDVDtBQUFBLFFBQ0FVO0FBQUFBLE1BQ0Y7QUFBQSxNQUNBLEdBQUlUO0FBQUFBO0FBQUFBLElBTk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTVk7QUFHaEI7QUFBQ1UsTUFkUUY7QUFnQlQsU0FBU0csY0FBYztBQUFBLEVBQ3JCRjtBQUFBQSxFQUNBRztBQUFBQSxFQUNBQyxrQkFBa0I7QUFBQSxFQUNsQkM7QUFBQUEsRUFDQUMsb0JBQW9CO0FBQUEsRUFDcEIsR0FBR2Y7QUFLTCxHQUFHO0FBQ0QsUUFBTWdCLFVBQ0o7QUFBQSxJQUFDLGdCQUFnQjtBQUFBLElBQWhCO0FBQUEsTUFDQyxhQUFVO0FBQUEsTUFDVixXQUFXakI7QUFBQUEsUUFDVDtBQUFBLFFBQ0FVO0FBQUFBLE1BQ0Y7QUFBQSxNQUNBLEdBQUlUO0FBQUFBLE1BRUhZO0FBQUFBO0FBQUFBLFFBQ0FDLG1CQUNDO0FBQUEsVUFBQyxnQkFBZ0I7QUFBQSxVQUFoQjtBQUFBLFlBQ0MsYUFBVTtBQUFBLFlBQ1YsV0FBVTtBQUFBLFlBRVY7QUFBQSxxQ0FBQyxhQUFVLE1BQUssU0FBUSxNQUFNLE1BQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlDO0FBQUEsY0FDakMsdUJBQUMsVUFBSyxXQUFVLFdBQVUsc0JBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUE7QUFBQTtBQUFBLFVBTGxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUE7QUFBQTtBQUFBLElBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWtCQTtBQUVGLFNBQ0UsdUJBQUMsZ0JBQWEsYUFBVSxpQkFDckJFLDhCQUNDLHVCQUFDLGlCQUFjLFdBQVdoQixHQUFHLDJCQUEyQmUsZ0JBQWdCLEdBQ3JFRSxxQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUEsSUFFQSxtQ0FDRTtBQUFBLDJCQUFDLGlCQUFjLFdBQVdGLG9CQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJDO0FBQUEsSUFDMUNFO0FBQUFBLE9BRkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUdBLEtBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVdBO0FBRUo7QUFBQ0MsTUEvQ1FOO0FBaURULFNBQVNPLGFBQWEsRUFBRVQsV0FBVyxHQUFHVCxNQUFtQyxHQUFHO0FBQzFFLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLGFBQVU7QUFBQSxNQUNWLFdBQVdELEdBQUcsZ0RBQWdEVSxTQUFTO0FBQUEsTUFDdkUsR0FBSVQ7QUFBQUE7QUFBQUEsSUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFHWTtBQUdoQjtBQUFDbUIsTUFSUUQ7QUFVVCxTQUFTRSxhQUFhO0FBQUEsRUFDcEJYO0FBQUFBLEVBQ0FJLGtCQUFrQjtBQUFBLEVBQ2xCRDtBQUFBQSxFQUNBLEdBQUdaO0FBR0wsR0FBRztBQUNELFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLGFBQVU7QUFBQSxNQUNWLFdBQVdELEdBQUcsMERBQTBEVSxTQUFTO0FBQUEsTUFDakYsR0FBSVQ7QUFBQUEsTUFFSFk7QUFBQUE7QUFBQUEsUUFDQUMsbUJBQ0MsdUJBQUMsZ0JBQWdCLE9BQWhCLEVBQXNCLFNBQU8sTUFDNUIsaUNBQUMsVUFBTyxTQUFRLFdBQVUsc0JBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0MsS0FEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUE7QUFBQTtBQUFBLElBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBV0E7QUFFSjtBQUFDUSxNQXRCUUQ7QUF3QlQsU0FBU0UsWUFBWSxFQUFFYixXQUFXLEdBQUdULE1BQTBELEdBQUc7QUFDaEcsU0FDRTtBQUFBLElBQUMsZ0JBQWdCO0FBQUEsSUFBaEI7QUFBQSxNQUNDLGFBQVU7QUFBQSxNQUNWLFdBQVdELEdBQUcsc0NBQXNDVSxTQUFTO0FBQUEsTUFDN0QsR0FBSVQ7QUFBQUE7QUFBQUEsSUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFHWTtBQUdoQjtBQUFDdUIsTUFSUUQ7QUFVVCxTQUFTRSxrQkFBa0I7QUFBQSxFQUN6QmY7QUFBQUEsRUFDQSxHQUFHVDtBQUNxRCxHQUFHO0FBQzNELFNBQ0U7QUFBQSxJQUFDLGdCQUFnQjtBQUFBLElBQWhCO0FBQUEsTUFDQyxhQUFVO0FBQUEsTUFDVixXQUFXRCxHQUFHLGlDQUFpQ1UsU0FBUztBQUFBLE1BQ3hELEdBQUlUO0FBQUFBO0FBQUFBLElBSE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBR1k7QUFHaEI7QUFBQ3lCLE1BWFFEO0FBYVQ7QUFBQSxFQUNFOUI7QUFBQUEsRUFDQVk7QUFBQUEsRUFDQUs7QUFBQUEsRUFDQWE7QUFBQUEsRUFDQUo7QUFBQUEsRUFDQUY7QUFBQUEsRUFDQVY7QUFBQUEsRUFDQUo7QUFBQUEsRUFDQWtCO0FBQUFBLEVBQ0FwQjtBQUFBQTtBQUNBLElBQUFELElBQUFFLEtBQUFFLEtBQUFFLEtBQUFHLEtBQUFPLEtBQUFFLEtBQUFFLEtBQUFFLEtBQUFFO0FBQUEsYUFBQXhCLElBQUE7QUFBQSxhQUFBRSxLQUFBO0FBQUEsYUFBQUUsS0FBQTtBQUFBLGFBQUFFLEtBQUE7QUFBQSxhQUFBRyxLQUFBO0FBQUEsYUFBQU8sS0FBQTtBQUFBLGFBQUFFLEtBQUE7QUFBQSxhQUFBRSxLQUFBO0FBQUEsYUFBQUUsS0FBQTtBQUFBLGFBQUFFLEtBQUEiLCJuYW1lcyI6WyJEaWFsb2ciLCJEaWFsb2dQcmltaXRpdmUiLCJSZWFjdCIsIkZpZ21hSWNvbiIsIkJ1dHRvbiIsImNuIiwicHJvcHMiLCJfYyIsIkRpYWxvZ1RyaWdnZXIiLCJfYzIiLCJEaWFsb2dQb3J0YWwiLCJfYzMiLCJEaWFsb2dDbG9zZSIsIl9jNCIsIkRpYWxvZ092ZXJsYXkiLCJjbGFzc05hbWUiLCJfYzUiLCJEaWFsb2dDb250ZW50IiwiY2hpbGRyZW4iLCJzaG93Q2xvc2VCdXR0b24iLCJvdmVybGF5Q2xhc3NOYW1lIiwic2Nyb2xsYWJsZU92ZXJsYXkiLCJjb250ZW50IiwiX2M2IiwiRGlhbG9nSGVhZGVyIiwiX2M3IiwiRGlhbG9nRm9vdGVyIiwiX2M4IiwiRGlhbG9nVGl0bGUiLCJfYzkiLCJEaWFsb2dEZXNjcmlwdGlvbiIsIl9jMCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJkaWFsb2cudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERpYWxvZyBhcyBEaWFsb2dQcmltaXRpdmUgfSBmcm9tICdyYWRpeC11aSc7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5cbmltcG9ydCB7IEZpZ21hSWNvbiB9IGZyb20gJ0AvY29tcG9uZW50cy9pY29ucy9GaWdtYUljb24nO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbic7XG5pbXBvcnQgeyBjbiB9IGZyb20gJ0AvbGliL2NuJztcblxuZnVuY3Rpb24gRGlhbG9nKHsgLi4ucHJvcHMgfTogUmVhY3QuQ29tcG9uZW50UHJvcHM8dHlwZW9mIERpYWxvZ1ByaW1pdGl2ZS5Sb290Pikge1xuICByZXR1cm4gPERpYWxvZ1ByaW1pdGl2ZS5Sb290IGRhdGEtc2xvdD1cImRpYWxvZ1wiIHsuLi5wcm9wc30gLz47XG59XG5cbmZ1bmN0aW9uIERpYWxvZ1RyaWdnZXIoeyAuLi5wcm9wcyB9OiBSZWFjdC5Db21wb25lbnRQcm9wczx0eXBlb2YgRGlhbG9nUHJpbWl0aXZlLlRyaWdnZXI+KSB7XG4gIHJldHVybiA8RGlhbG9nUHJpbWl0aXZlLlRyaWdnZXIgZGF0YS1zbG90PVwiZGlhbG9nLXRyaWdnZXJcIiB7Li4ucHJvcHN9IC8+O1xufVxuXG5mdW5jdGlvbiBEaWFsb2dQb3J0YWwoeyAuLi5wcm9wcyB9OiBSZWFjdC5Db21wb25lbnRQcm9wczx0eXBlb2YgRGlhbG9nUHJpbWl0aXZlLlBvcnRhbD4pIHtcbiAgcmV0dXJuIDxEaWFsb2dQcmltaXRpdmUuUG9ydGFsIGRhdGEtc2xvdD1cImRpYWxvZy1wb3J0YWxcIiB7Li4ucHJvcHN9IC8+O1xufVxuXG5mdW5jdGlvbiBEaWFsb2dDbG9zZSh7IC4uLnByb3BzIH06IFJlYWN0LkNvbXBvbmVudFByb3BzPHR5cGVvZiBEaWFsb2dQcmltaXRpdmUuQ2xvc2U+KSB7XG4gIHJldHVybiA8RGlhbG9nUHJpbWl0aXZlLkNsb3NlIGRhdGEtc2xvdD1cImRpYWxvZy1jbG9zZVwiIHsuLi5wcm9wc30gLz47XG59XG5cbmZ1bmN0aW9uIERpYWxvZ092ZXJsYXkoe1xuICBjbGFzc05hbWUsXG4gIC4uLnByb3BzXG59OiBSZWFjdC5Db21wb25lbnRQcm9wczx0eXBlb2YgRGlhbG9nUHJpbWl0aXZlLk92ZXJsYXk+KSB7XG4gIHJldHVybiAoXG4gICAgPERpYWxvZ1ByaW1pdGl2ZS5PdmVybGF5XG4gICAgICBkYXRhLXNsb3Q9XCJkaWFsb2ctb3ZlcmxheVwiXG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAnZGF0YS1bc3RhdGU9Y2xvc2VkXTphbmltYXRlLW91dCBkYXRhLVtzdGF0ZT1jbG9zZWRdOmZhZGUtb3V0LTAgZGF0YS1bc3RhdGU9b3Blbl06YW5pbWF0ZS1pbiBkYXRhLVtzdGF0ZT1vcGVuXTpmYWRlLWluLTAgZml4ZWQgaW5zZXQtMCB6LTUwIGJnLWJsYWNrLzUwJyxcbiAgICAgICAgY2xhc3NOYW1lLFxuICAgICAgKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApO1xufVxuXG5mdW5jdGlvbiBEaWFsb2dDb250ZW50KHtcbiAgY2xhc3NOYW1lLFxuICBjaGlsZHJlbixcbiAgc2hvd0Nsb3NlQnV0dG9uID0gdHJ1ZSxcbiAgb3ZlcmxheUNsYXNzTmFtZSxcbiAgc2Nyb2xsYWJsZU92ZXJsYXkgPSBmYWxzZSxcbiAgLi4ucHJvcHNcbn06IFJlYWN0LkNvbXBvbmVudFByb3BzPHR5cGVvZiBEaWFsb2dQcmltaXRpdmUuQ29udGVudD4gJiB7XG4gIHNob3dDbG9zZUJ1dHRvbj86IGJvb2xlYW47XG4gIG92ZXJsYXlDbGFzc05hbWU/OiBzdHJpbmc7XG4gIHNjcm9sbGFibGVPdmVybGF5PzogYm9vbGVhbjtcbn0pIHtcbiAgY29uc3QgY29udGVudCA9IChcbiAgICA8RGlhbG9nUHJpbWl0aXZlLkNvbnRlbnRcbiAgICAgIGRhdGEtc2xvdD1cImRpYWxvZy1jb250ZW50XCJcbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICdkYXRhLVtzdGF0ZT1jbG9zZWRdOmFuaW1hdGUtb3V0IGRhdGEtW3N0YXRlPWNsb3NlZF06ZmFkZS1vdXQtMCBkYXRhLVtzdGF0ZT1jbG9zZWRdOnpvb20tb3V0LTk1IGRhdGEtW3N0YXRlPW9wZW5dOmFuaW1hdGUtaW4gZGF0YS1bc3RhdGU9b3Blbl06ZmFkZS1pbi0wIGRhdGEtW3N0YXRlPW9wZW5dOnpvb20taW4tOTUgZml4ZWQgdG9wLVs1MCVdIGxlZnQtWzUwJV0gei01MCBncmlkIHctZnVsbCBtYXgtdy1bY2FsYygxMDAlLTJyZW0pXSB0cmFuc2xhdGUteC1bLTUwJV0gdHJhbnNsYXRlLXktWy01MCVdIGdhcC00IHJvdW5kZWQtbGcgYm9yZGVyIGJnLWJhY2tncm91bmQgcC02IHNoYWRvdy1sZyBkdXJhdGlvbi0yMDAgb3V0bGluZS1ub25lIHNtOm1heC13LWxnJyxcbiAgICAgICAgY2xhc3NOYW1lLFxuICAgICAgKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgICB7c2hvd0Nsb3NlQnV0dG9uICYmIChcbiAgICAgICAgPERpYWxvZ1ByaW1pdGl2ZS5DbG9zZVxuICAgICAgICAgIGRhdGEtc2xvdD1cImRpYWxvZy1jbG9zZVwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgcmlnaHQtMCBmbGV4IHNpemUtMTEgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQteHMgdGV4dC1wcmltYXJ5IHJpbmctb2Zmc2V0LWJhY2tncm91bmQgdHJhbnNpdGlvbi1vcGFjaXR5IGhvdmVyOmJnLXN1cmZhY2UtcmFpc2VkIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXJpbmcgZm9jdXM6cmluZy1vZmZzZXQtMiBmb2N1czpvdXRsaW5lLWhpZGRlbiBhY3RpdmU6YmctYm9yZGVyIGRpc2FibGVkOnBvaW50ZXItZXZlbnRzLW5vbmUgZGF0YS1bc3RhdGU9b3Blbl06YmctYWNjZW50IGRhdGEtW3N0YXRlPW9wZW5dOnRleHQtbXV0ZWQtZm9yZWdyb3VuZCBbJl9zdmddOnBvaW50ZXItZXZlbnRzLW5vbmUgWyZfc3ZnXTpzaHJpbmstMCBbJl9zdmc6bm90KFtjbGFzcyo9J3NpemUtJ10pXTpzaXplLTRcIlxuICAgICAgICA+XG4gICAgICAgICAgPEZpZ21hSWNvbiBuYW1lPVwiY2xvc2VcIiBzaXplPXsxNn0gLz5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCI+RmVjaGFyPC9zcGFuPlxuICAgICAgICA8L0RpYWxvZ1ByaW1pdGl2ZS5DbG9zZT5cbiAgICAgICl9XG4gICAgPC9EaWFsb2dQcmltaXRpdmUuQ29udGVudD5cbiAgKTtcbiAgcmV0dXJuIChcbiAgICA8RGlhbG9nUG9ydGFsIGRhdGEtc2xvdD1cImRpYWxvZy1wb3J0YWxcIj5cbiAgICAgIHtzY3JvbGxhYmxlT3ZlcmxheSA/IChcbiAgICAgICAgPERpYWxvZ092ZXJsYXkgY2xhc3NOYW1lPXtjbignb3ZlcmZsb3cteS1hdXRvIG1kOnBiLTQnLCBvdmVybGF5Q2xhc3NOYW1lKX0+XG4gICAgICAgICAge2NvbnRlbnR9XG4gICAgICAgIDwvRGlhbG9nT3ZlcmxheT5cbiAgICAgICkgOiAoXG4gICAgICAgIDw+XG4gICAgICAgICAgPERpYWxvZ092ZXJsYXkgY2xhc3NOYW1lPXtvdmVybGF5Q2xhc3NOYW1lfSAvPlxuICAgICAgICAgIHtjb250ZW50fVxuICAgICAgICA8Lz5cbiAgICAgICl9XG4gICAgPC9EaWFsb2dQb3J0YWw+XG4gICk7XG59XG5cbmZ1bmN0aW9uIERpYWxvZ0hlYWRlcih7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfTogUmVhY3QuQ29tcG9uZW50UHJvcHM8J2Rpdic+KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgZGF0YS1zbG90PVwiZGlhbG9nLWhlYWRlclwiXG4gICAgICBjbGFzc05hbWU9e2NuKCdmbGV4IGZsZXgtY29sIGdhcC0yIHRleHQtY2VudGVyIHNtOnRleHQtbGVmdCcsIGNsYXNzTmFtZSl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgKTtcbn1cblxuZnVuY3Rpb24gRGlhbG9nRm9vdGVyKHtcbiAgY2xhc3NOYW1lLFxuICBzaG93Q2xvc2VCdXR0b24gPSBmYWxzZSxcbiAgY2hpbGRyZW4sXG4gIC4uLnByb3BzXG59OiBSZWFjdC5Db21wb25lbnRQcm9wczwnZGl2Jz4gJiB7XG4gIHNob3dDbG9zZUJ1dHRvbj86IGJvb2xlYW47XG59KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgZGF0YS1zbG90PVwiZGlhbG9nLWZvb3RlclwiXG4gICAgICBjbGFzc05hbWU9e2NuKCdmbGV4IGZsZXgtY29sLXJldmVyc2UgZ2FwLTIgc206ZmxleC1yb3cgc206anVzdGlmeS1lbmQnLCBjbGFzc05hbWUpfVxuICAgICAgey4uLnByb3BzfVxuICAgID5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICAgIHtzaG93Q2xvc2VCdXR0b24gJiYgKFxuICAgICAgICA8RGlhbG9nUHJpbWl0aXZlLkNsb3NlIGFzQ2hpbGQ+XG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwib3V0bGluZVwiPkZlY2hhcjwvQnV0dG9uPlxuICAgICAgICA8L0RpYWxvZ1ByaW1pdGl2ZS5DbG9zZT5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmZ1bmN0aW9uIERpYWxvZ1RpdGxlKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9OiBSZWFjdC5Db21wb25lbnRQcm9wczx0eXBlb2YgRGlhbG9nUHJpbWl0aXZlLlRpdGxlPikge1xuICByZXR1cm4gKFxuICAgIDxEaWFsb2dQcmltaXRpdmUuVGl0bGVcbiAgICAgIGRhdGEtc2xvdD1cImRpYWxvZy10aXRsZVwiXG4gICAgICBjbGFzc05hbWU9e2NuKCd0ZXh0LWxnIGxlYWRpbmctbm9uZSBmb250LXNlbWlib2xkJywgY2xhc3NOYW1lKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApO1xufVxuXG5mdW5jdGlvbiBEaWFsb2dEZXNjcmlwdGlvbih7XG4gIGNsYXNzTmFtZSxcbiAgLi4ucHJvcHNcbn06IFJlYWN0LkNvbXBvbmVudFByb3BzPHR5cGVvZiBEaWFsb2dQcmltaXRpdmUuRGVzY3JpcHRpb24+KSB7XG4gIHJldHVybiAoXG4gICAgPERpYWxvZ1ByaW1pdGl2ZS5EZXNjcmlwdGlvblxuICAgICAgZGF0YS1zbG90PVwiZGlhbG9nLWRlc2NyaXB0aW9uXCJcbiAgICAgIGNsYXNzTmFtZT17Y24oJ3RleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kJywgY2xhc3NOYW1lKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApO1xufVxuXG5leHBvcnQge1xuICBEaWFsb2csXG4gIERpYWxvZ0Nsb3NlLFxuICBEaWFsb2dDb250ZW50LFxuICBEaWFsb2dEZXNjcmlwdGlvbixcbiAgRGlhbG9nRm9vdGVyLFxuICBEaWFsb2dIZWFkZXIsXG4gIERpYWxvZ092ZXJsYXksXG4gIERpYWxvZ1BvcnRhbCxcbiAgRGlhbG9nVGl0bGUsXG4gIERpYWxvZ1RyaWdnZXIsXG59O1xuIl0sImZpbGUiOiIvVXNlcnMvZmlsaXBlY2F2YWxjYW50ZS9Eb2N1bWVudHMvSnVuZ2xlR2FtaW5nVGVzdGUvc3JjL2NvbXBvbmVudHMvdWkvZGlhbG9nLnRzeCJ9