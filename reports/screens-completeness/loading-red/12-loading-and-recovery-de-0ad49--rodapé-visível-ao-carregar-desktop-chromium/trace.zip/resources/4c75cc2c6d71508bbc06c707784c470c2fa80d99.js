import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/DetailSummary.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { DetailHeading } from "/src/features/nft-detail/components/DetailHeading.tsx";
import { DetailMetadata } from "/src/features/nft-detail/components/DetailMetadata.tsx";
import { PurchasePanel } from "/src/features/nft-detail/components/PurchasePanel.tsx";
import { ShareNftAction } from "/src/features/nft-detail/components/ShareNftAction.tsx";
export function DetailSummary({ nft }) {
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      "data-testid": "detail-summary",
      className: "relative -mx-6 -mt-[30px] space-y-3 rounded-t-[32px] bg-surface-card px-6 pt-8 pb-6 md:mx-0 md:mt-0 md:bg-transparent md:p-0 lg:flex lg:min-h-[448px] lg:flex-col lg:gap-3 lg:space-y-0",
      children: [
        /* @__PURE__ */ jsxDEV(DetailHeading, { nft }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailSummary.tsx",
          lineNumber: 14,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "hidden text-body-sm font-bold md:block", children: "Sobre este NFT:" }, void 0, false, {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailSummary.tsx",
            lineNumber: 16,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm leading-6 text-text-secondary", children: nft.description }, void 0, false, {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailSummary.tsx",
            lineNumber: 17,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailSummary.tsx",
          lineNumber: 15,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(PurchasePanel, { nft }, nft.id, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailSummary.tsx",
          lineNumber: 19,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(DetailMetadata, { nft }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailSummary.tsx",
          lineNumber: 20,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(ShareNftAction, {}, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailSummary.tsx",
          lineNumber: 21,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailSummary.tsx",
      lineNumber: 10,
      columnNumber: 5
    },
    this
  );
}
_c = DetailSummary;
var _c;
$RefreshReg$(_c, "DetailSummary");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailSummary.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailSummary.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailSummary.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYU07QUFYTixTQUFTQSxxQkFBcUI7QUFDOUIsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyxzQkFBc0I7QUFFeEIsZ0JBQVNDLGNBQWMsRUFBRUMsSUFBa0IsR0FBRztBQUNuRCxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxlQUFZO0FBQUEsTUFDWixXQUFVO0FBQUEsTUFFVjtBQUFBLCtCQUFDLGlCQUFjLE9BQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3QjtBQUFBLFFBQ3hCLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDBDQUF5QywrQkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0U7QUFBQSxVQUN0RSx1QkFBQyxPQUFFLFdBQVUseUNBQXlDQSxjQUFJQyxlQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRTtBQUFBLGFBRnhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsaUJBQTJCLE9BQVJELElBQUlFLElBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUM7QUFBQSxRQUNyQyx1QkFBQyxrQkFBZSxPQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlCO0FBQUEsUUFDekIsdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFlO0FBQUE7QUFBQTtBQUFBLElBWGpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVlBO0FBRUo7QUFBQ0MsS0FoQmVKO0FBQWEsSUFBQUk7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiRGV0YWlsSGVhZGluZyIsIkRldGFpbE1ldGFkYXRhIiwiUHVyY2hhc2VQYW5lbCIsIlNoYXJlTmZ0QWN0aW9uIiwiRGV0YWlsU3VtbWFyeSIsIm5mdCIsImRlc2NyaXB0aW9uIiwiaWQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJEZXRhaWxTdW1tYXJ5LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IE5mdCB9IGZyb20gJ0AvY29udHJhY3RzL25mdCc7XG5cbmltcG9ydCB7IERldGFpbEhlYWRpbmcgfSBmcm9tICcuL0RldGFpbEhlYWRpbmcnO1xuaW1wb3J0IHsgRGV0YWlsTWV0YWRhdGEgfSBmcm9tICcuL0RldGFpbE1ldGFkYXRhJztcbmltcG9ydCB7IFB1cmNoYXNlUGFuZWwgfSBmcm9tICcuL1B1cmNoYXNlUGFuZWwnO1xuaW1wb3J0IHsgU2hhcmVOZnRBY3Rpb24gfSBmcm9tICcuL1NoYXJlTmZ0QWN0aW9uJztcblxuZXhwb3J0IGZ1bmN0aW9uIERldGFpbFN1bW1hcnkoeyBuZnQgfTogeyBuZnQ6IE5mdCB9KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgZGF0YS10ZXN0aWQ9XCJkZXRhaWwtc3VtbWFyeVwiXG4gICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSAtbXgtNiAtbXQtWzMwcHhdIHNwYWNlLXktMyByb3VuZGVkLXQtWzMycHhdIGJnLXN1cmZhY2UtY2FyZCBweC02IHB0LTggcGItNiBtZDpteC0wIG1kOm10LTAgbWQ6YmctdHJhbnNwYXJlbnQgbWQ6cC0wIGxnOmZsZXggbGc6bWluLWgtWzQ0OHB4XSBsZzpmbGV4LWNvbCBsZzpnYXAtMyBsZzpzcGFjZS15LTBcIlxuICAgID5cbiAgICAgIDxEZXRhaWxIZWFkaW5nIG5mdD17bmZ0fSAvPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cImhpZGRlbiB0ZXh0LWJvZHktc20gZm9udC1ib2xkIG1kOmJsb2NrXCI+U29icmUgZXN0ZSBORlQ6PC9oMj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBsZWFkaW5nLTYgdGV4dC10ZXh0LXNlY29uZGFyeVwiPntuZnQuZGVzY3JpcHRpb259PC9wPlxuICAgICAgPC9kaXY+XG4gICAgICA8UHVyY2hhc2VQYW5lbCBrZXk9e25mdC5pZH0gbmZ0PXtuZnR9IC8+XG4gICAgICA8RGV0YWlsTWV0YWRhdGEgbmZ0PXtuZnR9IC8+XG4gICAgICA8U2hhcmVOZnRBY3Rpb24gLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2ZpbGlwZWNhdmFsY2FudGUvRG9jdW1lbnRzL0p1bmdsZUdhbWluZ1Rlc3RlL3NyYy9mZWF0dXJlcy9uZnQtZGV0YWlsL2NvbXBvbmVudHMvRGV0YWlsU3VtbWFyeS50c3gifQ==