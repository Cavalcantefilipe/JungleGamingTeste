import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/ReviewsSummary.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { detailMessages } from "/src/features/nft-detail/messages.ts";
import { RatingStars } from "/src/features/nft-detail/components/RatingStars.tsx";
export function ReviewsSummary({ rating }) {
  return /* @__PURE__ */ jsxDEV("header", { className: "space-y-3", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "text-section font-bold text-text-accent", children: detailMessages.reviews }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewsSummary.tsx",
      lineNumber: 9,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-3", children: [
      /* @__PURE__ */ jsxDEV(RatingStars, { rating }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewsSummary.tsx",
        lineNumber: 11,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: [
        rating.average.toLocaleString("pt-BR"),
        " de 5 · ",
        rating.count,
        " avaliações"
      ] }, void 0, true, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewsSummary.tsx",
        lineNumber: 12,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewsSummary.tsx",
      lineNumber: 10,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-text-secondary", children: "Comentários de compradores fictícios para esta demonstração." }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewsSummary.tsx",
      lineNumber: 16,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewsSummary.tsx",
    lineNumber: 8,
    columnNumber: 5
  }, this);
}
_c = ReviewsSummary;
var _c;
$RefreshReg$(_c, "ReviewsSummary");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewsSummary.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewsSummary.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewsSummary.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUU07QUFOTixTQUFTQSxzQkFBc0I7QUFDL0IsU0FBU0MsbUJBQW1CO0FBRXJCLGdCQUFTQyxlQUFlLEVBQUVDLE9BQWtDLEdBQUc7QUFDcEUsU0FDRSx1QkFBQyxZQUFPLFdBQVUsYUFDaEI7QUFBQSwyQkFBQyxRQUFHLFdBQVUsMkNBQTJDSCx5QkFBZUksV0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnRjtBQUFBLElBQ2hGLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLDZCQUFDLGVBQVksVUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRCO0FBQUEsTUFDNUIsdUJBQUMsT0FDRUQ7QUFBQUEsZUFBT0UsUUFBUUMsZUFBZSxPQUFPO0FBQUEsUUFBRTtBQUFBLFFBQVNILE9BQU9JO0FBQUFBLFFBQU07QUFBQSxXQURoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBQ0EsdUJBQUMsT0FBRSxXQUFVLCtCQUE2Qiw0RUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBV0E7QUFFSjtBQUFDQyxLQWZlTjtBQUFjLElBQUFNO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbImRldGFpbE1lc3NhZ2VzIiwiUmF0aW5nU3RhcnMiLCJSZXZpZXdzU3VtbWFyeSIsInJhdGluZyIsInJldmlld3MiLCJhdmVyYWdlIiwidG9Mb2NhbGVTdHJpbmciLCJjb3VudCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlJldmlld3NTdW1tYXJ5LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IE5mdCB9IGZyb20gJ0AvY29udHJhY3RzL25mdCc7XG5cbmltcG9ydCB7IGRldGFpbE1lc3NhZ2VzIH0gZnJvbSAnLi4vbWVzc2FnZXMnO1xuaW1wb3J0IHsgUmF0aW5nU3RhcnMgfSBmcm9tICcuL1JhdGluZ1N0YXJzJztcblxuZXhwb3J0IGZ1bmN0aW9uIFJldmlld3NTdW1tYXJ5KHsgcmF0aW5nIH06IHsgcmF0aW5nOiBOZnRbJ3JhdGluZyddIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8aGVhZGVyIGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtc2VjdGlvbiBmb250LWJvbGQgdGV4dC10ZXh0LWFjY2VudFwiPntkZXRhaWxNZXNzYWdlcy5yZXZpZXdzfTwvaDI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICA8UmF0aW5nU3RhcnMgcmF0aW5nPXtyYXRpbmd9IC8+XG4gICAgICAgIDxwPlxuICAgICAgICAgIHtyYXRpbmcuYXZlcmFnZS50b0xvY2FsZVN0cmluZygncHQtQlInKX0gZGUgNSDCtyB7cmF0aW5nLmNvdW50fSBhdmFsaWHDp8O1ZXNcbiAgICAgICAgPC9wPlxuICAgICAgPC9kaXY+XG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtdGV4dC1zZWNvbmRhcnlcIj5cbiAgICAgICAgQ29tZW50w6FyaW9zIGRlIGNvbXByYWRvcmVzIGZpY3TDrWNpb3MgcGFyYSBlc3RhIGRlbW9uc3RyYcOnw6NvLlxuICAgICAgPC9wPlxuICAgIDwvaGVhZGVyPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvZmlsaXBlY2F2YWxjYW50ZS9Eb2N1bWVudHMvSnVuZ2xlR2FtaW5nVGVzdGUvc3JjL2ZlYXR1cmVzL25mdC1kZXRhaWwvY29tcG9uZW50cy9SZXZpZXdzU3VtbWFyeS50c3gifQ==