import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/EditionPicker.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Button } from "/src/components/ui/button.tsx";
export function EditionPicker({
  editions,
  value,
  onChange
}) {
  return /* @__PURE__ */ jsxDEV("fieldset", { children: [
    /* @__PURE__ */ jsxDEV("legend", { className: "mb-0 text-body-sm font-bold md:mb-2", children: "Edição:" }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/EditionPicker.tsx",
      lineNumber: 15,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-1 md:gap-1.5", children: editions.map(
      (edition) => /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "edition",
          size: "edition",
          "aria-pressed": value === edition.id,
          "aria-disabled": edition.available === 0,
          disabled: edition.available === 0,
          onClick: () => {
            onChange(edition.id);
          },
          children: [
            edition.label.toUpperCase(),
            edition.available === 0 ? " · Esgotada" : ""
          ]
        },
        edition.id,
        true,
        {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/EditionPicker.tsx",
          lineNumber: 18,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/EditionPicker.tsx",
      lineNumber: 16,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/EditionPicker.tsx",
    lineNumber: 14,
    columnNumber: 5
  }, this);
}
_c = EditionPicker;
var _c;
$RefreshReg$(_c, "EditionPicker");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/EditionPicker.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/EditionPicker.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/EditionPicker.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY007QUFkTixTQUFTQSxjQUFjO0FBR2hCLGdCQUFTQyxjQUFjO0FBQUEsRUFDNUJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBS0YsR0FBRztBQUNELFNBQ0UsdUJBQUMsY0FDQztBQUFBLDJCQUFDLFlBQU8sV0FBVSx1Q0FBc0MsdUJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0Q7QUFBQSxJQUMvRCx1QkFBQyxTQUFJLFdBQVUsbUNBQ1pGLG1CQUFTRztBQUFBQSxNQUFJLENBQUNDLFlBQ2I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVDLFNBQVE7QUFBQSxVQUNSLE1BQUs7QUFBQSxVQUNMLGdCQUFjSCxVQUFVRyxRQUFRQztBQUFBQSxVQUNoQyxpQkFBZUQsUUFBUUUsY0FBYztBQUFBLFVBQ3JDLFVBQVVGLFFBQVFFLGNBQWM7QUFBQSxVQUNoQyxTQUFTLE1BQU07QUFDYkoscUJBQVNFLFFBQVFDLEVBQUU7QUFBQSxVQUNyQjtBQUFBLFVBRUNEO0FBQUFBLG9CQUFRRyxNQUFNQyxZQUFZO0FBQUEsWUFDMUJKLFFBQVFFLGNBQWMsSUFBSSxnQkFBZ0I7QUFBQTtBQUFBO0FBQUEsUUFYdENGLFFBQVFDO0FBQUFBLFFBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQWFBO0FBQUEsSUFDRCxLQWhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUJBO0FBQUEsT0FuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9CQTtBQUVKO0FBQUNJLEtBaENlVjtBQUFhLElBQUFVO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkJ1dHRvbiIsIkVkaXRpb25QaWNrZXIiLCJlZGl0aW9ucyIsInZhbHVlIiwib25DaGFuZ2UiLCJtYXAiLCJlZGl0aW9uIiwiaWQiLCJhdmFpbGFibGUiLCJsYWJlbCIsInRvVXBwZXJDYXNlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRWRpdGlvblBpY2tlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbic7XG5pbXBvcnQgdHlwZSB7IE5mdEVkaXRpb24gfSBmcm9tICdAL2NvbnRyYWN0cy9uZnQnO1xuXG5leHBvcnQgZnVuY3Rpb24gRWRpdGlvblBpY2tlcih7XG4gIGVkaXRpb25zLFxuICB2YWx1ZSxcbiAgb25DaGFuZ2UsXG59OiB7XG4gIGVkaXRpb25zOiBOZnRFZGl0aW9uW107XG4gIHZhbHVlOiBzdHJpbmc7XG4gIG9uQ2hhbmdlOiAoaWQ6IHN0cmluZykgPT4gdm9pZDtcbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZmllbGRzZXQ+XG4gICAgICA8bGVnZW5kIGNsYXNzTmFtZT1cIm1iLTAgdGV4dC1ib2R5LXNtIGZvbnQtYm9sZCBtZDptYi0yXCI+RWRpw6fDo286PC9sZWdlbmQ+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0xIG1kOmdhcC0xLjVcIj5cbiAgICAgICAge2VkaXRpb25zLm1hcCgoZWRpdGlvbikgPT4gKFxuICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgIGtleT17ZWRpdGlvbi5pZH1cbiAgICAgICAgICAgIHZhcmlhbnQ9XCJlZGl0aW9uXCJcbiAgICAgICAgICAgIHNpemU9XCJlZGl0aW9uXCJcbiAgICAgICAgICAgIGFyaWEtcHJlc3NlZD17dmFsdWUgPT09IGVkaXRpb24uaWR9XG4gICAgICAgICAgICBhcmlhLWRpc2FibGVkPXtlZGl0aW9uLmF2YWlsYWJsZSA9PT0gMH1cbiAgICAgICAgICAgIGRpc2FibGVkPXtlZGl0aW9uLmF2YWlsYWJsZSA9PT0gMH1cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgb25DaGFuZ2UoZWRpdGlvbi5pZCk7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHtlZGl0aW9uLmxhYmVsLnRvVXBwZXJDYXNlKCl9XG4gICAgICAgICAgICB7ZWRpdGlvbi5hdmFpbGFibGUgPT09IDAgPyAnIMK3IEVzZ290YWRhJyA6ICcnfVxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICApKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvZmllbGRzZXQ+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9maWxpcGVjYXZhbGNhbnRlL0RvY3VtZW50cy9KdW5nbGVHYW1pbmdUZXN0ZS9zcmMvZmVhdHVyZXMvbmZ0LWRldGFpbC9jb21wb25lbnRzL0VkaXRpb25QaWNrZXIudHN4In0=