import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/CarouselPlayback.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Pause, Play } from "/node_modules/.vite/deps/lucide-react.js?v=970a124b";
import { Button } from "/src/components/ui/button.tsx";
export function CarouselPlayback({ playing, toggle }) {
  const Icon = playing ? Pause : Play;
  return /* @__PURE__ */ jsxDEV(
    Button,
    {
      variant: "ghost",
      size: "icon",
      className: "motion-reduce:hidden",
      "data-carousel-playback": true,
      "aria-label": playing ? "Pausar carrossel" : "Reproduzir carrossel",
      onClick: toggle,
      children: /* @__PURE__ */ jsxDEV(Icon, { size: 16, "aria-hidden": "true" }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CarouselPlayback.tsx",
        lineNumber: 16,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CarouselPlayback.tsx",
      lineNumber: 8,
      columnNumber: 5
    },
    this
  );
}
_c = CarouselPlayback;
var _c;
$RefreshReg$(_c, "CarouselPlayback");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CarouselPlayback.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CarouselPlayback.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CarouselPlayback.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZU07QUFmTixTQUFTQSxPQUFPQyxZQUFZO0FBRTVCLFNBQVNDLGNBQWM7QUFFaEIsZ0JBQVNDLGlCQUFpQixFQUFFQyxTQUFTQyxPQUFpRCxHQUFHO0FBQzlGLFFBQU1DLE9BQU9GLFVBQVVKLFFBQVFDO0FBQy9CLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFNBQVE7QUFBQSxNQUNSLE1BQUs7QUFBQSxNQUNMLFdBQVU7QUFBQSxNQUNWO0FBQUEsTUFDQSxjQUFZRyxVQUFVLHFCQUFxQjtBQUFBLE1BQzNDLFNBQVNDO0FBQUFBLE1BRVQsaUNBQUMsUUFBSyxNQUFNLElBQUksZUFBWSxVQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtDO0FBQUE7QUFBQSxJQVJwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFTQTtBQUVKO0FBQUNFLEtBZGVKO0FBQWdCLElBQUFJO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlBhdXNlIiwiUGxheSIsIkJ1dHRvbiIsIkNhcm91c2VsUGxheWJhY2siLCJwbGF5aW5nIiwidG9nZ2xlIiwiSWNvbiIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNhcm91c2VsUGxheWJhY2sudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFBhdXNlLCBQbGF5IH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbic7XG5cbmV4cG9ydCBmdW5jdGlvbiBDYXJvdXNlbFBsYXliYWNrKHsgcGxheWluZywgdG9nZ2xlIH06IHsgcGxheWluZzogYm9vbGVhbjsgdG9nZ2xlOiAoKSA9PiB2b2lkIH0pIHtcbiAgY29uc3QgSWNvbiA9IHBsYXlpbmcgPyBQYXVzZSA6IFBsYXk7XG4gIHJldHVybiAoXG4gICAgPEJ1dHRvblxuICAgICAgdmFyaWFudD1cImdob3N0XCJcbiAgICAgIHNpemU9XCJpY29uXCJcbiAgICAgIGNsYXNzTmFtZT1cIm1vdGlvbi1yZWR1Y2U6aGlkZGVuXCJcbiAgICAgIGRhdGEtY2Fyb3VzZWwtcGxheWJhY2tcbiAgICAgIGFyaWEtbGFiZWw9e3BsYXlpbmcgPyAnUGF1c2FyIGNhcnJvc3NlbCcgOiAnUmVwcm9kdXppciBjYXJyb3NzZWwnfVxuICAgICAgb25DbGljaz17dG9nZ2xlfVxuICAgID5cbiAgICAgIDxJY29uIHNpemU9ezE2fSBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgIDwvQnV0dG9uPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvZmlsaXBlY2F2YWxjYW50ZS9Eb2N1bWVudHMvSnVuZ2xlR2FtaW5nVGVzdGUvc3JjL2ZlYXR1cmVzL2NhdGFsb2cvY29tcG9uZW50cy9DYXJvdXNlbFBsYXliYWNrLnRzeCJ9