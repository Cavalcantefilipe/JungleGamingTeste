import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/DetailFacts.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { NFT_NETWORK_LABELS } from "/src/contracts/nft.ts";
export function DetailFacts({ nft }) {
  const facts = nft.details ? [
    { label: "Rede", value: nft.details.provenance },
    { label: "Contrato", value: `${nft.details.contract} · ${nft.details.standard}` },
    {
      label: "Direitos autorais",
      value: `${nft.details.creator}: ${nft.details.royaltyPercent}% nas vendas secundárias, pagos pelos mercados compatíveis.`
    }
  ] : [{ label: "Rede", value: NFT_NETWORK_LABELS[nft.network] }, ...nft.attributes];
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 py-2 text-sm leading-7 text-text-secondary", children: [
    (nft.details?.paragraphs ?? [nft.description]).map(
      (paragraph) => /* @__PURE__ */ jsxDEV("p", { children: paragraph }, paragraph, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailFacts.tsx",
        lineNumber: 17,
        columnNumber: 7
      }, this)
    ),
    /* @__PURE__ */ jsxDEV("dl", { className: "space-y-3", children: facts.map(
      (fact) => /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("dt", { className: "font-bold text-foreground", children: fact.label }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailFacts.tsx",
          lineNumber: 22,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("dd", { className: "wrap-anywhere", children: fact.value }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailFacts.tsx",
          lineNumber: 23,
          columnNumber: 13
        }, this)
      ] }, fact.label, true, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailFacts.tsx",
        lineNumber: 21,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailFacts.tsx",
      lineNumber: 19,
      columnNumber: 7
    }, this),
    nft.details && /* @__PURE__ */ jsxDEV("p", { className: "text-xs", children: "Metadados ilustrativos da demonstração; nenhuma transação é realizada na blockchain." }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailFacts.tsx",
      lineNumber: 28,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailFacts.tsx",
    lineNumber: 15,
    columnNumber: 5
  }, this);
}
_c = DetailFacts;
var _c;
$RefreshReg$(_c, "DetailFacts");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailFacts.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailFacts.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailFacts.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JRO0FBaEJSLFNBQVNBLDBCQUFvQztBQUV0QyxnQkFBU0MsWUFBWSxFQUFFQyxJQUFrQixHQUFHO0FBQ2pELFFBQU1DLFFBQVFELElBQUlFLFVBQ2Q7QUFBQSxJQUNFLEVBQUVDLE9BQU8sUUFBUUMsT0FBT0osSUFBSUUsUUFBUUcsV0FBVztBQUFBLElBQy9DLEVBQUVGLE9BQU8sWUFBWUMsT0FBTyxHQUFHSixJQUFJRSxRQUFRSSxRQUFRLE1BQU1OLElBQUlFLFFBQVFLLFFBQVEsR0FBRztBQUFBLElBQ2hGO0FBQUEsTUFDRUosT0FBTztBQUFBLE1BQ1BDLE9BQU8sR0FBR0osSUFBSUUsUUFBUU0sT0FBTyxLQUFLUixJQUFJRSxRQUFRTyxjQUFjO0FBQUEsSUFDOUQ7QUFBQSxFQUFDLElBRUgsQ0FBQyxFQUFFTixPQUFPLFFBQVFDLE9BQU9OLG1CQUFtQkUsSUFBSVUsT0FBTyxFQUFFLEdBQUcsR0FBR1YsSUFBSVcsVUFBVTtBQUNqRixTQUNFLHVCQUFDLFNBQUksV0FBVSx3REFDWFg7QUFBQUEsU0FBSUUsU0FBU1UsY0FBYyxDQUFDWixJQUFJYSxXQUFXLEdBQUdDO0FBQUFBLE1BQUksQ0FBQ0MsY0FDbkQsdUJBQUMsT0FBbUJBLHVCQUFaQSxXQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEI7QUFBQSxJQUMvQjtBQUFBLElBQ0QsdUJBQUMsUUFBRyxXQUFVLGFBQ1hkLGdCQUFNYTtBQUFBQSxNQUFJLENBQUNFLFNBQ1YsdUJBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSw2QkFBNkJBLGVBQUtiLFNBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0Q7QUFBQSxRQUN0RCx1QkFBQyxRQUFHLFdBQVUsaUJBQWlCYSxlQUFLWixTQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBDO0FBQUEsV0FGbENZLEtBQUtiLE9BQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsSUFDRCxLQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBQ0NILElBQUlFLFdBQ0gsdUJBQUMsT0FBRSxXQUFVLFdBQVMsb0dBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BZko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlCQTtBQUVKO0FBQUNlLEtBL0JlbEI7QUFBVyxJQUFBa0I7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiTkZUX05FVFdPUktfTEFCRUxTIiwiRGV0YWlsRmFjdHMiLCJuZnQiLCJmYWN0cyIsImRldGFpbHMiLCJsYWJlbCIsInZhbHVlIiwicHJvdmVuYW5jZSIsImNvbnRyYWN0Iiwic3RhbmRhcmQiLCJjcmVhdG9yIiwicm95YWx0eVBlcmNlbnQiLCJuZXR3b3JrIiwiYXR0cmlidXRlcyIsInBhcmFncmFwaHMiLCJkZXNjcmlwdGlvbiIsIm1hcCIsInBhcmFncmFwaCIsImZhY3QiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJEZXRhaWxGYWN0cy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTkZUX05FVFdPUktfTEFCRUxTLCB0eXBlIE5mdCB9IGZyb20gJ0AvY29udHJhY3RzL25mdCc7XG5cbmV4cG9ydCBmdW5jdGlvbiBEZXRhaWxGYWN0cyh7IG5mdCB9OiB7IG5mdDogTmZ0IH0pIHtcbiAgY29uc3QgZmFjdHMgPSBuZnQuZGV0YWlsc1xuICAgID8gW1xuICAgICAgICB7IGxhYmVsOiAnUmVkZScsIHZhbHVlOiBuZnQuZGV0YWlscy5wcm92ZW5hbmNlIH0sXG4gICAgICAgIHsgbGFiZWw6ICdDb250cmF0bycsIHZhbHVlOiBgJHtuZnQuZGV0YWlscy5jb250cmFjdH0gwrcgJHtuZnQuZGV0YWlscy5zdGFuZGFyZH1gIH0sXG4gICAgICAgIHtcbiAgICAgICAgICBsYWJlbDogJ0RpcmVpdG9zIGF1dG9yYWlzJyxcbiAgICAgICAgICB2YWx1ZTogYCR7bmZ0LmRldGFpbHMuY3JlYXRvcn06ICR7bmZ0LmRldGFpbHMucm95YWx0eVBlcmNlbnR9JSBuYXMgdmVuZGFzIHNlY3VuZMOhcmlhcywgcGFnb3MgcGVsb3MgbWVyY2Fkb3MgY29tcGF0w612ZWlzLmAsXG4gICAgICAgIH0sXG4gICAgICBdXG4gICAgOiBbeyBsYWJlbDogJ1JlZGUnLCB2YWx1ZTogTkZUX05FVFdPUktfTEFCRUxTW25mdC5uZXR3b3JrXSB9LCAuLi5uZnQuYXR0cmlidXRlc107XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTYgcHktMiB0ZXh0LXNtIGxlYWRpbmctNyB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+XG4gICAgICB7KG5mdC5kZXRhaWxzPy5wYXJhZ3JhcGhzID8/IFtuZnQuZGVzY3JpcHRpb25dKS5tYXAoKHBhcmFncmFwaCkgPT4gKFxuICAgICAgICA8cCBrZXk9e3BhcmFncmFwaH0+e3BhcmFncmFwaH08L3A+XG4gICAgICApKX1cbiAgICAgIDxkbCBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAge2ZhY3RzLm1hcCgoZmFjdCkgPT4gKFxuICAgICAgICAgIDxkaXYga2V5PXtmYWN0LmxhYmVsfT5cbiAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1mb3JlZ3JvdW5kXCI+e2ZhY3QubGFiZWx9PC9kdD5cbiAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJ3cmFwLWFueXdoZXJlXCI+e2ZhY3QudmFsdWV9PC9kZD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSl9XG4gICAgICA8L2RsPlxuICAgICAge25mdC5kZXRhaWxzICYmIChcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14c1wiPlxuICAgICAgICAgIE1ldGFkYWRvcyBpbHVzdHJhdGl2b3MgZGEgZGVtb25zdHJhw6fDo287IG5lbmh1bWEgdHJhbnNhw6fDo28gw6kgcmVhbGl6YWRhIG5hIGJsb2NrY2hhaW4uXG4gICAgICAgIDwvcD5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9maWxpcGVjYXZhbGNhbnRlL0RvY3VtZW50cy9KdW5nbGVHYW1pbmdUZXN0ZS9zcmMvZmVhdHVyZXMvbmZ0LWRldGFpbC9jb21wb25lbnRzL0RldGFpbEZhY3RzLnRzeCJ9