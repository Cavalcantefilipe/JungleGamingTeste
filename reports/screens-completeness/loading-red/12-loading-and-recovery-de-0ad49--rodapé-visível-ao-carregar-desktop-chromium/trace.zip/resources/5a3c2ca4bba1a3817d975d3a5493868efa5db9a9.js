import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/DetailHeading.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { FigmaIcon } from "/src/components/icons/FigmaIcon.tsx";
import { formatEth } from "/src/lib/money.ts";
import { RatingStars } from "/src/features/nft-detail/components/RatingStars.tsx";
export function DetailHeading({ nft }) {
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center justify-between gap-2", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-title font-bold md:text-heading", children: nft.name }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailHeading.tsx",
        lineNumber: 11,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "span",
        {
          role: "img",
          "aria-label": `Avaliação: ${nft.rating.average} de 5, ${nft.rating.count} avaliações`,
          className: "mr-0.5 inline-flex h-[27px] shrink-0 items-center gap-1 rounded-full border border-primary px-0.5 text-sm md:hidden",
          children: [
            /* @__PURE__ */ jsxDEV(FigmaIcon, { name: "star", size: 12, className: "text-amber" }, void 0, false, {
              fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailHeading.tsx",
              lineNumber: 17,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: [
              nft.rating.average,
              /* @__PURE__ */ jsxDEV("span", { className: "text-text-secondary", children: [
                "(",
                nft.rating.count,
                ")"
              ] }, void 0, true, {
                fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailHeading.tsx",
                lineNumber: 20,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailHeading.tsx",
              lineNumber: 18,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailHeading.tsx",
          lineNumber: 12,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailHeading.tsx",
      lineNumber: 10,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "hidden flex-wrap items-center justify-between gap-2 border-b border-border pb-2 md:flex", children: [
      /* @__PURE__ */ jsxDEV("p", { "data-testid": "nft-price", className: "text-[22px] leading-7 font-bold text-text-accent", children: formatEth(nft.price) }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailHeading.tsx",
        lineNumber: 25,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "flex flex-wrap items-center gap-1 text-body-sm", children: [
        /* @__PURE__ */ jsxDEV(RatingStars, { rating: nft.rating }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailHeading.tsx",
          lineNumber: 29,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          nft.rating.count,
          " avaliações de colecionadores"
        ] }, void 0, true, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailHeading.tsx",
          lineNumber: 30,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailHeading.tsx",
        lineNumber: 28,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailHeading.tsx",
      lineNumber: 24,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailHeading.tsx",
    lineNumber: 9,
    columnNumber: 5
  }, this);
}
_c = DetailHeading;
var _c;
$RefreshReg$(_c, "DetailHeading");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailHeading.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailHeading.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailHeading.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUUksbUJBRUksY0FGSjtBQVJKLFNBQVNBLGlCQUFpQjtBQUUxQixTQUFTQyxpQkFBaUI7QUFFMUIsU0FBU0MsbUJBQW1CO0FBRXJCLGdCQUFTQyxjQUFjLEVBQUVDLElBQWtCLEdBQUc7QUFDbkQsU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLFNBQUksV0FBVSxxREFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSx3Q0FBd0NBLGNBQUlDLFFBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0Q7QUFBQSxNQUMvRDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsY0FBWSxjQUFjRCxJQUFJRSxPQUFPQyxPQUFPLFVBQVVILElBQUlFLE9BQU9FLEtBQUs7QUFBQSxVQUN0RSxXQUFVO0FBQUEsVUFFVjtBQUFBLG1DQUFDLGFBQVUsTUFBSyxRQUFPLE1BQU0sSUFBSSxXQUFVLGdCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RDtBQUFBLFlBQ3ZELHVCQUFDLFVBQ0VKO0FBQUFBLGtCQUFJRSxPQUFPQztBQUFBQSxjQUNaLHVCQUFDLFVBQUssV0FBVSx1QkFBc0I7QUFBQTtBQUFBLGdCQUFFSCxJQUFJRSxPQUFPRTtBQUFBQSxnQkFBTTtBQUFBLG1CQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwRDtBQUFBLGlCQUY1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUE7QUFBQTtBQUFBLFFBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BVUE7QUFBQSxTQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FhQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFVLDJGQUNiO0FBQUEsNkJBQUMsT0FBRSxlQUFZLGFBQVksV0FBVSxvREFDbENQLG9CQUFVRyxJQUFJSyxLQUFLLEtBRHRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsT0FBRSxXQUFVLGtEQUNYO0FBQUEsK0JBQUMsZUFBWSxRQUFRTCxJQUFJRSxVQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdDO0FBQUEsUUFDaEMsdUJBQUMsVUFBTUY7QUFBQUEsY0FBSUUsT0FBT0U7QUFBQUEsVUFBTTtBQUFBLGFBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUQ7QUFBQSxXQUZ2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLE9BdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3QkE7QUFFSjtBQUFDRSxLQTVCZVA7QUFBYSxJQUFBTztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJGaWdtYUljb24iLCJmb3JtYXRFdGgiLCJSYXRpbmdTdGFycyIsIkRldGFpbEhlYWRpbmciLCJuZnQiLCJuYW1lIiwicmF0aW5nIiwiYXZlcmFnZSIsImNvdW50IiwicHJpY2UiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJEZXRhaWxIZWFkaW5nLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGaWdtYUljb24gfSBmcm9tICdAL2NvbXBvbmVudHMvaWNvbnMvRmlnbWFJY29uJztcbmltcG9ydCB0eXBlIHsgTmZ0IH0gZnJvbSAnQC9jb250cmFjdHMvbmZ0JztcbmltcG9ydCB7IGZvcm1hdEV0aCB9IGZyb20gJ0AvbGliL21vbmV5JztcblxuaW1wb3J0IHsgUmF0aW5nU3RhcnMgfSBmcm9tICcuL1JhdGluZ1N0YXJzJztcblxuZXhwb3J0IGZ1bmN0aW9uIERldGFpbEhlYWRpbmcoeyBuZnQgfTogeyBuZnQ6IE5mdCB9KSB7XG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMlwiPlxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC10aXRsZSBmb250LWJvbGQgbWQ6dGV4dC1oZWFkaW5nXCI+e25mdC5uYW1lfTwvaDE+XG4gICAgICAgIDxzcGFuXG4gICAgICAgICAgcm9sZT1cImltZ1wiXG4gICAgICAgICAgYXJpYS1sYWJlbD17YEF2YWxpYcOnw6NvOiAke25mdC5yYXRpbmcuYXZlcmFnZX0gZGUgNSwgJHtuZnQucmF0aW5nLmNvdW50fSBhdmFsaWHDp8O1ZXNgfVxuICAgICAgICAgIGNsYXNzTmFtZT1cIm1yLTAuNSBpbmxpbmUtZmxleCBoLVsyN3B4XSBzaHJpbmstMCBpdGVtcy1jZW50ZXIgZ2FwLTEgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItcHJpbWFyeSBweC0wLjUgdGV4dC1zbSBtZDpoaWRkZW5cIlxuICAgICAgICA+XG4gICAgICAgICAgPEZpZ21hSWNvbiBuYW1lPVwic3RhclwiIHNpemU9ezEyfSBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyXCIgLz5cbiAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgIHtuZnQucmF0aW5nLmF2ZXJhZ2V9XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+KHtuZnQucmF0aW5nLmNvdW50fSk8L3NwYW4+XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L3NwYW4+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yIGJvcmRlci1iIGJvcmRlci1ib3JkZXIgcGItMiBtZDpmbGV4XCI+XG4gICAgICAgIDxwIGRhdGEtdGVzdGlkPVwibmZ0LXByaWNlXCIgY2xhc3NOYW1lPVwidGV4dC1bMjJweF0gbGVhZGluZy03IGZvbnQtYm9sZCB0ZXh0LXRleHQtYWNjZW50XCI+XG4gICAgICAgICAge2Zvcm1hdEV0aChuZnQucHJpY2UpfVxuICAgICAgICA8L3A+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMSB0ZXh0LWJvZHktc21cIj5cbiAgICAgICAgICA8UmF0aW5nU3RhcnMgcmF0aW5nPXtuZnQucmF0aW5nfSAvPlxuICAgICAgICAgIDxzcGFuPntuZnQucmF0aW5nLmNvdW50fSBhdmFsaWHDp8O1ZXMgZGUgY29sZWNpb25hZG9yZXM8L3NwYW4+XG4gICAgICAgIDwvcD5cbiAgICAgIDwvZGl2PlxuICAgIDwvPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvZmlsaXBlY2F2YWxjYW50ZS9Eb2N1bWVudHMvSnVuZ2xlR2FtaW5nVGVzdGUvc3JjL2ZlYXR1cmVzL25mdC1kZXRhaWwvY29tcG9uZW50cy9EZXRhaWxIZWFkaW5nLnRzeCJ9