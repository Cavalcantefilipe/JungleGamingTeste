import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/DetailTabTrigger.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { TabsTrigger } from "/src/components/ui/tabs.tsx";
export function DetailTabTrigger({ value, children }) {
  return /* @__PURE__ */ jsxDEV(
    TabsTrigger,
    {
      value,
      className: "min-h-11 flex-none rounded-none border-0 border-b-2 border-transparent px-0 text-sm text-foreground after:hidden data-[state=active]:border-primary data-[state=active]:font-bold data-[state=active]:text-text-accent md:text-[17px]",
      children
    },
    void 0,
    false,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailTabTrigger.tsx",
      lineNumber: 7,
      columnNumber: 5
    },
    this
  );
}
_c = DetailTabTrigger;
var _c;
$RefreshReg$(_c, "DetailTabTrigger");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailTabTrigger.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailTabTrigger.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailTabTrigger.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBTUk7QUFOSixTQUFTQSxtQkFBbUI7QUFJckIsZ0JBQVNDLGlCQUFpQixFQUFFQyxPQUFPQyxTQUFpRCxHQUFHO0FBQzVGLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDO0FBQUEsTUFDQSxXQUFVO0FBQUEsTUFFVEE7QUFBQUE7QUFBQUEsSUFKSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLQTtBQUVKO0FBQUNDLEtBVGVIO0FBQWdCLElBQUFHO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlRhYnNUcmlnZ2VyIiwiRGV0YWlsVGFiVHJpZ2dlciIsInZhbHVlIiwiY2hpbGRyZW4iLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJEZXRhaWxUYWJUcmlnZ2VyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBUYWJzVHJpZ2dlciB9IGZyb20gJ0AvY29tcG9uZW50cy91aS90YWJzJztcblxuaW1wb3J0IHR5cGUgeyBSZWFjdE5vZGUgfSBmcm9tICdyZWFjdCc7XG5cbmV4cG9ydCBmdW5jdGlvbiBEZXRhaWxUYWJUcmlnZ2VyKHsgdmFsdWUsIGNoaWxkcmVuIH06IHsgdmFsdWU6IHN0cmluZzsgY2hpbGRyZW46IFJlYWN0Tm9kZSB9KSB7XG4gIHJldHVybiAoXG4gICAgPFRhYnNUcmlnZ2VyXG4gICAgICB2YWx1ZT17dmFsdWV9XG4gICAgICBjbGFzc05hbWU9XCJtaW4taC0xMSBmbGV4LW5vbmUgcm91bmRlZC1ub25lIGJvcmRlci0wIGJvcmRlci1iLTIgYm9yZGVyLXRyYW5zcGFyZW50IHB4LTAgdGV4dC1zbSB0ZXh0LWZvcmVncm91bmQgYWZ0ZXI6aGlkZGVuIGRhdGEtW3N0YXRlPWFjdGl2ZV06Ym9yZGVyLXByaW1hcnkgZGF0YS1bc3RhdGU9YWN0aXZlXTpmb250LWJvbGQgZGF0YS1bc3RhdGU9YWN0aXZlXTp0ZXh0LXRleHQtYWNjZW50IG1kOnRleHQtWzE3cHhdXCJcbiAgICA+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9UYWJzVHJpZ2dlcj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2ZpbGlwZWNhdmFsY2FudGUvRG9jdW1lbnRzL0p1bmdsZUdhbWluZ1Rlc3RlL3NyYy9mZWF0dXJlcy9uZnQtZGV0YWlsL2NvbXBvbmVudHMvRGV0YWlsVGFiVHJpZ2dlci50c3gifQ==