import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/ReviewsPagination.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Button } from "/src/components/ui/button.tsx";
export function ReviewsPagination({ page, pages, change, pending }) {
  if (pages < 2) return null;
  return /* @__PURE__ */ jsxDEV(
    "nav",
    {
      "aria-label": "Paginação das avaliações",
      className: "flex flex-wrap items-center justify-center gap-3",
      children: [
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "secondary",
            disabled: pending || page === 1,
            "aria-label": "Avaliações anteriores",
            onClick: () => {
              change(page - 1);
            },
            children: "Anterior"
          },
          void 0,
          false,
          {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewsPagination.tsx",
            lineNumber: 17,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-text-secondary", role: "status", children: [
          "Página ",
          page,
          " de ",
          pages
        ] }, void 0, true, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewsPagination.tsx",
          lineNumber: 27,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            variant: "secondary",
            disabled: pending || page === pages,
            "aria-label": "Próximas avaliações",
            onClick: () => {
              change(page + 1);
            },
            children: "Próxima"
          },
          void 0,
          false,
          {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewsPagination.tsx",
            lineNumber: 30,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewsPagination.tsx",
      lineNumber: 13,
      columnNumber: 5
    },
    this
  );
}
_c = ReviewsPagination;
var _c;
$RefreshReg$(_c, "ReviewsPagination");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewsPagination.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewsPagination.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/ReviewsPagination.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JNO0FBaEJOLFNBQVNBLGNBQWM7QUFTaEIsZ0JBQVNDLGtCQUFrQixFQUFFQyxNQUFNQyxPQUFPQyxRQUFRQyxRQUFnQyxHQUFHO0FBQzFGLE1BQUlGLFFBQVEsRUFBRyxRQUFPO0FBQ3RCLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLGNBQVc7QUFBQSxNQUNYLFdBQVU7QUFBQSxNQUVWO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVE7QUFBQSxZQUNSLFVBQVVFLFdBQVdILFNBQVM7QUFBQSxZQUM5QixjQUFXO0FBQUEsWUFDWCxTQUFTLE1BQU07QUFDYkUscUJBQU9GLE9BQU8sQ0FBQztBQUFBLFlBQ2pCO0FBQUEsWUFBRTtBQUFBO0FBQUEsVUFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFTQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLCtCQUE4QixNQUFLLFVBQVE7QUFBQTtBQUFBLFVBQzlDQTtBQUFBQSxVQUFLO0FBQUEsVUFBS0M7QUFBQUEsYUFEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUTtBQUFBLFlBQ1IsVUFBVUUsV0FBV0gsU0FBU0M7QUFBQUEsWUFDOUIsY0FBVztBQUFBLFlBQ1gsU0FBUyxNQUFNO0FBQ2JDLHFCQUFPRixPQUFPLENBQUM7QUFBQSxZQUNqQjtBQUFBLFlBQUU7QUFBQTtBQUFBLFVBTko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBU0E7QUFBQTtBQUFBO0FBQUEsSUExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBMkJBO0FBRUo7QUFBQ0ksS0FoQ2VMO0FBQWlCLElBQUFLO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkJ1dHRvbiIsIlJldmlld3NQYWdpbmF0aW9uIiwicGFnZSIsInBhZ2VzIiwiY2hhbmdlIiwicGVuZGluZyIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlJldmlld3NQYWdpbmF0aW9uLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJztcblxuaW50ZXJmYWNlIFJldmlld3NQYWdpbmF0aW9uUHJvcHMge1xuICBwYWdlOiBudW1iZXI7XG4gIHBhZ2VzOiBudW1iZXI7XG4gIGNoYW5nZTogKHBhZ2U6IG51bWJlcikgPT4gdm9pZDtcbiAgcGVuZGluZzogYm9vbGVhbjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFJldmlld3NQYWdpbmF0aW9uKHsgcGFnZSwgcGFnZXMsIGNoYW5nZSwgcGVuZGluZyB9OiBSZXZpZXdzUGFnaW5hdGlvblByb3BzKSB7XG4gIGlmIChwYWdlcyA8IDIpIHJldHVybiBudWxsO1xuICByZXR1cm4gKFxuICAgIDxuYXZcbiAgICAgIGFyaWEtbGFiZWw9XCJQYWdpbmHDp8OjbyBkYXMgYXZhbGlhw6fDtWVzXCJcbiAgICAgIGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtM1wiXG4gICAgPlxuICAgICAgPEJ1dHRvblxuICAgICAgICB2YXJpYW50PVwic2Vjb25kYXJ5XCJcbiAgICAgICAgZGlzYWJsZWQ9e3BlbmRpbmcgfHwgcGFnZSA9PT0gMX1cbiAgICAgICAgYXJpYS1sYWJlbD1cIkF2YWxpYcOnw7VlcyBhbnRlcmlvcmVzXCJcbiAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgIGNoYW5nZShwYWdlIC0gMSk7XG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIEFudGVyaW9yXG4gICAgICA8L0J1dHRvbj5cbiAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC10ZXh0LXNlY29uZGFyeVwiIHJvbGU9XCJzdGF0dXNcIj5cbiAgICAgICAgUMOhZ2luYSB7cGFnZX0gZGUge3BhZ2VzfVxuICAgICAgPC9wPlxuICAgICAgPEJ1dHRvblxuICAgICAgICB2YXJpYW50PVwic2Vjb25kYXJ5XCJcbiAgICAgICAgZGlzYWJsZWQ9e3BlbmRpbmcgfHwgcGFnZSA9PT0gcGFnZXN9XG4gICAgICAgIGFyaWEtbGFiZWw9XCJQcsOzeGltYXMgYXZhbGlhw6fDtWVzXCJcbiAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgIGNoYW5nZShwYWdlICsgMSk7XG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIFByw7N4aW1hXG4gICAgICA8L0J1dHRvbj5cbiAgICA8L25hdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2ZpbGlwZWNhdmFsY2FudGUvRG9jdW1lbnRzL0p1bmdsZUdhbWluZ1Rlc3RlL3NyYy9mZWF0dXJlcy9uZnQtZGV0YWlsL2NvbXBvbmVudHMvUmV2aWV3c1BhZ2luYXRpb24udHN4In0=