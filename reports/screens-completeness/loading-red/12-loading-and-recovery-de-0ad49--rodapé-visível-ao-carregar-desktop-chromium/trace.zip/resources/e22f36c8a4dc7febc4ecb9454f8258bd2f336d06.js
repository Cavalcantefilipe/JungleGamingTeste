import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/GalleryZoom.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { FigmaIcon } from "/src/components/icons/FigmaIcon.tsx";
import { ArtworkImage } from "/src/components/media/ArtworkImage.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Dialog, DialogContent, DialogTitle, DialogTrigger } from "/src/components/ui/dialog.tsx";
export function GalleryZoom({ image }) {
  if (!image) return null;
  return /* @__PURE__ */ jsxDEV(Dialog, { children: [
    /* @__PURE__ */ jsxDEV(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxDEV(
      Button,
      {
        variant: "zoom",
        size: "icon",
        "aria-label": "Ampliar imagem",
        className: "absolute top-2 right-2 hidden lg:inline-flex",
        children: /* @__PURE__ */ jsxDEV(FigmaIcon, { name: "search", size: 24 }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/GalleryZoom.tsx",
          lineNumber: 18,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/GalleryZoom.tsx",
        lineNumber: 12,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/GalleryZoom.tsx",
      lineNumber: 11,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(DialogContent, { "aria-describedby": void 0, className: "bg-surface-card sm:max-w-3xl", children: [
      /* @__PURE__ */ jsxDEV(DialogTitle, { children: "Imagem ampliada" }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/GalleryZoom.tsx",
        lineNumber: 22,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        ArtworkImage,
        {
          src: image.src,
          alt: image.alt,
          width: image.width,
          height: image.height,
          sizes: "(min-width: 768px) 720px, calc(100vw - 80px)",
          className: "max-h-[75dvh] w-full rounded-media object-contain"
        },
        void 0,
        false,
        {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/GalleryZoom.tsx",
          lineNumber: 23,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/GalleryZoom.tsx",
      lineNumber: 21,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/GalleryZoom.tsx",
    lineNumber: 10,
    columnNumber: 5
  }, this);
}
_c = GalleryZoom;
var _c;
$RefreshReg$(_c, "GalleryZoom");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/GalleryZoom.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/GalleryZoom.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/GalleryZoom.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJVO0FBakJWLFNBQVNBLGlCQUFpQjtBQUMxQixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxRQUFRQyxlQUFlQyxhQUFhQyxxQkFBcUI7QUFHM0QsZ0JBQVNDLFlBQVksRUFBRUMsTUFBdUMsR0FBRztBQUN0RSxNQUFJLENBQUNBLE1BQU8sUUFBTztBQUNuQixTQUNFLHVCQUFDLFVBQ0M7QUFBQSwyQkFBQyxpQkFBYyxTQUFPLE1BQ3BCO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFRO0FBQUEsUUFDUixNQUFLO0FBQUEsUUFDTCxjQUFXO0FBQUEsUUFDWCxXQUFVO0FBQUEsUUFFVixpQ0FBQyxhQUFVLE1BQUssVUFBUyxNQUFNLE1BQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0M7QUFBQTtBQUFBLE1BTnBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFDQSx1QkFBQyxpQkFBYyxvQkFBa0JDLFFBQVcsV0FBVSxnQ0FDcEQ7QUFBQSw2QkFBQyxlQUFZLCtCQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEI7QUFBQSxNQUM1QjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsS0FBS0QsTUFBTUU7QUFBQUEsVUFDWCxLQUFLRixNQUFNRztBQUFBQSxVQUNYLE9BQU9ILE1BQU1JO0FBQUFBLFVBQ2IsUUFBUUosTUFBTUs7QUFBQUEsVUFDZCxPQUFNO0FBQUEsVUFDTixXQUFVO0FBQUE7QUFBQSxRQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU0rRDtBQUFBLFNBUmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLE9BckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzQkE7QUFFSjtBQUFDQyxLQTNCZVA7QUFBVyxJQUFBTztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJGaWdtYUljb24iLCJBcnR3b3JrSW1hZ2UiLCJCdXR0b24iLCJEaWFsb2ciLCJEaWFsb2dDb250ZW50IiwiRGlhbG9nVGl0bGUiLCJEaWFsb2dUcmlnZ2VyIiwiR2FsbGVyeVpvb20iLCJpbWFnZSIsInVuZGVmaW5lZCIsInNyYyIsImFsdCIsIndpZHRoIiwiaGVpZ2h0IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiR2FsbGVyeVpvb20udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZpZ21hSWNvbiB9IGZyb20gJ0AvY29tcG9uZW50cy9pY29ucy9GaWdtYUljb24nO1xuaW1wb3J0IHsgQXJ0d29ya0ltYWdlIH0gZnJvbSAnQC9jb21wb25lbnRzL21lZGlhL0FydHdvcmtJbWFnZSc7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJztcbmltcG9ydCB7IERpYWxvZywgRGlhbG9nQ29udGVudCwgRGlhbG9nVGl0bGUsIERpYWxvZ1RyaWdnZXIgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvZGlhbG9nJztcbmltcG9ydCB0eXBlIHsgTmZ0SW1hZ2UgfSBmcm9tICdAL2NvbnRyYWN0cy9uZnQnO1xuXG5leHBvcnQgZnVuY3Rpb24gR2FsbGVyeVpvb20oeyBpbWFnZSB9OiB7IGltYWdlOiBOZnRJbWFnZSB8IHVuZGVmaW5lZCB9KSB7XG4gIGlmICghaW1hZ2UpIHJldHVybiBudWxsO1xuICByZXR1cm4gKFxuICAgIDxEaWFsb2c+XG4gICAgICA8RGlhbG9nVHJpZ2dlciBhc0NoaWxkPlxuICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgdmFyaWFudD1cInpvb21cIlxuICAgICAgICAgIHNpemU9XCJpY29uXCJcbiAgICAgICAgICBhcmlhLWxhYmVsPVwiQW1wbGlhciBpbWFnZW1cIlxuICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0yIHJpZ2h0LTIgaGlkZGVuIGxnOmlubGluZS1mbGV4XCJcbiAgICAgICAgPlxuICAgICAgICAgIDxGaWdtYUljb24gbmFtZT1cInNlYXJjaFwiIHNpemU9ezI0fSAvPlxuICAgICAgICA8L0J1dHRvbj5cbiAgICAgIDwvRGlhbG9nVHJpZ2dlcj5cbiAgICAgIDxEaWFsb2dDb250ZW50IGFyaWEtZGVzY3JpYmVkYnk9e3VuZGVmaW5lZH0gY2xhc3NOYW1lPVwiYmctc3VyZmFjZS1jYXJkIHNtOm1heC13LTN4bFwiPlxuICAgICAgICA8RGlhbG9nVGl0bGU+SW1hZ2VtIGFtcGxpYWRhPC9EaWFsb2dUaXRsZT5cbiAgICAgICAgPEFydHdvcmtJbWFnZVxuICAgICAgICAgIHNyYz17aW1hZ2Uuc3JjfVxuICAgICAgICAgIGFsdD17aW1hZ2UuYWx0fVxuICAgICAgICAgIHdpZHRoPXtpbWFnZS53aWR0aH1cbiAgICAgICAgICBoZWlnaHQ9e2ltYWdlLmhlaWdodH1cbiAgICAgICAgICBzaXplcz1cIihtaW4td2lkdGg6IDc2OHB4KSA3MjBweCwgY2FsYygxMDB2dyAtIDgwcHgpXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJtYXgtaC1bNzVkdmhdIHctZnVsbCByb3VuZGVkLW1lZGlhIG9iamVjdC1jb250YWluXCJcbiAgICAgICAgLz5cbiAgICAgIDwvRGlhbG9nQ29udGVudD5cbiAgICA8L0RpYWxvZz5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2ZpbGlwZWNhdmFsY2FudGUvRG9jdW1lbnRzL0p1bmdsZUdhbWluZ1Rlc3RlL3NyYy9mZWF0dXJlcy9uZnQtZGV0YWlsL2NvbXBvbmVudHMvR2FsbGVyeVpvb20udHN4In0=