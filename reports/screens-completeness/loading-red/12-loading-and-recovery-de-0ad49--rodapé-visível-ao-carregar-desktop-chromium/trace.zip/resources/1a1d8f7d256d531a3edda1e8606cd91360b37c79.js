import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/NftDetailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { DetailMobileNavigation } from "/src/features/nft-detail/components/DetailMobileNavigation.tsx";
import { DetailSummary } from "/src/features/nft-detail/components/DetailSummary.tsx";
import { DetailTabs } from "/src/features/nft-detail/components/DetailTabs.tsx";
import { Gallery } from "/src/features/nft-detail/components/Gallery.tsx";
import { RelatedCarousel } from "/src/features/nft-detail/components/RelatedCarousel.tsx";
export function NftDetailPage({ nft }) {
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        "data-testid": "detail-background",
        "aria-hidden": "true",
        className: "pointer-events-none absolute inset-x-0 top-0 -z-10 h-[506px] bg-detail-gradient md:hidden"
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/NftDetailPage.tsx",
        lineNumber: 12,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(DetailMobileNavigation, { nft }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/NftDetailPage.tsx",
      lineNumber: 17,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "mb-3 hidden text-body-sm font-bold md:block", children: "Início / Mercado" }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/NftDetailPage.tsx",
      lineNumber: 18,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid items-start gap-0 lg:grid-cols-[573px_minmax(0,1fr)] lg:gap-8", children: [
      /* @__PURE__ */ jsxDEV(Gallery, { images: nft.images }, nft.id, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/NftDetailPage.tsx",
        lineNumber: 20,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DetailSummary, { nft }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/NftDetailPage.tsx",
        lineNumber: 21,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/NftDetailPage.tsx",
      lineNumber: 19,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(DetailTabs, { nft }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/NftDetailPage.tsx",
      lineNumber: 23,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(RelatedCarousel, { nft }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/NftDetailPage.tsx",
      lineNumber: 24,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "h-44 lg:hidden" }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/NftDetailPage.tsx",
      lineNumber: 25,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/NftDetailPage.tsx",
    lineNumber: 11,
    columnNumber: 5
  }, this);
}
_c = NftDetailPage;
var _c;
$RefreshReg$(_c, "NftDetailPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/NftDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/NftDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/NftDetailPage.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVUksbUJBQ0UsY0FERjtBQVJKLFNBQVNBLDhCQUE4QjtBQUN2QyxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsdUJBQXVCO0FBRXpCLGdCQUFTQyxjQUFjLEVBQUVDLElBQWtCLEdBQUc7QUFDbkQsU0FDRSxtQ0FDRTtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxlQUFZO0FBQUEsUUFDWixlQUFZO0FBQUEsUUFDWixXQUFVO0FBQUE7QUFBQSxNQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUd1RztBQUFBLElBRXZHLHVCQUFDLDBCQUF1QixPQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlDO0FBQUEsSUFDakMsdUJBQUMsT0FBRSxXQUFVLCtDQUE4QyxnQ0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyRTtBQUFBLElBQzNFLHVCQUFDLFNBQUksV0FBVSxzRUFDYjtBQUFBLDZCQUFDLFdBQXFCLFFBQVFBLElBQUlDLFVBQXBCRCxJQUFJRSxJQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlDO0FBQUEsTUFDekMsdUJBQUMsaUJBQWMsT0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdCO0FBQUEsU0FGMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxjQUFXLE9BQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQjtBQUFBLElBQ3JCLHVCQUFDLG1CQUFnQixPQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBCO0FBQUEsSUFDMUIsdUJBQUMsU0FBSSxXQUFVLG9CQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0I7QUFBQSxPQWRqQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZUE7QUFFSjtBQUFDQyxLQW5CZUo7QUFBYSxJQUFBSTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJEZXRhaWxNb2JpbGVOYXZpZ2F0aW9uIiwiRGV0YWlsU3VtbWFyeSIsIkRldGFpbFRhYnMiLCJHYWxsZXJ5IiwiUmVsYXRlZENhcm91c2VsIiwiTmZ0RGV0YWlsUGFnZSIsIm5mdCIsImltYWdlcyIsImlkIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTmZ0RGV0YWlsUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBOZnQgfSBmcm9tICdAL2NvbnRyYWN0cy9uZnQnO1xuXG5pbXBvcnQgeyBEZXRhaWxNb2JpbGVOYXZpZ2F0aW9uIH0gZnJvbSAnLi9EZXRhaWxNb2JpbGVOYXZpZ2F0aW9uJztcbmltcG9ydCB7IERldGFpbFN1bW1hcnkgfSBmcm9tICcuL0RldGFpbFN1bW1hcnknO1xuaW1wb3J0IHsgRGV0YWlsVGFicyB9IGZyb20gJy4vRGV0YWlsVGFicyc7XG5pbXBvcnQgeyBHYWxsZXJ5IH0gZnJvbSAnLi9HYWxsZXJ5JztcbmltcG9ydCB7IFJlbGF0ZWRDYXJvdXNlbCB9IGZyb20gJy4vUmVsYXRlZENhcm91c2VsJztcblxuZXhwb3J0IGZ1bmN0aW9uIE5mdERldGFpbFBhZ2UoeyBuZnQgfTogeyBuZnQ6IE5mdCB9KSB7XG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxkaXZcbiAgICAgICAgZGF0YS10ZXN0aWQ9XCJkZXRhaWwtYmFja2dyb3VuZFwiXG4gICAgICAgIGFyaWEtaGlkZGVuPVwidHJ1ZVwiXG4gICAgICAgIGNsYXNzTmFtZT1cInBvaW50ZXItZXZlbnRzLW5vbmUgYWJzb2x1dGUgaW5zZXQteC0wIHRvcC0wIC16LTEwIGgtWzUwNnB4XSBiZy1kZXRhaWwtZ3JhZGllbnQgbWQ6aGlkZGVuXCJcbiAgICAgIC8+XG4gICAgICA8RGV0YWlsTW9iaWxlTmF2aWdhdGlvbiBuZnQ9e25mdH0gLz5cbiAgICAgIDxwIGNsYXNzTmFtZT1cIm1iLTMgaGlkZGVuIHRleHQtYm9keS1zbSBmb250LWJvbGQgbWQ6YmxvY2tcIj5JbsOtY2lvIC8gTWVyY2FkbzwvcD5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBpdGVtcy1zdGFydCBnYXAtMCBsZzpncmlkLWNvbHMtWzU3M3B4X21pbm1heCgwLDFmcildIGxnOmdhcC04XCI+XG4gICAgICAgIDxHYWxsZXJ5IGtleT17bmZ0LmlkfSBpbWFnZXM9e25mdC5pbWFnZXN9IC8+XG4gICAgICAgIDxEZXRhaWxTdW1tYXJ5IG5mdD17bmZ0fSAvPlxuICAgICAgPC9kaXY+XG4gICAgICA8RGV0YWlsVGFicyBuZnQ9e25mdH0gLz5cbiAgICAgIDxSZWxhdGVkQ2Fyb3VzZWwgbmZ0PXtuZnR9IC8+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtNDQgbGc6aGlkZGVuXCIgLz5cbiAgICA8Lz5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2ZpbGlwZWNhdmFsY2FudGUvRG9jdW1lbnRzL0p1bmdsZUdhbWluZ1Rlc3RlL3NyYy9mZWF0dXJlcy9uZnQtZGV0YWlsL2NvbXBvbmVudHMvTmZ0RGV0YWlsUGFnZS50c3gifQ==