import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/DetailTabs.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { Tabs, TabsContent, TabsList } from "/src/components/ui/tabs.tsx";
import { useDetailNavigation } from "/src/features/nft-detail/useDetailNavigation.ts";
import { BuyerReviews } from "/src/features/nft-detail/components/BuyerReviews.tsx";
import { DetailFacts } from "/src/features/nft-detail/components/DetailFacts.tsx";
import { DetailTabTrigger } from "/src/features/nft-detail/components/DetailTabTrigger.tsx";
export function DetailTabs({ nft }) {
  _s();
  const { tab, setTab } = useDetailNavigation();
  return /* @__PURE__ */ jsxDEV(Tabs, { value: tab, onValueChange: setTab, className: "mt-section", children: [
    /* @__PURE__ */ jsxDEV(
      TabsList,
      {
        variant: "line",
        className: "h-auto w-full flex-wrap justify-start gap-x-8 rounded-none border-b border-border p-0 group-data-[orientation=horizontal]/tabs:h-auto",
        children: [
          /* @__PURE__ */ jsxDEV(DetailTabTrigger, { value: "details", children: "Detalhes do NFT" }, void 0, false, {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailTabs.tsx",
            lineNumber: 17,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(DetailTabTrigger, { value: "reviews", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "md:hidden", children: [
              "Avaliações (",
              nft.rating.count,
              ")"
            ] }, void 0, true, {
              fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailTabs.tsx",
              lineNumber: 19,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "hidden md:inline", children: [
              "Avaliações de colecionadores (",
              nft.rating.count,
              ")"
            ] }, void 0, true, {
              fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailTabs.tsx",
              lineNumber: 20,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailTabs.tsx",
            lineNumber: 18,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailTabs.tsx",
        lineNumber: 13,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(TabsContent, { value: "details", children: /* @__PURE__ */ jsxDEV(DetailFacts, { nft }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailTabs.tsx",
      lineNumber: 26,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailTabs.tsx",
      lineNumber: 25,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TabsContent, { value: "reviews", children: /* @__PURE__ */ jsxDEV(BuyerReviews, { nft }, nft.id, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailTabs.tsx",
      lineNumber: 29,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailTabs.tsx",
      lineNumber: 28,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailTabs.tsx",
    lineNumber: 12,
    columnNumber: 5
  }, this);
}
_s(DetailTabs, "y7zgqXGrQqmrShkjp2duY7YF5YE=", false, function() {
  return [useDetailNavigation];
});
_c = DetailTabs;
var _c;
$RefreshReg$(_c, "DetailTabs");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailTabs.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailTabs.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/DetailTabs.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JROztBQWhCUixTQUFTQSxNQUFNQyxhQUFhQyxnQkFBZ0I7QUFHNUMsU0FBU0MsMkJBQTJCO0FBQ3BDLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0Msd0JBQXdCO0FBRTFCLGdCQUFTQyxXQUFXLEVBQUVDLElBQWtCLEdBQUc7QUFBQUMsS0FBQTtBQUNoRCxRQUFNLEVBQUVDLEtBQUtDLE9BQU8sSUFBSVIsb0JBQW9CO0FBQzVDLFNBQ0UsdUJBQUMsUUFBSyxPQUFPTyxLQUFLLGVBQWVDLFFBQVEsV0FBVSxjQUNqRDtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFRO0FBQUEsUUFDUixXQUFVO0FBQUEsUUFFVjtBQUFBLGlDQUFDLG9CQUFpQixPQUFNLFdBQVUsK0JBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlEO0FBQUEsVUFDakQsdUJBQUMsb0JBQWlCLE9BQU0sV0FDdEI7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsYUFBWTtBQUFBO0FBQUEsY0FBYUgsSUFBSUksT0FBT0M7QUFBQUEsY0FBTTtBQUFBLGlCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRDtBQUFBLFlBQzNELHVCQUFDLFVBQUssV0FBVSxvQkFBa0I7QUFBQTtBQUFBLGNBQ0RMLElBQUlJLE9BQU9DO0FBQUFBLGNBQU07QUFBQSxpQkFEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBO0FBQUE7QUFBQSxNQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVdBO0FBQUEsSUFDQSx1QkFBQyxlQUFZLE9BQU0sV0FDakIsaUNBQUMsZUFBWSxPQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0IsS0FEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxlQUFZLE9BQU0sV0FDakIsaUNBQUMsZ0JBQTBCLE9BQVJMLElBQUlNLElBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0MsS0FEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1CQTtBQUVKO0FBQUNMLEdBeEJlRixZQUFVO0FBQUEsVUFDQUosbUJBQW1CO0FBQUE7QUFBQSxLQUQ3Qkk7QUFBVSxJQUFBUTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJUYWJzIiwiVGFic0NvbnRlbnQiLCJUYWJzTGlzdCIsInVzZURldGFpbE5hdmlnYXRpb24iLCJCdXllclJldmlld3MiLCJEZXRhaWxGYWN0cyIsIkRldGFpbFRhYlRyaWdnZXIiLCJEZXRhaWxUYWJzIiwibmZ0IiwiX3MiLCJ0YWIiLCJzZXRUYWIiLCJyYXRpbmciLCJjb3VudCIsImlkIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRGV0YWlsVGFicy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgVGFicywgVGFic0NvbnRlbnQsIFRhYnNMaXN0IH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL3RhYnMnO1xuaW1wb3J0IHR5cGUgeyBOZnQgfSBmcm9tICdAL2NvbnRyYWN0cy9uZnQnO1xuXG5pbXBvcnQgeyB1c2VEZXRhaWxOYXZpZ2F0aW9uIH0gZnJvbSAnLi4vdXNlRGV0YWlsTmF2aWdhdGlvbic7XG5pbXBvcnQgeyBCdXllclJldmlld3MgfSBmcm9tICcuL0J1eWVyUmV2aWV3cyc7XG5pbXBvcnQgeyBEZXRhaWxGYWN0cyB9IGZyb20gJy4vRGV0YWlsRmFjdHMnO1xuaW1wb3J0IHsgRGV0YWlsVGFiVHJpZ2dlciB9IGZyb20gJy4vRGV0YWlsVGFiVHJpZ2dlcic7XG5cbmV4cG9ydCBmdW5jdGlvbiBEZXRhaWxUYWJzKHsgbmZ0IH06IHsgbmZ0OiBOZnQgfSkge1xuICBjb25zdCB7IHRhYiwgc2V0VGFiIH0gPSB1c2VEZXRhaWxOYXZpZ2F0aW9uKCk7XG4gIHJldHVybiAoXG4gICAgPFRhYnMgdmFsdWU9e3RhYn0gb25WYWx1ZUNoYW5nZT17c2V0VGFifSBjbGFzc05hbWU9XCJtdC1zZWN0aW9uXCI+XG4gICAgICA8VGFic0xpc3RcbiAgICAgICAgdmFyaWFudD1cImxpbmVcIlxuICAgICAgICBjbGFzc05hbWU9XCJoLWF1dG8gdy1mdWxsIGZsZXgtd3JhcCBqdXN0aWZ5LXN0YXJ0IGdhcC14LTggcm91bmRlZC1ub25lIGJvcmRlci1iIGJvcmRlci1ib3JkZXIgcC0wIGdyb3VwLWRhdGEtW29yaWVudGF0aW9uPWhvcml6b250YWxdL3RhYnM6aC1hdXRvXCJcbiAgICAgID5cbiAgICAgICAgPERldGFpbFRhYlRyaWdnZXIgdmFsdWU9XCJkZXRhaWxzXCI+RGV0YWxoZXMgZG8gTkZUPC9EZXRhaWxUYWJUcmlnZ2VyPlxuICAgICAgICA8RGV0YWlsVGFiVHJpZ2dlciB2YWx1ZT1cInJldmlld3NcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtZDpoaWRkZW5cIj5BdmFsaWHDp8O1ZXMgKHtuZnQucmF0aW5nLmNvdW50fSk8L3NwYW4+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIG1kOmlubGluZVwiPlxuICAgICAgICAgICAgQXZhbGlhw6fDtWVzIGRlIGNvbGVjaW9uYWRvcmVzICh7bmZ0LnJhdGluZy5jb3VudH0pXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L0RldGFpbFRhYlRyaWdnZXI+XG4gICAgICA8L1RhYnNMaXN0PlxuICAgICAgPFRhYnNDb250ZW50IHZhbHVlPVwiZGV0YWlsc1wiPlxuICAgICAgICA8RGV0YWlsRmFjdHMgbmZ0PXtuZnR9IC8+XG4gICAgICA8L1RhYnNDb250ZW50PlxuICAgICAgPFRhYnNDb250ZW50IHZhbHVlPVwicmV2aWV3c1wiPlxuICAgICAgICA8QnV5ZXJSZXZpZXdzIGtleT17bmZ0LmlkfSBuZnQ9e25mdH0gLz5cbiAgICAgIDwvVGFic0NvbnRlbnQ+XG4gICAgPC9UYWJzPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvZmlsaXBlY2F2YWxjYW50ZS9Eb2N1bWVudHMvSnVuZ2xlR2FtaW5nVGVzdGUvc3JjL2ZlYXR1cmVzL25mdC1kZXRhaWwvY29tcG9uZW50cy9EZXRhaWxUYWJzLnRzeCJ9