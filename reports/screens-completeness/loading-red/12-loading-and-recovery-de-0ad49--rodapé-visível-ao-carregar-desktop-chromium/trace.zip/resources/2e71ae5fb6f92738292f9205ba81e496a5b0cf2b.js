import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/NftCarousel.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=970a124b"; const useId = __vite__cjsImport1_react["useId"];
import { useCarousel } from "/src/features/catalog/useCarousel.ts";
import { useCarouselAutoplay } from "/src/features/catalog/useCarouselAutoplay.ts";
import { CarouselDots } from "/src/features/catalog/components/CarouselDots.tsx";
import { CarouselNavigation } from "/src/features/catalog/components/CarouselNavigation.tsx";
import { CarouselPlayback } from "/src/features/catalog/components/CarouselPlayback.tsx";
import { CarouselTrack } from "/src/features/catalog/components/CarouselTrack.tsx";
export function NftCarousel({ title, items }) {
  _s();
  const headingId = useId();
  const { track, onScroll, ...navigation } = useCarousel(items.length);
  const { container, playing, toggle } = useCarouselAutoplay(navigation);
  return /* @__PURE__ */ jsxDEV("section", { ref: container, "aria-labelledby": headingId, "aria-roledescription": "carrossel", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mb-2 flex items-center justify-between gap-3 border-b border-border pb-3", children: [
      /* @__PURE__ */ jsxDEV("h2", { id: headingId, className: "text-section font-bold text-text-accent", children: title }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCarousel.tsx",
        lineNumber: 19,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(CarouselNavigation, { ...navigation }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCarousel.tsx",
        lineNumber: 22,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCarousel.tsx",
      lineNumber: 18,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CarouselTrack, { title, items, track, onScroll }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCarousel.tsx",
      lineNumber: 24,
      columnNumber: 7
    }, this),
    navigation.pages > 1 && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-[44px_minmax(0,1fr)_44px] items-center", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "col-start-2", children: /* @__PURE__ */ jsxDEV(CarouselDots, { ...navigation }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCarousel.tsx",
        lineNumber: 28,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCarousel.tsx",
        lineNumber: 27,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(CarouselPlayback, { playing, toggle }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCarousel.tsx",
        lineNumber: 30,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCarousel.tsx",
      lineNumber: 26,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCarousel.tsx",
    lineNumber: 17,
    columnNumber: 5
  }, this);
}
_s(NftCarousel, "cyux7ZaF84djOVY1MyvWh8uTgGw=", false, function() {
  return [useCarousel, useCarouselAutoplay];
});
_c = NftCarousel;
var _c;
$RefreshReg$(_c, "NftCarousel");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCarousel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCarousel.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCarousel.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JROztBQWxCUixTQUFTQSxhQUFhO0FBSXRCLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyx3QkFBd0I7QUFDakMsU0FBU0MscUJBQXFCO0FBRXZCLGdCQUFTQyxZQUFZLEVBQUVDLE9BQU9DLE1BQXVDLEdBQUc7QUFBQUMsS0FBQTtBQUM3RSxRQUFNQyxZQUFZWCxNQUFNO0FBQ3hCLFFBQU0sRUFBRVksT0FBT0MsVUFBVSxHQUFHQyxXQUFXLElBQUliLFlBQVlRLE1BQU1NLE1BQU07QUFDbkUsUUFBTSxFQUFFQyxXQUFXQyxTQUFTQyxPQUFPLElBQUloQixvQkFBb0JZLFVBQVU7QUFDckUsU0FDRSx1QkFBQyxhQUFRLEtBQUtFLFdBQVcsbUJBQWlCTCxXQUFXLHdCQUFxQixhQUN4RTtBQUFBLDJCQUFDLFNBQUksV0FBVSw0RUFDYjtBQUFBLDZCQUFDLFFBQUcsSUFBSUEsV0FBVyxXQUFVLDJDQUMxQkgsbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxzQkFBbUIsR0FBSU0sY0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtQztBQUFBLFNBSnJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBQ0EsdUJBQUMsaUJBQWMsT0FBYyxPQUFjLE9BQWMsWUFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE0RTtBQUFBLElBQzNFQSxXQUFXSyxRQUFRLEtBQ2xCLHVCQUFDLFNBQUksV0FBVSx5REFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxlQUNiLGlDQUFDLGdCQUFhLEdBQUlMLGNBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkIsS0FEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxvQkFBaUIsU0FBa0IsVUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRDtBQUFBLFNBSnJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLE9BZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdCQTtBQUVKO0FBQUNKLEdBdkJlSCxhQUFXO0FBQUEsVUFFa0JOLGFBQ0pDLG1CQUFtQjtBQUFBO0FBQUEsS0FINUNLO0FBQVcsSUFBQWE7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlSWQiLCJ1c2VDYXJvdXNlbCIsInVzZUNhcm91c2VsQXV0b3BsYXkiLCJDYXJvdXNlbERvdHMiLCJDYXJvdXNlbE5hdmlnYXRpb24iLCJDYXJvdXNlbFBsYXliYWNrIiwiQ2Fyb3VzZWxUcmFjayIsIk5mdENhcm91c2VsIiwidGl0bGUiLCJpdGVtcyIsIl9zIiwiaGVhZGluZ0lkIiwidHJhY2siLCJvblNjcm9sbCIsIm5hdmlnYXRpb24iLCJsZW5ndGgiLCJjb250YWluZXIiLCJwbGF5aW5nIiwidG9nZ2xlIiwicGFnZXMiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJOZnRDYXJvdXNlbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlSWQgfSBmcm9tICdyZWFjdCc7XG5cbmltcG9ydCB0eXBlIHsgTmZ0IH0gZnJvbSAnQC9jb250cmFjdHMvbmZ0JztcblxuaW1wb3J0IHsgdXNlQ2Fyb3VzZWwgfSBmcm9tICcuLi91c2VDYXJvdXNlbCc7XG5pbXBvcnQgeyB1c2VDYXJvdXNlbEF1dG9wbGF5IH0gZnJvbSAnLi4vdXNlQ2Fyb3VzZWxBdXRvcGxheSc7XG5pbXBvcnQgeyBDYXJvdXNlbERvdHMgfSBmcm9tICcuL0Nhcm91c2VsRG90cyc7XG5pbXBvcnQgeyBDYXJvdXNlbE5hdmlnYXRpb24gfSBmcm9tICcuL0Nhcm91c2VsTmF2aWdhdGlvbic7XG5pbXBvcnQgeyBDYXJvdXNlbFBsYXliYWNrIH0gZnJvbSAnLi9DYXJvdXNlbFBsYXliYWNrJztcbmltcG9ydCB7IENhcm91c2VsVHJhY2sgfSBmcm9tICcuL0Nhcm91c2VsVHJhY2snO1xuXG5leHBvcnQgZnVuY3Rpb24gTmZ0Q2Fyb3VzZWwoeyB0aXRsZSwgaXRlbXMgfTogeyB0aXRsZTogc3RyaW5nOyBpdGVtczogTmZ0W10gfSkge1xuICBjb25zdCBoZWFkaW5nSWQgPSB1c2VJZCgpO1xuICBjb25zdCB7IHRyYWNrLCBvblNjcm9sbCwgLi4ubmF2aWdhdGlvbiB9ID0gdXNlQ2Fyb3VzZWwoaXRlbXMubGVuZ3RoKTtcbiAgY29uc3QgeyBjb250YWluZXIsIHBsYXlpbmcsIHRvZ2dsZSB9ID0gdXNlQ2Fyb3VzZWxBdXRvcGxheShuYXZpZ2F0aW9uKTtcbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiByZWY9e2NvbnRhaW5lcn0gYXJpYS1sYWJlbGxlZGJ5PXtoZWFkaW5nSWR9IGFyaWEtcm9sZWRlc2NyaXB0aW9uPVwiY2Fycm9zc2VsXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIGJvcmRlci1iIGJvcmRlci1ib3JkZXIgcGItM1wiPlxuICAgICAgICA8aDIgaWQ9e2hlYWRpbmdJZH0gY2xhc3NOYW1lPVwidGV4dC1zZWN0aW9uIGZvbnQtYm9sZCB0ZXh0LXRleHQtYWNjZW50XCI+XG4gICAgICAgICAge3RpdGxlfVxuICAgICAgICA8L2gyPlxuICAgICAgICA8Q2Fyb3VzZWxOYXZpZ2F0aW9uIHsuLi5uYXZpZ2F0aW9ufSAvPlxuICAgICAgPC9kaXY+XG4gICAgICA8Q2Fyb3VzZWxUcmFjayB0aXRsZT17dGl0bGV9IGl0ZW1zPXtpdGVtc30gdHJhY2s9e3RyYWNrfSBvblNjcm9sbD17b25TY3JvbGx9IC8+XG4gICAgICB7bmF2aWdhdGlvbi5wYWdlcyA+IDEgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLVs0NHB4X21pbm1heCgwLDFmcilfNDRweF0gaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtc3RhcnQtMlwiPlxuICAgICAgICAgICAgPENhcm91c2VsRG90cyB7Li4ubmF2aWdhdGlvbn0gLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8Q2Fyb3VzZWxQbGF5YmFjayBwbGF5aW5nPXtwbGF5aW5nfSB0b2dnbGU9e3RvZ2dsZX0gLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2ZpbGlwZWNhdmFsY2FudGUvRG9jdW1lbnRzL0p1bmdsZUdhbWluZ1Rlc3RlL3NyYy9mZWF0dXJlcy9jYXRhbG9nL2NvbXBvbmVudHMvTmZ0Q2Fyb3VzZWwudHN4In0=