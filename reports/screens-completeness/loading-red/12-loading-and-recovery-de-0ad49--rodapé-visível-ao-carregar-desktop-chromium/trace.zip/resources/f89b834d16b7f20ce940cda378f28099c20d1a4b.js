import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/nft-detail/components/RatingStars.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { FigmaIcon } from "/src/components/icons/FigmaIcon.tsx";
export function RatingStars({ rating }) {
  return /* @__PURE__ */ jsxDEV("span", { role: "img", "aria-label": `Avaliação: ${rating.average} de 5`, className: "inline-flex gap-1", children: Array.from(
    { length: 5 },
    (_, index) => /* @__PURE__ */ jsxDEV(
      FigmaIcon,
      {
        name: "star-desktop",
        size: 15,
        className: index < Math.floor(rating.average) ? "text-primary" : "text-text-secondary"
      },
      index,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/RatingStars.tsx",
        lineNumber: 8,
        columnNumber: 7
      },
      this
    )
  ) }, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/RatingStars.tsx",
    lineNumber: 6,
    columnNumber: 5
  }, this);
}
_c = RatingStars;
var _c;
$RefreshReg$(_c, "RatingStars");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/RatingStars.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/RatingStars.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/nft-detail/components/RatingStars.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT1E7QUFQUixTQUFTQSxpQkFBaUI7QUFHbkIsZ0JBQVNDLFlBQVksRUFBRUMsT0FBa0MsR0FBRztBQUNqRSxTQUNFLHVCQUFDLFVBQUssTUFBSyxPQUFNLGNBQVksY0FBY0EsT0FBT0MsT0FBTyxTQUFTLFdBQVUscUJBQ3pFQyxnQkFBTUM7QUFBQUEsSUFBSyxFQUFFQyxRQUFRLEVBQUU7QUFBQSxJQUFHLENBQUNDLEdBQUdDLFVBQzdCO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFFQyxNQUFLO0FBQUEsUUFDTCxNQUFNO0FBQUEsUUFDTixXQUFXQSxRQUFRQyxLQUFLQyxNQUFNUixPQUFPQyxPQUFPLElBQUksaUJBQWlCO0FBQUE7QUFBQSxNQUg1REs7QUFBQUEsTUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSXlGO0FBQUEsRUFFMUYsS0FSSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBU0E7QUFFSjtBQUFDRyxLQWJlVjtBQUFXLElBQUFVO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkZpZ21hSWNvbiIsIlJhdGluZ1N0YXJzIiwicmF0aW5nIiwiYXZlcmFnZSIsIkFycmF5IiwiZnJvbSIsImxlbmd0aCIsIl8iLCJpbmRleCIsIk1hdGgiLCJmbG9vciIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlJhdGluZ1N0YXJzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGaWdtYUljb24gfSBmcm9tICdAL2NvbXBvbmVudHMvaWNvbnMvRmlnbWFJY29uJztcbmltcG9ydCB0eXBlIHsgTmZ0IH0gZnJvbSAnQC9jb250cmFjdHMvbmZ0JztcblxuZXhwb3J0IGZ1bmN0aW9uIFJhdGluZ1N0YXJzKHsgcmF0aW5nIH06IHsgcmF0aW5nOiBOZnRbJ3JhdGluZyddIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8c3BhbiByb2xlPVwiaW1nXCIgYXJpYS1sYWJlbD17YEF2YWxpYcOnw6NvOiAke3JhdGluZy5hdmVyYWdlfSBkZSA1YH0gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggZ2FwLTFcIj5cbiAgICAgIHtBcnJheS5mcm9tKHsgbGVuZ3RoOiA1IH0sIChfLCBpbmRleCkgPT4gKFxuICAgICAgICA8RmlnbWFJY29uXG4gICAgICAgICAga2V5PXtpbmRleH1cbiAgICAgICAgICBuYW1lPVwic3Rhci1kZXNrdG9wXCJcbiAgICAgICAgICBzaXplPXsxNX1cbiAgICAgICAgICBjbGFzc05hbWU9e2luZGV4IDwgTWF0aC5mbG9vcihyYXRpbmcuYXZlcmFnZSkgPyAndGV4dC1wcmltYXJ5JyA6ICd0ZXh0LXRleHQtc2Vjb25kYXJ5J31cbiAgICAgICAgLz5cbiAgICAgICkpfVxuICAgIDwvc3Bhbj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2ZpbGlwZWNhdmFsY2FudGUvRG9jdW1lbnRzL0p1bmdsZUdhbWluZ1Rlc3RlL3NyYy9mZWF0dXJlcy9uZnQtZGV0YWlsL2NvbXBvbmVudHMvUmF0aW5nU3RhcnMudHN4In0=