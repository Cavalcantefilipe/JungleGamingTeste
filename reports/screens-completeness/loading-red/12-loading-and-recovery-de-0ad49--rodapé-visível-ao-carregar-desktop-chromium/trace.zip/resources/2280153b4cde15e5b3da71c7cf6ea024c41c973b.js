import { useRouterState } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=970a124b";
export function useShareDestinations() {
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const url = encodeURIComponent(`${window.location.origin}${pathname}`);
  return [
    {
      icon: "linkedin",
      label: "Compartilhar no LinkedIn",
      href: `https://www.linkedin.com/sharing/share-offsite/?url=${url}`
    },
    { icon: "mail", label: "Compartilhar por e-mail", href: `mailto:?body=${url}` },
    {
      icon: "twitter",
      label: "Compartilhar no X",
      href: `https://twitter.com/intent/tweet?url=${url}`
    }
  ];
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZVNoYXJlRGVzdGluYXRpb25zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVJvdXRlclN0YXRlIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcic7XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VTaGFyZURlc3RpbmF0aW9ucygpIHtcbiAgY29uc3QgcGF0aG5hbWUgPSB1c2VSb3V0ZXJTdGF0ZSh7IHNlbGVjdDogKHN0YXRlKSA9PiBzdGF0ZS5sb2NhdGlvbi5wYXRobmFtZSB9KTtcbiAgY29uc3QgdXJsID0gZW5jb2RlVVJJQ29tcG9uZW50KGAke3dpbmRvdy5sb2NhdGlvbi5vcmlnaW59JHtwYXRobmFtZX1gKTtcbiAgcmV0dXJuIFtcbiAgICB7XG4gICAgICBpY29uOiAnbGlua2VkaW4nLFxuICAgICAgbGFiZWw6ICdDb21wYXJ0aWxoYXIgbm8gTGlua2VkSW4nLFxuICAgICAgaHJlZjogYGh0dHBzOi8vd3d3LmxpbmtlZGluLmNvbS9zaGFyaW5nL3NoYXJlLW9mZnNpdGUvP3VybD0ke3VybH1gLFxuICAgIH0sXG4gICAgeyBpY29uOiAnbWFpbCcsIGxhYmVsOiAnQ29tcGFydGlsaGFyIHBvciBlLW1haWwnLCBocmVmOiBgbWFpbHRvOj9ib2R5PSR7dXJsfWAgfSxcbiAgICB7XG4gICAgICBpY29uOiAndHdpdHRlcicsXG4gICAgICBsYWJlbDogJ0NvbXBhcnRpbGhhciBubyBYJyxcbiAgICAgIGhyZWY6IGBodHRwczovL3R3aXR0ZXIuY29tL2ludGVudC90d2VldD91cmw9JHt1cmx9YCxcbiAgICB9LFxuICBdIGFzIGNvbnN0O1xufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLHNCQUFzQjtBQUV4QixnQkFBUyx1QkFBdUI7QUFDckMsUUFBTSxXQUFXLGVBQWUsRUFBRSxRQUFRLENBQUMsVUFBVSxNQUFNLFNBQVMsU0FBUyxDQUFDO0FBQzlFLFFBQU0sTUFBTSxtQkFBbUIsR0FBRyxPQUFPLFNBQVMsTUFBTSxHQUFHLFFBQVEsRUFBRTtBQUNyRSxTQUFPO0FBQUEsSUFDTDtBQUFBLE1BQ0UsTUFBTTtBQUFBLE1BQ04sT0FBTztBQUFBLE1BQ1AsTUFBTSx1REFBdUQsR0FBRztBQUFBLElBQ2xFO0FBQUEsSUFDQSxFQUFFLE1BQU0sUUFBUSxPQUFPLDJCQUEyQixNQUFNLGdCQUFnQixHQUFHLEdBQUc7QUFBQSxJQUM5RTtBQUFBLE1BQ0UsTUFBTTtBQUFBLE1BQ04sT0FBTztBQUFBLE1BQ1AsTUFBTSx3Q0FBd0MsR0FBRztBQUFBLElBQ25EO0FBQUEsRUFDRjtBQUNGOyIsIm5hbWVzIjpbXX0=