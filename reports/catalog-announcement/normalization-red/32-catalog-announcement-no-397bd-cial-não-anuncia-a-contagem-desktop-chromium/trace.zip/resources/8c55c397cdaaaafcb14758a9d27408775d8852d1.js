import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/CatalogPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { Navigate, useRouterState } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=970a124b";
import { CatalogSection } from "/src/features/catalog/components/CatalogSection.tsx?t=1792850937924";
import { EditorialSections } from "/src/features/catalog/components/EditorialSections.tsx";
import { HeroSection } from "/src/features/catalog/components/HeroSection.tsx";
import { MobileCatalogSearch } from "/src/features/catalog/components/MobileCatalogSearch.tsx";
import { useCatalogQuery } from "/src/features/catalog/queries.ts";
import { defaultCatalogSearch } from "/src/features/catalog/search-params.ts";
import { useCatalogNavigation } from "/src/features/catalog/useCatalogNavigation.ts";
export function CatalogPage({ search }) {
  _s();
  const hash = useRouterState({ select: (state) => state.location.hash });
  const query = useCatalogQuery(search);
  const hero = useCatalogQuery(defaultCatalogSearch);
  const navigation = useCatalogNavigation(search);
  if (!query.isPlaceholderData && query.data && query.data.page !== search.page)
    return /* @__PURE__ */ jsxDEV(
      Navigate,
      {
        to: "/",
        search: { ...search, page: query.data.page },
        hash,
        replace: true,
        resetScroll: false
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogPage.tsx",
        lineNumber: 18,
        columnNumber: 5
      },
      this
    );
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      MobileCatalogSearch,
      {
        search,
        ...query.data ? { facets: query.data.facets } : {},
        apply: navigation.setFilter,
        clear: navigation.clear
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogPage.tsx",
        lineNumber: 28,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(HeroSection, { items: hero.data?.items ?? [], loading: hero.isPending }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogPage.tsx",
      lineNumber: 34,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CatalogSection, { search, query, hero, navigation }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogPage.tsx",
      lineNumber: 35,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(EditorialSections, {}, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogPage.tsx",
      lineNumber: 36,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogPage.tsx",
    lineNumber: 27,
    columnNumber: 5
  }, this);
}
_s(CatalogPage, "gt81qGNw2qGIcytoPtp66urRc4s=", false, function() {
  return [useRouterState, useCatalogQuery, useCatalogQuery, useCatalogNavigation];
});
_c = CatalogPage;
var _c;
$RefreshReg$(_c, "CatalogPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogPage.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJNLFNBU0YsVUFURTs7QUFqQk4sU0FBU0EsVUFBVUMsc0JBQXNCO0FBRXpDLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLDJCQUEyQjtBQUNwQyxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsNEJBQWdEO0FBQ3pELFNBQVNDLDRCQUE0QjtBQUU5QixnQkFBU0MsWUFBWSxFQUFFQyxPQUFrQyxHQUFHO0FBQUFDLEtBQUE7QUFDakUsUUFBTUMsT0FBT1gsZUFBZSxFQUFFWSxRQUFRQSxDQUFDQyxVQUFVQSxNQUFNQyxTQUFTSCxLQUFLLENBQUM7QUFDdEUsUUFBTUksUUFBUVYsZ0JBQWdCSSxNQUFNO0FBQ3BDLFFBQU1PLE9BQU9YLGdCQUFnQkMsb0JBQW9CO0FBQ2pELFFBQU1XLGFBQWFWLHFCQUFxQkUsTUFBTTtBQUM5QyxNQUFJLENBQUNNLE1BQU1HLHFCQUFxQkgsTUFBTUksUUFBUUosTUFBTUksS0FBS0MsU0FBU1gsT0FBT1c7QUFDdkUsV0FDRTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsSUFBRztBQUFBLFFBQ0gsUUFBUSxFQUFFLEdBQUdYLFFBQVFXLE1BQU1MLE1BQU1JLEtBQUtDLEtBQUs7QUFBQSxRQUMzQztBQUFBLFFBQ0E7QUFBQSxRQUNBLGFBQWE7QUFBQTtBQUFBLE1BTGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBS3FCO0FBR3pCLFNBQ0UsbUNBQ0U7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBLEdBQUtMLE1BQU1JLE9BQU8sRUFBRUUsUUFBUU4sTUFBTUksS0FBS0UsT0FBTyxJQUFJLENBQUM7QUFBQSxRQUNuRCxPQUFPSixXQUFXSztBQUFBQSxRQUNsQixPQUFPTCxXQUFXTTtBQUFBQTtBQUFBQSxNQUpwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJMEI7QUFBQSxJQUUxQix1QkFBQyxlQUFZLE9BQU9QLEtBQUtHLE1BQU1LLFNBQVMsSUFBSSxTQUFTUixLQUFLUyxhQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9FO0FBQUEsSUFDcEUsdUJBQUMsa0JBQWUsUUFBZ0IsT0FBYyxNQUFZLGNBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUY7QUFBQSxJQUNqRix1QkFBQyx1QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtCO0FBQUEsT0FUcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVVBO0FBRUo7QUFBQ2YsR0E1QmVGLGFBQVc7QUFBQSxVQUNaUixnQkFDQ0ssaUJBQ0RBLGlCQUNNRSxvQkFBb0I7QUFBQTtBQUFBLEtBSnpCQztBQUFXLElBQUFrQjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJOYXZpZ2F0ZSIsInVzZVJvdXRlclN0YXRlIiwiQ2F0YWxvZ1NlY3Rpb24iLCJFZGl0b3JpYWxTZWN0aW9ucyIsIkhlcm9TZWN0aW9uIiwiTW9iaWxlQ2F0YWxvZ1NlYXJjaCIsInVzZUNhdGFsb2dRdWVyeSIsImRlZmF1bHRDYXRhbG9nU2VhcmNoIiwidXNlQ2F0YWxvZ05hdmlnYXRpb24iLCJDYXRhbG9nUGFnZSIsInNlYXJjaCIsIl9zIiwiaGFzaCIsInNlbGVjdCIsInN0YXRlIiwibG9jYXRpb24iLCJxdWVyeSIsImhlcm8iLCJuYXZpZ2F0aW9uIiwiaXNQbGFjZWhvbGRlckRhdGEiLCJkYXRhIiwicGFnZSIsImZhY2V0cyIsInNldEZpbHRlciIsImNsZWFyIiwiaXRlbXMiLCJpc1BlbmRpbmciLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDYXRhbG9nUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmF2aWdhdGUsIHVzZVJvdXRlclN0YXRlIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcic7XG5cbmltcG9ydCB7IENhdGFsb2dTZWN0aW9uIH0gZnJvbSAnQC9mZWF0dXJlcy9jYXRhbG9nL2NvbXBvbmVudHMvQ2F0YWxvZ1NlY3Rpb24nO1xuaW1wb3J0IHsgRWRpdG9yaWFsU2VjdGlvbnMgfSBmcm9tICdAL2ZlYXR1cmVzL2NhdGFsb2cvY29tcG9uZW50cy9FZGl0b3JpYWxTZWN0aW9ucyc7XG5pbXBvcnQgeyBIZXJvU2VjdGlvbiB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy9jb21wb25lbnRzL0hlcm9TZWN0aW9uJztcbmltcG9ydCB7IE1vYmlsZUNhdGFsb2dTZWFyY2ggfSBmcm9tICdAL2ZlYXR1cmVzL2NhdGFsb2cvY29tcG9uZW50cy9Nb2JpbGVDYXRhbG9nU2VhcmNoJztcbmltcG9ydCB7IHVzZUNhdGFsb2dRdWVyeSB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy9xdWVyaWVzJztcbmltcG9ydCB7IGRlZmF1bHRDYXRhbG9nU2VhcmNoLCB0eXBlIENhdGFsb2dTZWFyY2ggfSBmcm9tICdAL2ZlYXR1cmVzL2NhdGFsb2cvc2VhcmNoLXBhcmFtcyc7XG5pbXBvcnQgeyB1c2VDYXRhbG9nTmF2aWdhdGlvbiB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy91c2VDYXRhbG9nTmF2aWdhdGlvbic7XG5cbmV4cG9ydCBmdW5jdGlvbiBDYXRhbG9nUGFnZSh7IHNlYXJjaCB9OiB7IHNlYXJjaDogQ2F0YWxvZ1NlYXJjaCB9KSB7XG4gIGNvbnN0IGhhc2ggPSB1c2VSb3V0ZXJTdGF0ZSh7IHNlbGVjdDogKHN0YXRlKSA9PiBzdGF0ZS5sb2NhdGlvbi5oYXNoIH0pO1xuICBjb25zdCBxdWVyeSA9IHVzZUNhdGFsb2dRdWVyeShzZWFyY2gpO1xuICBjb25zdCBoZXJvID0gdXNlQ2F0YWxvZ1F1ZXJ5KGRlZmF1bHRDYXRhbG9nU2VhcmNoKTtcbiAgY29uc3QgbmF2aWdhdGlvbiA9IHVzZUNhdGFsb2dOYXZpZ2F0aW9uKHNlYXJjaCk7XG4gIGlmICghcXVlcnkuaXNQbGFjZWhvbGRlckRhdGEgJiYgcXVlcnkuZGF0YSAmJiBxdWVyeS5kYXRhLnBhZ2UgIT09IHNlYXJjaC5wYWdlKVxuICAgIHJldHVybiAoXG4gICAgICA8TmF2aWdhdGVcbiAgICAgICAgdG89XCIvXCJcbiAgICAgICAgc2VhcmNoPXt7IC4uLnNlYXJjaCwgcGFnZTogcXVlcnkuZGF0YS5wYWdlIH19XG4gICAgICAgIGhhc2g9e2hhc2h9XG4gICAgICAgIHJlcGxhY2VcbiAgICAgICAgcmVzZXRTY3JvbGw9e2ZhbHNlfVxuICAgICAgLz5cbiAgICApO1xuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8TW9iaWxlQ2F0YWxvZ1NlYXJjaFxuICAgICAgICBzZWFyY2g9e3NlYXJjaH1cbiAgICAgICAgey4uLihxdWVyeS5kYXRhID8geyBmYWNldHM6IHF1ZXJ5LmRhdGEuZmFjZXRzIH0gOiB7fSl9XG4gICAgICAgIGFwcGx5PXtuYXZpZ2F0aW9uLnNldEZpbHRlcn1cbiAgICAgICAgY2xlYXI9e25hdmlnYXRpb24uY2xlYXJ9XG4gICAgICAvPlxuICAgICAgPEhlcm9TZWN0aW9uIGl0ZW1zPXtoZXJvLmRhdGE/Lml0ZW1zID8/IFtdfSBsb2FkaW5nPXtoZXJvLmlzUGVuZGluZ30gLz5cbiAgICAgIDxDYXRhbG9nU2VjdGlvbiBzZWFyY2g9e3NlYXJjaH0gcXVlcnk9e3F1ZXJ5fSBoZXJvPXtoZXJvfSBuYXZpZ2F0aW9uPXtuYXZpZ2F0aW9ufSAvPlxuICAgICAgPEVkaXRvcmlhbFNlY3Rpb25zIC8+XG4gICAgPC8+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9maWxpcGVjYXZhbGNhbnRlL0RvY3VtZW50cy9KdW5nbGVHYW1pbmdUZXN0ZS9zcmMvZmVhdHVyZXMvY2F0YWxvZy9jb21wb25lbnRzL0NhdGFsb2dQYWdlLnRzeCJ9