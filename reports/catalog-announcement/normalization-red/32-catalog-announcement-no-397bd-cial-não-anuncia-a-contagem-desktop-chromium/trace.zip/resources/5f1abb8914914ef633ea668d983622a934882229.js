import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/HeroSection.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=970a124b"; const useState = __vite__cjsImport1_react["useState"];
import { HeroArtwork } from "/src/features/catalog/components/HeroArtwork.tsx";
import { HeroCopy } from "/src/features/catalog/components/HeroCopy.tsx";
import { HeroPagination } from "/src/features/catalog/components/HeroPagination.tsx";
export function HeroSection({ items, loading = false }) {
  _s();
  const [selected, setSelected] = useState(0);
  const featured = items.slice(0, 3);
  const nft = featured[selected] ?? featured[0];
  return /* @__PURE__ */ jsxDEV(
    "section",
    {
      "data-testid": "home-hero",
      className: "relative mb-0 min-h-[190px] rounded-xl bg-transparent px-4 pt-4 pb-0 md:mb-24 md:grid md:h-[450px] md:grid-cols-[minmax(0,1fr)_40%] md:items-center md:overflow-visible md:rounded-none md:bg-transparent md:p-0 md:pl-10 xl:grid-cols-[minmax(0,1fr)_450px]",
      children: [
        /* @__PURE__ */ jsxDEV(
          "img",
          {
            src: "/images/ui/mobile-hero-background.svg",
            width: 366,
            height: 190,
            fetchPriority: "high",
            alt: "",
            "aria-hidden": "true",
            className: "pointer-events-none absolute inset-0 h-full w-full md:hidden"
          },
          void 0,
          false,
          {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroSection.tsx",
            lineNumber: 17,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(HeroCopy, {}, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroSection.tsx",
          lineNumber: 26,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(HeroArtwork, { nft, secondary: featured[1], loading }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroSection.tsx",
          lineNumber: 27,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(HeroPagination, { items: featured, selected, select: setSelected }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroSection.tsx",
          lineNumber: 28,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroSection.tsx",
      lineNumber: 13,
      columnNumber: 5
    },
    this
  );
}
_s(HeroSection, "gGT9ux4E8pnUkSZL1bYkDrfRDO0=");
_c = HeroSection;
var _c;
$RefreshReg$(_c, "HeroSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroSection.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroSection.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroSection.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JNOztBQWhCTixTQUFTQSxnQkFBZ0I7QUFHekIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxzQkFBc0I7QUFFeEIsZ0JBQVNDLFlBQVksRUFBRUMsT0FBT0MsVUFBVSxNQUEyQyxHQUFHO0FBQUFDLEtBQUE7QUFDM0YsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUlULFNBQVMsQ0FBQztBQUMxQyxRQUFNVSxXQUFXTCxNQUFNTSxNQUFNLEdBQUcsQ0FBQztBQUNqQyxRQUFNQyxNQUFNRixTQUFTRixRQUFRLEtBQUtFLFNBQVMsQ0FBQztBQUM1QyxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxlQUFZO0FBQUEsTUFDWixXQUFVO0FBQUEsTUFFVjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxLQUFJO0FBQUEsWUFDSixPQUFPO0FBQUEsWUFDUCxRQUFRO0FBQUEsWUFDUixlQUFjO0FBQUEsWUFDZCxLQUFJO0FBQUEsWUFDSixlQUFZO0FBQUEsWUFDWixXQUFVO0FBQUE7QUFBQSxVQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU8wRTtBQUFBLFFBRTFFLHVCQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFTO0FBQUEsUUFDVCx1QkFBQyxlQUFZLEtBQVUsV0FBV0EsU0FBUyxDQUFDLEdBQUcsV0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRTtBQUFBLFFBQ2hFLHVCQUFDLGtCQUFlLE9BQU9BLFVBQVUsVUFBb0IsUUFBUUQsZUFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RTtBQUFBO0FBQUE7QUFBQSxJQWYzRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFnQkE7QUFFSjtBQUFDRixHQXZCZUgsYUFBVztBQUFBLEtBQVhBO0FBQVcsSUFBQVM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJIZXJvQXJ0d29yayIsIkhlcm9Db3B5IiwiSGVyb1BhZ2luYXRpb24iLCJIZXJvU2VjdGlvbiIsIml0ZW1zIiwibG9hZGluZyIsIl9zIiwic2VsZWN0ZWQiLCJzZXRTZWxlY3RlZCIsImZlYXR1cmVkIiwic2xpY2UiLCJuZnQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJIZXJvU2VjdGlvbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5cbmltcG9ydCB0eXBlIHsgTmZ0IH0gZnJvbSAnQC9jb250cmFjdHMvbmZ0JztcbmltcG9ydCB7IEhlcm9BcnR3b3JrIH0gZnJvbSAnQC9mZWF0dXJlcy9jYXRhbG9nL2NvbXBvbmVudHMvSGVyb0FydHdvcmsnO1xuaW1wb3J0IHsgSGVyb0NvcHkgfSBmcm9tICdAL2ZlYXR1cmVzL2NhdGFsb2cvY29tcG9uZW50cy9IZXJvQ29weSc7XG5pbXBvcnQgeyBIZXJvUGFnaW5hdGlvbiB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy9jb21wb25lbnRzL0hlcm9QYWdpbmF0aW9uJztcblxuZXhwb3J0IGZ1bmN0aW9uIEhlcm9TZWN0aW9uKHsgaXRlbXMsIGxvYWRpbmcgPSBmYWxzZSB9OiB7IGl0ZW1zOiBOZnRbXTsgbG9hZGluZz86IGJvb2xlYW4gfSkge1xuICBjb25zdCBbc2VsZWN0ZWQsIHNldFNlbGVjdGVkXSA9IHVzZVN0YXRlKDApO1xuICBjb25zdCBmZWF0dXJlZCA9IGl0ZW1zLnNsaWNlKDAsIDMpO1xuICBjb25zdCBuZnQgPSBmZWF0dXJlZFtzZWxlY3RlZF0gPz8gZmVhdHVyZWRbMF07XG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb25cbiAgICAgIGRhdGEtdGVzdGlkPVwiaG9tZS1oZXJvXCJcbiAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlIG1iLTAgbWluLWgtWzE5MHB4XSByb3VuZGVkLXhsIGJnLXRyYW5zcGFyZW50IHB4LTQgcHQtNCBwYi0wIG1kOm1iLTI0IG1kOmdyaWQgbWQ6aC1bNDUwcHhdIG1kOmdyaWQtY29scy1bbWlubWF4KDAsMWZyKV80MCVdIG1kOml0ZW1zLWNlbnRlciBtZDpvdmVyZmxvdy12aXNpYmxlIG1kOnJvdW5kZWQtbm9uZSBtZDpiZy10cmFuc3BhcmVudCBtZDpwLTAgbWQ6cGwtMTAgeGw6Z3JpZC1jb2xzLVttaW5tYXgoMCwxZnIpXzQ1MHB4XVwiXG4gICAgPlxuICAgICAgPGltZ1xuICAgICAgICBzcmM9XCIvaW1hZ2VzL3VpL21vYmlsZS1oZXJvLWJhY2tncm91bmQuc3ZnXCJcbiAgICAgICAgd2lkdGg9ezM2Nn1cbiAgICAgICAgaGVpZ2h0PXsxOTB9XG4gICAgICAgIGZldGNoUHJpb3JpdHk9XCJoaWdoXCJcbiAgICAgICAgYWx0PVwiXCJcbiAgICAgICAgYXJpYS1oaWRkZW49XCJ0cnVlXCJcbiAgICAgICAgY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtbm9uZSBhYnNvbHV0ZSBpbnNldC0wIGgtZnVsbCB3LWZ1bGwgbWQ6aGlkZGVuXCJcbiAgICAgIC8+XG4gICAgICA8SGVyb0NvcHkgLz5cbiAgICAgIDxIZXJvQXJ0d29yayBuZnQ9e25mdH0gc2Vjb25kYXJ5PXtmZWF0dXJlZFsxXX0gbG9hZGluZz17bG9hZGluZ30gLz5cbiAgICAgIDxIZXJvUGFnaW5hdGlvbiBpdGVtcz17ZmVhdHVyZWR9IHNlbGVjdGVkPXtzZWxlY3RlZH0gc2VsZWN0PXtzZXRTZWxlY3RlZH0gLz5cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9maWxpcGVjYXZhbGNhbnRlL0RvY3VtZW50cy9KdW5nbGVHYW1pbmdUZXN0ZS9zcmMvZmVhdHVyZXMvY2F0YWxvZy9jb21wb25lbnRzL0hlcm9TZWN0aW9uLnRzeCJ9