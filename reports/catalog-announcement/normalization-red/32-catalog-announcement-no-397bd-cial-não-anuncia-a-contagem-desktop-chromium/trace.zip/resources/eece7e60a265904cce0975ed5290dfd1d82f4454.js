import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/FilterChecklist.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Checkbox } from "/src/components/ui/checkbox.tsx";
export function FilterChecklist({
  options,
  selected,
  labels,
  change
}) {
  return /* @__PURE__ */ jsxDEV(Fragment, { children: options.map(
    ({ key, count }) => /* @__PURE__ */ jsxDEV(
      "label",
      {
        className: "flex min-h-11 cursor-pointer items-center gap-2 text-body-sm text-text-secondary sm:min-h-10",
        children: [
          /* @__PURE__ */ jsxDEV(
            Checkbox,
            {
              "aria-label": labels[key],
              checked: selected.includes(key),
              onCheckedChange: (checked) => {
                change(checked ? [...selected, key] : selected.filter((value) => value !== key));
              }
            },
            void 0,
            false,
            {
              fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterChecklist.tsx",
              lineNumber: 22,
              columnNumber: 11
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { children: labels[key] }, void 0, false, {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterChecklist.tsx",
            lineNumber: 29,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("span", { "aria-hidden": "true", className: "ml-auto text-body-sm", children: [
            "(",
            count,
            ")"
          ] }, void 0, true, {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterChecklist.tsx",
            lineNumber: 30,
            columnNumber: 11
          }, this)
        ]
      },
      key,
      true,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterChecklist.tsx",
        lineNumber: 18,
        columnNumber: 7
      },
      this
    )
  ) }, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterChecklist.tsx",
    lineNumber: 16,
    columnNumber: 5
  }, this);
}
_c = FilterChecklist;
var _c;
$RefreshReg$(_c, "FilterChecklist");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterChecklist.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterChecklist.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterChecklist.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZUksbUJBTU0sY0FOTjtBQWZKLFNBQVNBLGdCQUFnQjtBQVFsQixnQkFBU0MsZ0JBQWtDO0FBQUEsRUFDaERDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ3VCLEdBQUc7QUFDMUIsU0FDRSxtQ0FDR0gsa0JBQVFJO0FBQUFBLElBQUksQ0FBQyxFQUFFQyxLQUFLQyxNQUFNLE1BQ3pCO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFFQyxXQUFVO0FBQUEsUUFFVjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxjQUFZSixPQUFPRyxHQUFHO0FBQUEsY0FDdEIsU0FBU0osU0FBU00sU0FBU0YsR0FBRztBQUFBLGNBQzlCLGlCQUFpQixDQUFDRyxZQUFZO0FBQzVCTCx1QkFBT0ssVUFBVSxDQUFDLEdBQUdQLFVBQVVJLEdBQUcsSUFBSUosU0FBU1EsT0FBTyxDQUFDQyxVQUFVQSxVQUFVTCxHQUFHLENBQUM7QUFBQSxjQUNqRjtBQUFBO0FBQUEsWUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLSTtBQUFBLFVBRUosdUJBQUMsVUFBTUgsaUJBQU9HLEdBQUcsS0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUI7QUFBQSxVQUNuQix1QkFBQyxVQUFLLGVBQVksUUFBTyxXQUFVLHdCQUFzQjtBQUFBO0FBQUEsWUFDckRDO0FBQUFBLFlBQU07QUFBQSxlQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQTtBQUFBO0FBQUEsTUFiS0Q7QUFBQUEsTUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBZUE7QUFBQSxFQUNELEtBbEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtQkE7QUFFSjtBQUFDTSxLQTVCZVo7QUFBZSxJQUFBWTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJDaGVja2JveCIsIkZpbHRlckNoZWNrbGlzdCIsIm9wdGlvbnMiLCJzZWxlY3RlZCIsImxhYmVscyIsImNoYW5nZSIsIm1hcCIsImtleSIsImNvdW50IiwiaW5jbHVkZXMiLCJjaGVja2VkIiwiZmlsdGVyIiwidmFsdWUiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJGaWx0ZXJDaGVja2xpc3QudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENoZWNrYm94IH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2NoZWNrYm94JztcblxuaW50ZXJmYWNlIEZpbHRlckNoZWNrbGlzdFByb3BzPFQgZXh0ZW5kcyBzdHJpbmc+IHtcbiAgb3B0aW9uczogeyBrZXk6IFQ7IGNvdW50OiBudW1iZXIgfVtdO1xuICBzZWxlY3RlZDogVFtdO1xuICBsYWJlbHM6IFJlY29yZDxULCBzdHJpbmc+O1xuICBjaGFuZ2U6IChzZWxlY3RlZDogVFtdKSA9PiB2b2lkO1xufVxuZXhwb3J0IGZ1bmN0aW9uIEZpbHRlckNoZWNrbGlzdDxUIGV4dGVuZHMgc3RyaW5nPih7XG4gIG9wdGlvbnMsXG4gIHNlbGVjdGVkLFxuICBsYWJlbHMsXG4gIGNoYW5nZSxcbn06IEZpbHRlckNoZWNrbGlzdFByb3BzPFQ+KSB7XG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIHtvcHRpb25zLm1hcCgoeyBrZXksIGNvdW50IH0pID0+IChcbiAgICAgICAgPGxhYmVsXG4gICAgICAgICAga2V5PXtrZXl9XG4gICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBtaW4taC0xMSBjdXJzb3ItcG9pbnRlciBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1ib2R5LXNtIHRleHQtdGV4dC1zZWNvbmRhcnkgc206bWluLWgtMTBcIlxuICAgICAgICA+XG4gICAgICAgICAgPENoZWNrYm94XG4gICAgICAgICAgICBhcmlhLWxhYmVsPXtsYWJlbHNba2V5XX1cbiAgICAgICAgICAgIGNoZWNrZWQ9e3NlbGVjdGVkLmluY2x1ZGVzKGtleSl9XG4gICAgICAgICAgICBvbkNoZWNrZWRDaGFuZ2U9eyhjaGVja2VkKSA9PiB7XG4gICAgICAgICAgICAgIGNoYW5nZShjaGVja2VkID8gWy4uLnNlbGVjdGVkLCBrZXldIDogc2VsZWN0ZWQuZmlsdGVyKCh2YWx1ZSkgPT4gdmFsdWUgIT09IGtleSkpO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxzcGFuPntsYWJlbHNba2V5XX08L3NwYW4+XG4gICAgICAgICAgPHNwYW4gYXJpYS1oaWRkZW49XCJ0cnVlXCIgY2xhc3NOYW1lPVwibWwtYXV0byB0ZXh0LWJvZHktc21cIj5cbiAgICAgICAgICAgICh7Y291bnR9KVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9sYWJlbD5cbiAgICAgICkpfVxuICAgIDwvPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvZmlsaXBlY2F2YWxjYW50ZS9Eb2N1bWVudHMvSnVuZ2xlR2FtaW5nVGVzdGUvc3JjL2ZlYXR1cmVzL2NhdGFsb2cvY29tcG9uZW50cy9GaWx0ZXJDaGVja2xpc3QudHN4In0=