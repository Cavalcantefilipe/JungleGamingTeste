import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/FilterDrawerTrigger.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { FigmaIcon } from "/src/components/icons/FigmaIcon.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { SheetTrigger } from "/src/components/ui/sheet.tsx";
export function FilterDrawerTrigger({ compact }) {
  return /* @__PURE__ */ jsxDEV(SheetTrigger, { asChild: true, children: /* @__PURE__ */ jsxDEV(
    Button,
    {
      variant: compact ? "filter" : "secondary",
      size: compact ? "icon" : "default",
      "aria-label": "Filtros",
      className: "rounded-xl lg:hidden",
      children: [
        /* @__PURE__ */ jsxDEV(FigmaIcon, { name: "filter", "aria-hidden": "true", size: 20 }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterDrawerTrigger.tsx",
          lineNumber: 14,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: compact ? "sr-only" : "", children: "Filtros" }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterDrawerTrigger.tsx",
          lineNumber: 15,
          columnNumber: 9
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterDrawerTrigger.tsx",
      lineNumber: 8,
      columnNumber: 7
    },
    this
  ) }, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterDrawerTrigger.tsx",
    lineNumber: 7,
    columnNumber: 5
  }, this);
}
_c = FilterDrawerTrigger;
var _c;
$RefreshReg$(_c, "FilterDrawerTrigger");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterDrawerTrigger.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterDrawerTrigger.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterDrawerTrigger.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYVE7QUFiUixTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxvQkFBb0I7QUFFdEIsZ0JBQVNDLG9CQUFvQixFQUFFQyxRQUE4QixHQUFHO0FBQ3JFLFNBQ0UsdUJBQUMsZ0JBQWEsU0FBTyxNQUNuQjtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsU0FBU0EsVUFBVSxXQUFXO0FBQUEsTUFDOUIsTUFBTUEsVUFBVSxTQUFTO0FBQUEsTUFDekIsY0FBVztBQUFBLE1BQ1gsV0FBVTtBQUFBLE1BRVY7QUFBQSwrQkFBQyxhQUFVLE1BQUssVUFBUyxlQUFZLFFBQU8sTUFBTSxNQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFEO0FBQUEsUUFDckQsdUJBQUMsVUFBSyxXQUFXQSxVQUFVLFlBQVksSUFBSSx1QkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRDtBQUFBO0FBQUE7QUFBQSxJQVBwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FVQTtBQUVKO0FBQUNDLEtBZGVGO0FBQW1CLElBQUFFO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkZpZ21hSWNvbiIsIkJ1dHRvbiIsIlNoZWV0VHJpZ2dlciIsIkZpbHRlckRyYXdlclRyaWdnZXIiLCJjb21wYWN0IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRmlsdGVyRHJhd2VyVHJpZ2dlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRmlnbWFJY29uIH0gZnJvbSAnQC9jb21wb25lbnRzL2ljb25zL0ZpZ21hSWNvbic7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJztcbmltcG9ydCB7IFNoZWV0VHJpZ2dlciB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9zaGVldCc7XG5cbmV4cG9ydCBmdW5jdGlvbiBGaWx0ZXJEcmF3ZXJUcmlnZ2VyKHsgY29tcGFjdCB9OiB7IGNvbXBhY3Q6IGJvb2xlYW4gfSkge1xuICByZXR1cm4gKFxuICAgIDxTaGVldFRyaWdnZXIgYXNDaGlsZD5cbiAgICAgIDxCdXR0b25cbiAgICAgICAgdmFyaWFudD17Y29tcGFjdCA/ICdmaWx0ZXInIDogJ3NlY29uZGFyeSd9XG4gICAgICAgIHNpemU9e2NvbXBhY3QgPyAnaWNvbicgOiAnZGVmYXVsdCd9XG4gICAgICAgIGFyaWEtbGFiZWw9XCJGaWx0cm9zXCJcbiAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC14bCBsZzpoaWRkZW5cIlxuICAgICAgPlxuICAgICAgICA8RmlnbWFJY29uIG5hbWU9XCJmaWx0ZXJcIiBhcmlhLWhpZGRlbj1cInRydWVcIiBzaXplPXsyMH0gLz5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtjb21wYWN0ID8gJ3NyLW9ubHknIDogJyd9PkZpbHRyb3M8L3NwYW4+XG4gICAgICA8L0J1dHRvbj5cbiAgICA8L1NoZWV0VHJpZ2dlcj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2ZpbGlwZWNhdmFsY2FudGUvRG9jdW1lbnRzL0p1bmdsZUdhbWluZ1Rlc3RlL3NyYy9mZWF0dXJlcy9jYXRhbG9nL2NvbXBvbmVudHMvRmlsdGVyRHJhd2VyVHJpZ2dlci50c3gifQ==