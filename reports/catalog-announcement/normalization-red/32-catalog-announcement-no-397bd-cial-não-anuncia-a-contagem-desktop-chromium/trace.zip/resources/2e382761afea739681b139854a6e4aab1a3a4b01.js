import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/HeroCopy.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { FigmaIcon } from "/src/components/icons/FigmaIcon.tsx";
import { Button } from "/src/components/ui/button.tsx";
export function HeroCopy() {
  return /* @__PURE__ */ jsxDEV("div", { className: "pointer-events-none relative z-10 -mt-2 w-[58%] max-w-[190px] space-y-1 md:mt-10 md:w-full md:max-w-[600px] md:space-y-1 md:self-start", children: [
    /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] leading-4 text-foreground md:text-sm md:leading-6 md:font-medium md:tracking-[0.1em]", children: "Bem-vindo à Kurio" }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroCopy.tsx",
      lineNumber: 7,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("h1", { className: "text-[18px] leading-[29px] font-bold md:text-[32px] md:leading-[48px] xl:text-display xl:leading-[70px]", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "md:hidden", children: "SEJA DONO DA CULTURA DIGITAL" }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroCopy.tsx",
        lineNumber: 11,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "hidden md:inline", children: [
        "SEJA DONO DO FUTURO",
        /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroCopy.tsx",
          lineNumber: 14,
          columnNumber: 11
        }, this),
        "DA ARTE DIGITAL"
      ] }, void 0, true, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroCopy.tsx",
        lineNumber: 12,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroCopy.tsx",
      lineNumber: 10,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "text-xs leading-[18px] text-text-secondary md:text-sm md:leading-6", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "md:hidden", children: "Descubra NFTs selecionados de criadores do mundo todo." }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroCopy.tsx",
        lineNumber: 19,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "hidden md:inline", children: "Descubra NFTs selecionados de criadores emergentes e consagrados. Colecione arte digital rara, apoie artistas e tenha uma parte da cultura da internet." }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroCopy.tsx",
        lineNumber: 20,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroCopy.tsx",
      lineNumber: 18,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "hidden pt-7 md:block", children: /* @__PURE__ */ jsxDEV(Button, { asChild: true, className: "w-[140px] px-0", children: /* @__PURE__ */ jsxDEV("a", { href: "#catalogo", className: "pointer-events-auto", children: "EXPLORAR" }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroCopy.tsx",
      lineNumber: 27,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroCopy.tsx",
      lineNumber: 26,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroCopy.tsx",
      lineNumber: 25,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "a",
      {
        href: "#catalogo",
        className: "pointer-events-auto -mt-0.5 flex min-h-11 w-fit items-start gap-2 pt-1 text-xs font-bold text-primary hover:text-primary-light md:hidden",
        children: [
          "EXPLORAR",
          /* @__PURE__ */ jsxDEV(FigmaIcon, { name: "arrow-right", size: 14, "aria-hidden": "true" }, void 0, false, {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroCopy.tsx",
            lineNumber: 37,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroCopy.tsx",
        lineNumber: 32,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroCopy.tsx",
    lineNumber: 6,
    columnNumber: 5
  }, this);
}
_c = HeroCopy;
var _c;
$RefreshReg$(_c, "HeroCopy");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroCopy.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroCopy.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroCopy.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBTU07QUFOTixTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0MsY0FBYztBQUVoQixnQkFBU0MsV0FBVztBQUN6QixTQUNFLHVCQUFDLFNBQUksV0FBVSwwSUFDYjtBQUFBLDJCQUFDLE9BQUUsV0FBVSxvR0FBa0csaUNBQS9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsUUFBRyxXQUFVLDJHQUNaO0FBQUEsNkJBQUMsVUFBSyxXQUFVLGFBQVksNENBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0Q7QUFBQSxNQUN4RCx1QkFBQyxVQUFLLFdBQVUsb0JBQWtCO0FBQUE7QUFBQSxRQUVoQyx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBRztBQUFBO0FBQUEsV0FGTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxTQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBQ0EsdUJBQUMsT0FBRSxXQUFVLHNFQUNYO0FBQUEsNkJBQUMsVUFBSyxXQUFVLGFBQVksc0VBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0Y7QUFBQSxNQUNsRix1QkFBQyxVQUFLLFdBQVUsb0JBQWtCLHVLQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiLGlDQUFDLFVBQU8sU0FBTyxNQUFDLFdBQVUsa0JBQ3hCLGlDQUFDLE9BQUUsTUFBSyxhQUFZLFdBQVUsdUJBQXFCLHdCQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUEsS0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxJQUNBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFLO0FBQUEsUUFDTCxXQUFVO0FBQUEsUUFBMEk7QUFBQTtBQUFBLFVBR3BKLHVCQUFDLGFBQVUsTUFBSyxlQUFjLE1BQU0sSUFBSSxlQUFZLFVBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBEO0FBQUE7QUFBQTtBQUFBLE1BTDVEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1BO0FBQUEsT0FoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlDQTtBQUVKO0FBQUNDLEtBckNlRDtBQUFRLElBQUFDO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkZpZ21hSWNvbiIsIkJ1dHRvbiIsIkhlcm9Db3B5IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSGVyb0NvcHkudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZpZ21hSWNvbiB9IGZyb20gJ0AvY29tcG9uZW50cy9pY29ucy9GaWdtYUljb24nO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbic7XG5cbmV4cG9ydCBmdW5jdGlvbiBIZXJvQ29weSgpIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInBvaW50ZXItZXZlbnRzLW5vbmUgcmVsYXRpdmUgei0xMCAtbXQtMiB3LVs1OCVdIG1heC13LVsxOTBweF0gc3BhY2UteS0xIG1kOm10LTEwIG1kOnctZnVsbCBtZDptYXgtdy1bNjAwcHhdIG1kOnNwYWNlLXktMSBtZDpzZWxmLXN0YXJ0XCI+XG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBsZWFkaW5nLTQgdGV4dC1mb3JlZ3JvdW5kIG1kOnRleHQtc20gbWQ6bGVhZGluZy02IG1kOmZvbnQtbWVkaXVtIG1kOnRyYWNraW5nLVswLjFlbV1cIj5cbiAgICAgICAgQmVtLXZpbmRvIMOgIEt1cmlvXG4gICAgICA8L3A+XG4gICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1bMThweF0gbGVhZGluZy1bMjlweF0gZm9udC1ib2xkIG1kOnRleHQtWzMycHhdIG1kOmxlYWRpbmctWzQ4cHhdIHhsOnRleHQtZGlzcGxheSB4bDpsZWFkaW5nLVs3MHB4XVwiPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtZDpoaWRkZW5cIj5TRUpBIERPTk8gREEgQ1VMVFVSQSBESUdJVEFMPC9zcGFuPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gbWQ6aW5saW5lXCI+XG4gICAgICAgICAgU0VKQSBET05PIERPIEZVVFVST1xuICAgICAgICAgIDxiciAvPlxuICAgICAgICAgIERBIEFSVEUgRElHSVRBTFxuICAgICAgICA8L3NwYW4+XG4gICAgICA8L2gxPlxuICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBsZWFkaW5nLVsxOHB4XSB0ZXh0LXRleHQtc2Vjb25kYXJ5IG1kOnRleHQtc20gbWQ6bGVhZGluZy02XCI+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1kOmhpZGRlblwiPkRlc2N1YnJhIE5GVHMgc2VsZWNpb25hZG9zIGRlIGNyaWFkb3JlcyBkbyBtdW5kbyB0b2RvLjwvc3Bhbj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIG1kOmlubGluZVwiPlxuICAgICAgICAgIERlc2N1YnJhIE5GVHMgc2VsZWNpb25hZG9zIGRlIGNyaWFkb3JlcyBlbWVyZ2VudGVzIGUgY29uc2FncmFkb3MuIENvbGVjaW9uZSBhcnRlIGRpZ2l0YWxcbiAgICAgICAgICByYXJhLCBhcG9pZSBhcnRpc3RhcyBlIHRlbmhhIHVtYSBwYXJ0ZSBkYSBjdWx0dXJhIGRhIGludGVybmV0LlxuICAgICAgICA8L3NwYW4+XG4gICAgICA8L3A+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBwdC03IG1kOmJsb2NrXCI+XG4gICAgICAgIDxCdXR0b24gYXNDaGlsZCBjbGFzc05hbWU9XCJ3LVsxNDBweF0gcHgtMFwiPlxuICAgICAgICAgIDxhIGhyZWY9XCIjY2F0YWxvZ29cIiBjbGFzc05hbWU9XCJwb2ludGVyLWV2ZW50cy1hdXRvXCI+XG4gICAgICAgICAgICBFWFBMT1JBUlxuICAgICAgICAgIDwvYT5cbiAgICAgICAgPC9CdXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxhXG4gICAgICAgIGhyZWY9XCIjY2F0YWxvZ29cIlxuICAgICAgICBjbGFzc05hbWU9XCJwb2ludGVyLWV2ZW50cy1hdXRvIC1tdC0wLjUgZmxleCBtaW4taC0xMSB3LWZpdCBpdGVtcy1zdGFydCBnYXAtMiBwdC0xIHRleHQteHMgZm9udC1ib2xkIHRleHQtcHJpbWFyeSBob3Zlcjp0ZXh0LXByaW1hcnktbGlnaHQgbWQ6aGlkZGVuXCJcbiAgICAgID5cbiAgICAgICAgRVhQTE9SQVJcbiAgICAgICAgPEZpZ21hSWNvbiBuYW1lPVwiYXJyb3ctcmlnaHRcIiBzaXplPXsxNH0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgIDwvYT5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2ZpbGlwZWNhdmFsY2FudGUvRG9jdW1lbnRzL0p1bmdsZUdhbWluZ1Rlc3RlL3NyYy9mZWF0dXJlcy9jYXRhbG9nL2NvbXBvbmVudHMvSGVyb0NvcHkudHN4In0=