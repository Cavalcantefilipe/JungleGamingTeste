import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/PaginationArrow.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { FigmaIcon } from "/src/components/icons/FigmaIcon.tsx";
import { Button } from "/src/components/ui/button.tsx";
export function PaginationArrow({
  previous = false,
  disabled,
  go
}) {
  return /* @__PURE__ */ jsxDEV(
    Button,
    {
      variant: "pagination",
      size: "pagination",
      "aria-label": previous ? "Página anterior" : "Próxima página",
      onClick: go,
      disabled,
      children: /* @__PURE__ */ jsxDEV(FigmaIcon, { name: previous ? "chevron-left" : "chevron-right", "aria-hidden": "true" }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PaginationArrow.tsx",
        lineNumber: 21,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PaginationArrow.tsx",
      lineNumber: 14,
      columnNumber: 5
    },
    this
  );
}
_c = PaginationArrow;
var _c;
$RefreshReg$(_c, "PaginationArrow");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PaginationArrow.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PaginationArrow.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PaginationArrow.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JNO0FBcEJOLFNBQVNBLGlCQUFpQjtBQUMxQixTQUFTQyxjQUFjO0FBRWhCLGdCQUFTQyxnQkFBZ0I7QUFBQSxFQUM5QkMsV0FBVztBQUFBLEVBQ1hDO0FBQUFBLEVBQ0FDO0FBS0YsR0FBRztBQUNELFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFNBQVE7QUFBQSxNQUNSLE1BQUs7QUFBQSxNQUNMLGNBQVlGLFdBQVcsb0JBQW9CO0FBQUEsTUFDM0MsU0FBU0U7QUFBQUEsTUFDVDtBQUFBLE1BRUEsaUNBQUMsYUFBVSxNQUFNRixXQUFXLGlCQUFpQixpQkFBaUIsZUFBWSxVQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdGO0FBQUE7QUFBQSxJQVBsRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFRQTtBQUVKO0FBQUNHLEtBcEJlSjtBQUFlLElBQUFJO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkZpZ21hSWNvbiIsIkJ1dHRvbiIsIlBhZ2luYXRpb25BcnJvdyIsInByZXZpb3VzIiwiZGlzYWJsZWQiLCJnbyIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlBhZ2luYXRpb25BcnJvdy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRmlnbWFJY29uIH0gZnJvbSAnQC9jb21wb25lbnRzL2ljb25zL0ZpZ21hSWNvbic7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJztcblxuZXhwb3J0IGZ1bmN0aW9uIFBhZ2luYXRpb25BcnJvdyh7XG4gIHByZXZpb3VzID0gZmFsc2UsXG4gIGRpc2FibGVkLFxuICBnbyxcbn06IHtcbiAgcHJldmlvdXM/OiBib29sZWFuO1xuICBkaXNhYmxlZDogYm9vbGVhbjtcbiAgZ286ICgpID0+IHZvaWQ7XG59KSB7XG4gIHJldHVybiAoXG4gICAgPEJ1dHRvblxuICAgICAgdmFyaWFudD1cInBhZ2luYXRpb25cIlxuICAgICAgc2l6ZT1cInBhZ2luYXRpb25cIlxuICAgICAgYXJpYS1sYWJlbD17cHJldmlvdXMgPyAnUMOhZ2luYSBhbnRlcmlvcicgOiAnUHLDs3hpbWEgcMOhZ2luYSd9XG4gICAgICBvbkNsaWNrPXtnb31cbiAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cbiAgICA+XG4gICAgICA8RmlnbWFJY29uIG5hbWU9e3ByZXZpb3VzID8gJ2NoZXZyb24tbGVmdCcgOiAnY2hldnJvbi1yaWdodCd9IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgPC9CdXR0b24+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9maWxpcGVjYXZhbGNhbnRlL0RvY3VtZW50cy9KdW5nbGVHYW1pbmdUZXN0ZS9zcmMvZmVhdHVyZXMvY2F0YWxvZy9jb21wb25lbnRzL1BhZ2luYXRpb25BcnJvdy50c3gifQ==