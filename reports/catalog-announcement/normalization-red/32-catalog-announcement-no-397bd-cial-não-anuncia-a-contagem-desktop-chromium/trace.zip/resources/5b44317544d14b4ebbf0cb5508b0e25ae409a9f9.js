import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/sheet.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { XIcon } from "/node_modules/.vite/deps/lucide-react.js?v=970a124b";
import { Dialog as SheetPrimitive } from "/node_modules/.vite/deps/radix-ui.js?v=970a124b";
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=970a124b"; const React = ((m) => m?.__esModule ? m : {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m})(__vite__cjsImport3_react);
import { cn } from "/src/lib/cn.ts";
function Sheet({ ...props }) {
  return /* @__PURE__ */ jsxDEV(SheetPrimitive.Root, { "data-slot": "sheet", ...props }, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/sheet.tsx",
    lineNumber: 8,
    columnNumber: 10
  }, this);
}
_c = Sheet;
function SheetTrigger({ ...props }) {
  return /* @__PURE__ */ jsxDEV(SheetPrimitive.Trigger, { "data-slot": "sheet-trigger", ...props }, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/sheet.tsx",
    lineNumber: 12,
    columnNumber: 10
  }, this);
}
_c2 = SheetTrigger;
function SheetClose({ ...props }) {
  return /* @__PURE__ */ jsxDEV(SheetPrimitive.Close, { "data-slot": "sheet-close", ...props }, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/sheet.tsx",
    lineNumber: 16,
    columnNumber: 10
  }, this);
}
_c3 = SheetClose;
function SheetPortal({ ...props }) {
  return /* @__PURE__ */ jsxDEV(SheetPrimitive.Portal, { "data-slot": "sheet-portal", ...props }, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/sheet.tsx",
    lineNumber: 20,
    columnNumber: 10
  }, this);
}
_c4 = SheetPortal;
function SheetOverlay({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsxDEV(
    SheetPrimitive.Overlay,
    {
      "data-slot": "sheet-overlay",
      className: cn(
        "data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:animate-in data-[state=open]:fade-in-0 fixed inset-0 z-50 bg-black/50",
        className
      ),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/sheet.tsx",
      lineNumber: 28,
      columnNumber: 5
    },
    this
  );
}
_c5 = SheetOverlay;
function SheetContent({
  className,
  children,
  side = "right",
  showCloseButton = true,
  ...props
}) {
  return /* @__PURE__ */ jsxDEV(SheetPortal, { children: [
    /* @__PURE__ */ jsxDEV(SheetOverlay, {}, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/sheet.tsx",
      lineNumber: 51,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      SheetPrimitive.Content,
      {
        "data-slot": "sheet-content",
        className: cn(
          "data-[state=closed]:animate-out data-[state=open]:animate-in fixed z-50 flex flex-col gap-4 bg-background shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500",
          side === "right" && "data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right inset-y-0 right-0 h-full w-3/4 border-l sm:max-w-sm",
          side === "left" && "data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left inset-y-0 left-0 h-full w-3/4 border-r sm:max-w-sm",
          side === "top" && "data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top inset-x-0 top-0 h-auto border-b",
          side === "bottom" && "data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom inset-x-0 bottom-0 h-auto border-t",
          className
        ),
        ...props,
        children: [
          children,
          showCloseButton && /* @__PURE__ */ jsxDEV(SheetPrimitive.Close, { className: "absolute top-4 right-4 rounded-xs opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:ring-2 focus:ring-ring focus:ring-offset-2 focus:outline-hidden disabled:pointer-events-none data-[state=open]:bg-secondary", children: [
            /* @__PURE__ */ jsxDEV(XIcon, { className: "size-4" }, void 0, false, {
              fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/sheet.tsx",
              lineNumber: 71,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Close" }, void 0, false, {
              fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/sheet.tsx",
              lineNumber: 72,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/sheet.tsx",
            lineNumber: 70,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/sheet.tsx",
        lineNumber: 52,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/sheet.tsx",
    lineNumber: 50,
    columnNumber: 5
  }, this);
}
_c6 = SheetContent;
function SheetHeader({ className, ...props }) {
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      "data-slot": "sheet-header",
      className: cn("flex flex-col gap-1.5 p-4", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/sheet.tsx",
      lineNumber: 82,
      columnNumber: 5
    },
    this
  );
}
_c7 = SheetHeader;
function SheetFooter({ className, ...props }) {
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      "data-slot": "sheet-footer",
      className: cn("mt-auto flex flex-col gap-2 p-4", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/sheet.tsx",
      lineNumber: 92,
      columnNumber: 5
    },
    this
  );
}
_c8 = SheetFooter;
function SheetTitle({ className, ...props }) {
  return /* @__PURE__ */ jsxDEV(
    SheetPrimitive.Title,
    {
      "data-slot": "sheet-title",
      className: cn("font-semibold text-foreground", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/sheet.tsx",
      lineNumber: 102,
      columnNumber: 5
    },
    this
  );
}
_c9 = SheetTitle;
function SheetDescription({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsxDEV(
    SheetPrimitive.Description,
    {
      "data-slot": "sheet-description",
      className: cn("text-sm text-muted-foreground", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/sheet.tsx",
      lineNumber: 115,
      columnNumber: 5
    },
    this
  );
}
_c0 = SheetDescription;
export {
  Sheet,
  SheetTrigger,
  SheetClose,
  SheetContent,
  SheetHeader,
  SheetFooter,
  SheetTitle,
  SheetDescription
};
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c0;
$RefreshReg$(_c, "Sheet");
$RefreshReg$(_c2, "SheetTrigger");
$RefreshReg$(_c3, "SheetClose");
$RefreshReg$(_c4, "SheetPortal");
$RefreshReg$(_c5, "SheetOverlay");
$RefreshReg$(_c6, "SheetContent");
$RefreshReg$(_c7, "SheetHeader");
$RefreshReg$(_c8, "SheetFooter");
$RefreshReg$(_c9, "SheetTitle");
$RefreshReg$(_c0, "SheetDescription");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/sheet.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/sheet.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/sheet.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT1M7QUFQVCxTQUFTQSxhQUFhO0FBQ3RCLFNBQVNDLFVBQVVDLHNCQUFzQjtBQUN6QyxZQUFZQyxXQUFXO0FBRXZCLFNBQVNDLFVBQVU7QUFFbkIsU0FBU0MsTUFBTSxFQUFFLEdBQUdDLE1BQXdELEdBQUc7QUFDN0UsU0FBTyx1QkFBQyxlQUFlLE1BQWYsRUFBb0IsYUFBVSxTQUFRLEdBQUlBLFNBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBaUQ7QUFDMUQ7QUFBQ0MsS0FGUUY7QUFJVCxTQUFTRyxhQUFhLEVBQUUsR0FBR0YsTUFBMkQsR0FBRztBQUN2RixTQUFPLHVCQUFDLGVBQWUsU0FBZixFQUF1QixhQUFVLGlCQUFnQixHQUFJQSxTQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTREO0FBQ3JFO0FBQUNHLE1BRlFEO0FBSVQsU0FBU0UsV0FBVyxFQUFFLEdBQUdKLE1BQXlELEdBQUc7QUFDbkYsU0FBTyx1QkFBQyxlQUFlLE9BQWYsRUFBcUIsYUFBVSxlQUFjLEdBQUlBLFNBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBd0Q7QUFDakU7QUFBQ0ssTUFGUUQ7QUFJVCxTQUFTRSxZQUFZLEVBQUUsR0FBR04sTUFBMEQsR0FBRztBQUNyRixTQUFPLHVCQUFDLGVBQWUsUUFBZixFQUFzQixhQUFVLGdCQUFlLEdBQUlBLFNBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMEQ7QUFDbkU7QUFBQ08sTUFGUUQ7QUFJVCxTQUFTRSxhQUFhO0FBQUEsRUFDcEJDO0FBQUFBLEVBQ0EsR0FBR1Q7QUFDZ0QsR0FBRztBQUN0RCxTQUNFO0FBQUEsSUFBQyxlQUFlO0FBQUEsSUFBZjtBQUFBLE1BQ0MsYUFBVTtBQUFBLE1BQ1YsV0FBV0Y7QUFBQUEsUUFDVDtBQUFBLFFBQ0FXO0FBQUFBLE1BQ0Y7QUFBQSxNQUNBLEdBQUlUO0FBQUFBO0FBQUFBLElBTk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTVk7QUFHaEI7QUFBQ1UsTUFkUUY7QUFnQlQsU0FBU0csYUFBYTtBQUFBLEVBQ3BCRjtBQUFBQSxFQUNBRztBQUFBQSxFQUNBQyxPQUFPO0FBQUEsRUFDUEMsa0JBQWtCO0FBQUEsRUFDbEIsR0FBR2Q7QUFJTCxHQUFHO0FBQ0QsU0FDRSx1QkFBQyxlQUNDO0FBQUEsMkJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFhO0FBQUEsSUFDYjtBQUFBLE1BQUMsZUFBZTtBQUFBLE1BQWY7QUFBQSxRQUNDLGFBQVU7QUFBQSxRQUNWLFdBQVdGO0FBQUFBLFVBQ1Q7QUFBQSxVQUNBZSxTQUFTLFdBQ1A7QUFBQSxVQUNGQSxTQUFTLFVBQ1A7QUFBQSxVQUNGQSxTQUFTLFNBQ1A7QUFBQSxVQUNGQSxTQUFTLFlBQ1A7QUFBQSxVQUNGSjtBQUFBQSxRQUNGO0FBQUEsUUFDQSxHQUFJVDtBQUFBQSxRQUVIWTtBQUFBQTtBQUFBQSxVQUNBRSxtQkFDQyx1QkFBQyxlQUFlLE9BQWYsRUFBcUIsV0FBVSw4T0FDOUI7QUFBQSxtQ0FBQyxTQUFNLFdBQVUsWUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUI7QUFBQSxZQUN6Qix1QkFBQyxVQUFLLFdBQVUsV0FBVSxxQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0I7QUFBQSxlQUZqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUE7QUFBQTtBQUFBLE1BckJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXVCQTtBQUFBLE9BekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwQkE7QUFFSjtBQUFDQyxNQXZDUUo7QUF5Q1QsU0FBU0ssWUFBWSxFQUFFUCxXQUFXLEdBQUdULE1BQW1DLEdBQUc7QUFDekUsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsYUFBVTtBQUFBLE1BQ1YsV0FBV0YsR0FBRyw2QkFBNkJXLFNBQVM7QUFBQSxNQUNwRCxHQUFJVDtBQUFBQTtBQUFBQSxJQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUdZO0FBR2hCO0FBQUNpQixNQVJRRDtBQVVULFNBQVNFLFlBQVksRUFBRVQsV0FBVyxHQUFHVCxNQUFtQyxHQUFHO0FBQ3pFLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLGFBQVU7QUFBQSxNQUNWLFdBQVdGLEdBQUcsbUNBQW1DVyxTQUFTO0FBQUEsTUFDMUQsR0FBSVQ7QUFBQUE7QUFBQUEsSUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFHWTtBQUdoQjtBQUFDbUIsTUFSUUQ7QUFVVCxTQUFTRSxXQUFXLEVBQUVYLFdBQVcsR0FBR1QsTUFBeUQsR0FBRztBQUM5RixTQUNFO0FBQUEsSUFBQyxlQUFlO0FBQUEsSUFBZjtBQUFBLE1BQ0MsYUFBVTtBQUFBLE1BQ1YsV0FBV0YsR0FBRyxpQ0FBaUNXLFNBQVM7QUFBQSxNQUN4RCxHQUFJVDtBQUFBQTtBQUFBQSxJQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUdZO0FBR2hCO0FBQUNxQixNQVJRRDtBQVVULFNBQVNFLGlCQUFpQjtBQUFBLEVBQ3hCYjtBQUFBQSxFQUNBLEdBQUdUO0FBQ29ELEdBQUc7QUFDMUQsU0FDRTtBQUFBLElBQUMsZUFBZTtBQUFBLElBQWY7QUFBQSxNQUNDLGFBQVU7QUFBQSxNQUNWLFdBQVdGLEdBQUcsaUNBQWlDVyxTQUFTO0FBQUEsTUFDeEQsR0FBSVQ7QUFBQUE7QUFBQUEsSUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFHWTtBQUdoQjtBQUFDdUIsTUFYUUQ7QUFhVDtBQUFBLEVBQ0V2QjtBQUFBQSxFQUNBRztBQUFBQSxFQUNBRTtBQUFBQSxFQUNBTztBQUFBQSxFQUNBSztBQUFBQSxFQUNBRTtBQUFBQSxFQUNBRTtBQUFBQSxFQUNBRTtBQUFBQTtBQUNBLElBQUFyQixJQUFBRSxLQUFBRSxLQUFBRSxLQUFBRyxLQUFBSyxLQUFBRSxLQUFBRSxLQUFBRSxLQUFBRTtBQUFBLGFBQUF0QixJQUFBO0FBQUEsYUFBQUUsS0FBQTtBQUFBLGFBQUFFLEtBQUE7QUFBQSxhQUFBRSxLQUFBO0FBQUEsYUFBQUcsS0FBQTtBQUFBLGFBQUFLLEtBQUE7QUFBQSxhQUFBRSxLQUFBO0FBQUEsYUFBQUUsS0FBQTtBQUFBLGFBQUFFLEtBQUE7QUFBQSxhQUFBRSxLQUFBIiwibmFtZXMiOlsiWEljb24iLCJEaWFsb2ciLCJTaGVldFByaW1pdGl2ZSIsIlJlYWN0IiwiY24iLCJTaGVldCIsInByb3BzIiwiX2MiLCJTaGVldFRyaWdnZXIiLCJfYzIiLCJTaGVldENsb3NlIiwiX2MzIiwiU2hlZXRQb3J0YWwiLCJfYzQiLCJTaGVldE92ZXJsYXkiLCJjbGFzc05hbWUiLCJfYzUiLCJTaGVldENvbnRlbnQiLCJjaGlsZHJlbiIsInNpZGUiLCJzaG93Q2xvc2VCdXR0b24iLCJfYzYiLCJTaGVldEhlYWRlciIsIl9jNyIsIlNoZWV0Rm9vdGVyIiwiX2M4IiwiU2hlZXRUaXRsZSIsIl9jOSIsIlNoZWV0RGVzY3JpcHRpb24iLCJfYzAiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsic2hlZXQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFhJY29uIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IERpYWxvZyBhcyBTaGVldFByaW1pdGl2ZSB9IGZyb20gJ3JhZGl4LXVpJztcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcblxuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi9jbic7XG5cbmZ1bmN0aW9uIFNoZWV0KHsgLi4ucHJvcHMgfTogUmVhY3QuQ29tcG9uZW50UHJvcHM8dHlwZW9mIFNoZWV0UHJpbWl0aXZlLlJvb3Q+KSB7XG4gIHJldHVybiA8U2hlZXRQcmltaXRpdmUuUm9vdCBkYXRhLXNsb3Q9XCJzaGVldFwiIHsuLi5wcm9wc30gLz47XG59XG5cbmZ1bmN0aW9uIFNoZWV0VHJpZ2dlcih7IC4uLnByb3BzIH06IFJlYWN0LkNvbXBvbmVudFByb3BzPHR5cGVvZiBTaGVldFByaW1pdGl2ZS5UcmlnZ2VyPikge1xuICByZXR1cm4gPFNoZWV0UHJpbWl0aXZlLlRyaWdnZXIgZGF0YS1zbG90PVwic2hlZXQtdHJpZ2dlclwiIHsuLi5wcm9wc30gLz47XG59XG5cbmZ1bmN0aW9uIFNoZWV0Q2xvc2UoeyAuLi5wcm9wcyB9OiBSZWFjdC5Db21wb25lbnRQcm9wczx0eXBlb2YgU2hlZXRQcmltaXRpdmUuQ2xvc2U+KSB7XG4gIHJldHVybiA8U2hlZXRQcmltaXRpdmUuQ2xvc2UgZGF0YS1zbG90PVwic2hlZXQtY2xvc2VcIiB7Li4ucHJvcHN9IC8+O1xufVxuXG5mdW5jdGlvbiBTaGVldFBvcnRhbCh7IC4uLnByb3BzIH06IFJlYWN0LkNvbXBvbmVudFByb3BzPHR5cGVvZiBTaGVldFByaW1pdGl2ZS5Qb3J0YWw+KSB7XG4gIHJldHVybiA8U2hlZXRQcmltaXRpdmUuUG9ydGFsIGRhdGEtc2xvdD1cInNoZWV0LXBvcnRhbFwiIHsuLi5wcm9wc30gLz47XG59XG5cbmZ1bmN0aW9uIFNoZWV0T3ZlcmxheSh7XG4gIGNsYXNzTmFtZSxcbiAgLi4ucHJvcHNcbn06IFJlYWN0LkNvbXBvbmVudFByb3BzPHR5cGVvZiBTaGVldFByaW1pdGl2ZS5PdmVybGF5Pikge1xuICByZXR1cm4gKFxuICAgIDxTaGVldFByaW1pdGl2ZS5PdmVybGF5XG4gICAgICBkYXRhLXNsb3Q9XCJzaGVldC1vdmVybGF5XCJcbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICdkYXRhLVtzdGF0ZT1jbG9zZWRdOmFuaW1hdGUtb3V0IGRhdGEtW3N0YXRlPWNsb3NlZF06ZmFkZS1vdXQtMCBkYXRhLVtzdGF0ZT1vcGVuXTphbmltYXRlLWluIGRhdGEtW3N0YXRlPW9wZW5dOmZhZGUtaW4tMCBmaXhlZCBpbnNldC0wIHotNTAgYmctYmxhY2svNTAnLFxuICAgICAgICBjbGFzc05hbWUsXG4gICAgICApfVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gICk7XG59XG5cbmZ1bmN0aW9uIFNoZWV0Q29udGVudCh7XG4gIGNsYXNzTmFtZSxcbiAgY2hpbGRyZW4sXG4gIHNpZGUgPSAncmlnaHQnLFxuICBzaG93Q2xvc2VCdXR0b24gPSB0cnVlLFxuICAuLi5wcm9wc1xufTogUmVhY3QuQ29tcG9uZW50UHJvcHM8dHlwZW9mIFNoZWV0UHJpbWl0aXZlLkNvbnRlbnQ+ICYge1xuICBzaWRlPzogJ3RvcCcgfCAncmlnaHQnIHwgJ2JvdHRvbScgfCAnbGVmdCc7XG4gIHNob3dDbG9zZUJ1dHRvbj86IGJvb2xlYW47XG59KSB7XG4gIHJldHVybiAoXG4gICAgPFNoZWV0UG9ydGFsPlxuICAgICAgPFNoZWV0T3ZlcmxheSAvPlxuICAgICAgPFNoZWV0UHJpbWl0aXZlLkNvbnRlbnRcbiAgICAgICAgZGF0YS1zbG90PVwic2hlZXQtY29udGVudFwiXG4gICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgJ2RhdGEtW3N0YXRlPWNsb3NlZF06YW5pbWF0ZS1vdXQgZGF0YS1bc3RhdGU9b3Blbl06YW5pbWF0ZS1pbiBmaXhlZCB6LTUwIGZsZXggZmxleC1jb2wgZ2FwLTQgYmctYmFja2dyb3VuZCBzaGFkb3ctbGcgdHJhbnNpdGlvbiBlYXNlLWluLW91dCBkYXRhLVtzdGF0ZT1jbG9zZWRdOmR1cmF0aW9uLTMwMCBkYXRhLVtzdGF0ZT1vcGVuXTpkdXJhdGlvbi01MDAnLFxuICAgICAgICAgIHNpZGUgPT09ICdyaWdodCcgJiZcbiAgICAgICAgICAgICdkYXRhLVtzdGF0ZT1jbG9zZWRdOnNsaWRlLW91dC10by1yaWdodCBkYXRhLVtzdGF0ZT1vcGVuXTpzbGlkZS1pbi1mcm9tLXJpZ2h0IGluc2V0LXktMCByaWdodC0wIGgtZnVsbCB3LTMvNCBib3JkZXItbCBzbTptYXgtdy1zbScsXG4gICAgICAgICAgc2lkZSA9PT0gJ2xlZnQnICYmXG4gICAgICAgICAgICAnZGF0YS1bc3RhdGU9Y2xvc2VkXTpzbGlkZS1vdXQtdG8tbGVmdCBkYXRhLVtzdGF0ZT1vcGVuXTpzbGlkZS1pbi1mcm9tLWxlZnQgaW5zZXQteS0wIGxlZnQtMCBoLWZ1bGwgdy0zLzQgYm9yZGVyLXIgc206bWF4LXctc20nLFxuICAgICAgICAgIHNpZGUgPT09ICd0b3AnICYmXG4gICAgICAgICAgICAnZGF0YS1bc3RhdGU9Y2xvc2VkXTpzbGlkZS1vdXQtdG8tdG9wIGRhdGEtW3N0YXRlPW9wZW5dOnNsaWRlLWluLWZyb20tdG9wIGluc2V0LXgtMCB0b3AtMCBoLWF1dG8gYm9yZGVyLWInLFxuICAgICAgICAgIHNpZGUgPT09ICdib3R0b20nICYmXG4gICAgICAgICAgICAnZGF0YS1bc3RhdGU9Y2xvc2VkXTpzbGlkZS1vdXQtdG8tYm90dG9tIGRhdGEtW3N0YXRlPW9wZW5dOnNsaWRlLWluLWZyb20tYm90dG9tIGluc2V0LXgtMCBib3R0b20tMCBoLWF1dG8gYm9yZGVyLXQnLFxuICAgICAgICAgIGNsYXNzTmFtZSxcbiAgICAgICAgKX1cbiAgICAgICAgey4uLnByb3BzfVxuICAgICAgPlxuICAgICAgICB7Y2hpbGRyZW59XG4gICAgICAgIHtzaG93Q2xvc2VCdXR0b24gJiYgKFxuICAgICAgICAgIDxTaGVldFByaW1pdGl2ZS5DbG9zZSBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtNCByaWdodC00IHJvdW5kZWQteHMgb3BhY2l0eS03MCByaW5nLW9mZnNldC1iYWNrZ3JvdW5kIHRyYW5zaXRpb24tb3BhY2l0eSBob3ZlcjpvcGFjaXR5LTEwMCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1yaW5nIGZvY3VzOnJpbmctb2Zmc2V0LTIgZm9jdXM6b3V0bGluZS1oaWRkZW4gZGlzYWJsZWQ6cG9pbnRlci1ldmVudHMtbm9uZSBkYXRhLVtzdGF0ZT1vcGVuXTpiZy1zZWNvbmRhcnlcIj5cbiAgICAgICAgICAgIDxYSWNvbiBjbGFzc05hbWU9XCJzaXplLTRcIiAvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3Itb25seVwiPkNsb3NlPC9zcGFuPlxuICAgICAgICAgIDwvU2hlZXRQcmltaXRpdmUuQ2xvc2U+XG4gICAgICAgICl9XG4gICAgICA8L1NoZWV0UHJpbWl0aXZlLkNvbnRlbnQ+XG4gICAgPC9TaGVldFBvcnRhbD5cbiAgKTtcbn1cblxuZnVuY3Rpb24gU2hlZXRIZWFkZXIoeyBjbGFzc05hbWUsIC4uLnByb3BzIH06IFJlYWN0LkNvbXBvbmVudFByb3BzPCdkaXYnPikge1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGRhdGEtc2xvdD1cInNoZWV0LWhlYWRlclwiXG4gICAgICBjbGFzc05hbWU9e2NuKCdmbGV4IGZsZXgtY29sIGdhcC0xLjUgcC00JywgY2xhc3NOYW1lKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApO1xufVxuXG5mdW5jdGlvbiBTaGVldEZvb3Rlcih7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfTogUmVhY3QuQ29tcG9uZW50UHJvcHM8J2Rpdic+KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgZGF0YS1zbG90PVwic2hlZXQtZm9vdGVyXCJcbiAgICAgIGNsYXNzTmFtZT17Y24oJ210LWF1dG8gZmxleCBmbGV4LWNvbCBnYXAtMiBwLTQnLCBjbGFzc05hbWUpfVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gICk7XG59XG5cbmZ1bmN0aW9uIFNoZWV0VGl0bGUoeyBjbGFzc05hbWUsIC4uLnByb3BzIH06IFJlYWN0LkNvbXBvbmVudFByb3BzPHR5cGVvZiBTaGVldFByaW1pdGl2ZS5UaXRsZT4pIHtcbiAgcmV0dXJuIChcbiAgICA8U2hlZXRQcmltaXRpdmUuVGl0bGVcbiAgICAgIGRhdGEtc2xvdD1cInNoZWV0LXRpdGxlXCJcbiAgICAgIGNsYXNzTmFtZT17Y24oJ2ZvbnQtc2VtaWJvbGQgdGV4dC1mb3JlZ3JvdW5kJywgY2xhc3NOYW1lKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApO1xufVxuXG5mdW5jdGlvbiBTaGVldERlc2NyaXB0aW9uKHtcbiAgY2xhc3NOYW1lLFxuICAuLi5wcm9wc1xufTogUmVhY3QuQ29tcG9uZW50UHJvcHM8dHlwZW9mIFNoZWV0UHJpbWl0aXZlLkRlc2NyaXB0aW9uPikge1xuICByZXR1cm4gKFxuICAgIDxTaGVldFByaW1pdGl2ZS5EZXNjcmlwdGlvblxuICAgICAgZGF0YS1zbG90PVwic2hlZXQtZGVzY3JpcHRpb25cIlxuICAgICAgY2xhc3NOYW1lPXtjbigndGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmQnLCBjbGFzc05hbWUpfVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gICk7XG59XG5cbmV4cG9ydCB7XG4gIFNoZWV0LFxuICBTaGVldFRyaWdnZXIsXG4gIFNoZWV0Q2xvc2UsXG4gIFNoZWV0Q29udGVudCxcbiAgU2hlZXRIZWFkZXIsXG4gIFNoZWV0Rm9vdGVyLFxuICBTaGVldFRpdGxlLFxuICBTaGVldERlc2NyaXB0aW9uLFxufTtcbiJdLCJmaWxlIjoiL1VzZXJzL2ZpbGlwZWNhdmFsY2FudGUvRG9jdW1lbnRzL0p1bmdsZUdhbWluZ1Rlc3RlL3NyYy9jb21wb25lbnRzL3VpL3NoZWV0LnRzeCJ9