import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/FilterSidebar.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Button } from "/src/components/ui/button.tsx";
import { NFT_CATEGORY_LABELS, NFT_NETWORK_LABELS } from "/src/contracts/nft.ts";
import { FilterChecklist } from "/src/features/catalog/components/FilterChecklist.tsx";
import { PriceRangeFilter } from "/src/features/catalog/components/PriceRangeFilter.tsx";
export function FilterSidebar({ search, facets, apply, clear }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 bg-surface-card p-5", children: [
    /* @__PURE__ */ jsxDEV("section", { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-2 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-lg leading-[22px] font-bold", children: "Coleções" }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterSidebar.tsx",
          lineNumber: 12,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", className: "min-h-11 px-0 text-xs md:min-h-[22px]", onClick: clear, children: "Limpar filtros" }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterSidebar.tsx",
          lineNumber: 13,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterSidebar.tsx",
        lineNumber: 11,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-0", children: /* @__PURE__ */ jsxDEV(
        FilterChecklist,
        {
          options: facets?.categories ?? [],
          selected: search.category,
          labels: NFT_CATEGORY_LABELS,
          change: (category) => {
            apply({ category });
          }
        },
        void 0,
        false,
        {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterSidebar.tsx",
          lineNumber: 18,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterSidebar.tsx",
        lineNumber: 17,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterSidebar.tsx",
      lineNumber: 10,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      PriceRangeFilter,
      {
        search,
        apply
      },
      `${search.minPrice ?? ""}:${search.maxPrice ?? ""}`,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterSidebar.tsx",
        lineNumber: 28,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("section", { className: "space-y-0", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-2 text-lg leading-[22px] font-bold", children: "Rede" }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterSidebar.tsx",
        lineNumber: 34,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        FilterChecklist,
        {
          options: facets?.networks ?? [],
          selected: search.network,
          labels: NFT_NETWORK_LABELS,
          change: (network) => {
            apply({ network });
          }
        },
        void 0,
        false,
        {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterSidebar.tsx",
          lineNumber: 35,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterSidebar.tsx",
      lineNumber: 33,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterSidebar.tsx",
    lineNumber: 9,
    columnNumber: 5
  }, this);
}
_c = FilterSidebar;
var _c;
$RefreshReg$(_c, "FilterSidebar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterSidebar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterSidebar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterSidebar.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV1U7QUFYVixTQUFTQSxjQUFjO0FBQ3ZCLFNBQVNDLHFCQUFxQkMsMEJBQTBCO0FBQ3hELFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyx3QkFBd0I7QUFHMUIsZ0JBQVNDLGNBQWMsRUFBRUMsUUFBUUMsUUFBUUMsT0FBT0MsTUFBbUIsR0FBRztBQUMzRSxTQUNFLHVCQUFDLFNBQUksV0FBVSxpQ0FDYjtBQUFBLDJCQUFDLGFBQ0M7QUFBQSw2QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsb0NBQW1DLHdCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlEO0FBQUEsUUFDekQsdUJBQUMsVUFBTyxTQUFRLFNBQVEsV0FBVSx5Q0FBd0MsU0FBU0EsT0FBTSw4QkFBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTRixRQUFRRyxjQUFjO0FBQUEsVUFDL0IsVUFBVUosT0FBT0s7QUFBQUEsVUFDakIsUUFBUVY7QUFBQUEsVUFDUixRQUFRLENBQUNVLGFBQWE7QUFDcEJILGtCQUFNLEVBQUVHLFNBQVMsQ0FBQztBQUFBLFVBQ3BCO0FBQUE7QUFBQSxRQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1JLEtBUE47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsU0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLElBQ0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUVDO0FBQUEsUUFDQTtBQUFBO0FBQUEsTUFGSyxHQUFHTCxPQUFPTSxZQUFZLEVBQUUsSUFBSU4sT0FBT08sWUFBWSxFQUFFO0FBQUEsTUFEeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUdlO0FBQUEsSUFFZix1QkFBQyxhQUFRLFdBQVUsYUFDakI7QUFBQSw2QkFBQyxRQUFHLFdBQVUseUNBQXdDLG9CQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBEO0FBQUEsTUFDMUQ7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVNOLFFBQVFPLFlBQVk7QUFBQSxVQUM3QixVQUFVUixPQUFPUztBQUFBQSxVQUNqQixRQUFRYjtBQUFBQSxVQUNSLFFBQVEsQ0FBQ2EsWUFBWTtBQUNuQlAsa0JBQU0sRUFBRU8sUUFBUSxDQUFDO0FBQUEsVUFDbkI7QUFBQTtBQUFBLFFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUk7QUFBQSxTQVJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLE9BbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtQ0E7QUFFSjtBQUFDQyxLQXZDZVg7QUFBYSxJQUFBVztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJCdXR0b24iLCJORlRfQ0FURUdPUllfTEFCRUxTIiwiTkZUX05FVFdPUktfTEFCRUxTIiwiRmlsdGVyQ2hlY2tsaXN0IiwiUHJpY2VSYW5nZUZpbHRlciIsIkZpbHRlclNpZGViYXIiLCJzZWFyY2giLCJmYWNldHMiLCJhcHBseSIsImNsZWFyIiwiY2F0ZWdvcmllcyIsImNhdGVnb3J5IiwibWluUHJpY2UiLCJtYXhQcmljZSIsIm5ldHdvcmtzIiwibmV0d29yayIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkZpbHRlclNpZGViYXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nO1xuaW1wb3J0IHsgTkZUX0NBVEVHT1JZX0xBQkVMUywgTkZUX05FVFdPUktfTEFCRUxTIH0gZnJvbSAnQC9jb250cmFjdHMvbmZ0JztcbmltcG9ydCB7IEZpbHRlckNoZWNrbGlzdCB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy9jb21wb25lbnRzL0ZpbHRlckNoZWNrbGlzdCc7XG5pbXBvcnQgeyBQcmljZVJhbmdlRmlsdGVyIH0gZnJvbSAnQC9mZWF0dXJlcy9jYXRhbG9nL2NvbXBvbmVudHMvUHJpY2VSYW5nZUZpbHRlcic7XG5pbXBvcnQgdHlwZSB7IEZpbHRlclByb3BzIH0gZnJvbSAnQC9mZWF0dXJlcy9jYXRhbG9nL2ZpbHRlci1wcm9wcyc7XG5cbmV4cG9ydCBmdW5jdGlvbiBGaWx0ZXJTaWRlYmFyKHsgc2VhcmNoLCBmYWNldHMsIGFwcGx5LCBjbGVhciB9OiBGaWx0ZXJQcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02IGJnLXN1cmZhY2UtY2FyZCBwLTVcIj5cbiAgICAgIDxzZWN0aW9uPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgbGVhZGluZy1bMjJweF0gZm9udC1ib2xkXCI+Q29sZcOnw7VlczwvaDI+XG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiBjbGFzc05hbWU9XCJtaW4taC0xMSBweC0wIHRleHQteHMgbWQ6bWluLWgtWzIycHhdXCIgb25DbGljaz17Y2xlYXJ9PlxuICAgICAgICAgICAgTGltcGFyIGZpbHRyb3NcbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0wXCI+XG4gICAgICAgICAgPEZpbHRlckNoZWNrbGlzdFxuICAgICAgICAgICAgb3B0aW9ucz17ZmFjZXRzPy5jYXRlZ29yaWVzID8/IFtdfVxuICAgICAgICAgICAgc2VsZWN0ZWQ9e3NlYXJjaC5jYXRlZ29yeX1cbiAgICAgICAgICAgIGxhYmVscz17TkZUX0NBVEVHT1JZX0xBQkVMU31cbiAgICAgICAgICAgIGNoYW5nZT17KGNhdGVnb3J5KSA9PiB7XG4gICAgICAgICAgICAgIGFwcGx5KHsgY2F0ZWdvcnkgfSk7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuICAgICAgPFByaWNlUmFuZ2VGaWx0ZXJcbiAgICAgICAga2V5PXtgJHtzZWFyY2gubWluUHJpY2UgPz8gJyd9OiR7c2VhcmNoLm1heFByaWNlID8/ICcnfWB9XG4gICAgICAgIHNlYXJjaD17c2VhcmNofVxuICAgICAgICBhcHBseT17YXBwbHl9XG4gICAgICAvPlxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic3BhY2UteS0wXCI+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi0yIHRleHQtbGcgbGVhZGluZy1bMjJweF0gZm9udC1ib2xkXCI+UmVkZTwvaDM+XG4gICAgICAgIDxGaWx0ZXJDaGVja2xpc3RcbiAgICAgICAgICBvcHRpb25zPXtmYWNldHM/Lm5ldHdvcmtzID8/IFtdfVxuICAgICAgICAgIHNlbGVjdGVkPXtzZWFyY2gubmV0d29ya31cbiAgICAgICAgICBsYWJlbHM9e05GVF9ORVRXT1JLX0xBQkVMU31cbiAgICAgICAgICBjaGFuZ2U9eyhuZXR3b3JrKSA9PiB7XG4gICAgICAgICAgICBhcHBseSh7IG5ldHdvcmsgfSk7XG4gICAgICAgICAgfX1cbiAgICAgICAgLz5cbiAgICAgIDwvc2VjdGlvbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2ZpbGlwZWNhdmFsY2FudGUvRG9jdW1lbnRzL0p1bmdsZUdhbWluZ1Rlc3RlL3NyYy9mZWF0dXJlcy9jYXRhbG9nL2NvbXBvbmVudHMvRmlsdGVyU2lkZWJhci50c3gifQ==