import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/NftCardInfo.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { cn } from "/src/lib/cn.ts";
import { formatEth } from "/src/lib/money.ts";
export function NftCardInfo({ nft, variant }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-0 px-2 lg:space-y-3 lg:px-0", children: [
    /* @__PURE__ */ jsxDEV(
      "h3",
      {
        className: cn(
          "min-w-0 text-body-sm leading-4 font-normal wrap-anywhere",
          variant === "catalog" && "lg:text-base"
        ),
        children: nft.name
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCardInfo.tsx",
        lineNumber: 10,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2", children: [
      /* @__PURE__ */ jsxDEV(
        "span",
        {
          className: cn(
            "text-base leading-4 font-bold text-text-accent",
            variant === "catalog" && "lg:text-lg"
          ),
          children: formatEth(nft.price)
        },
        void 0,
        false,
        {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCardInfo.tsx",
          lineNumber: 19,
          columnNumber: 9
        },
        this
      ),
      nft.compareAtPrice && /* @__PURE__ */ jsxDEV(
        "s",
        {
          className: cn(
            "text-xs leading-4 text-secondary",
            variant === "catalog" && "lg:text-lg"
          ),
          children: formatEth(nft.compareAtPrice)
        },
        void 0,
        false,
        {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCardInfo.tsx",
          lineNumber: 28,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCardInfo.tsx",
      lineNumber: 18,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCardInfo.tsx",
    lineNumber: 9,
    columnNumber: 5
  }, this);
}
_c = NftCardInfo;
var _c;
$RefreshReg$(_c, "NftCardInfo");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCardInfo.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCardInfo.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCardInfo.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU007QUFSTixTQUFTQSxVQUFVO0FBQ25CLFNBQVNDLGlCQUFpQjtBQUluQixnQkFBU0MsWUFBWSxFQUFFQyxLQUFLQyxRQUErQyxHQUFHO0FBQ25GLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVdKO0FBQUFBLFVBQ1Q7QUFBQSxVQUNBSSxZQUFZLGFBQWE7QUFBQSxRQUMzQjtBQUFBLFFBRUNELGNBQUlFO0FBQUFBO0FBQUFBLE1BTlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBT0E7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFXTDtBQUFBQSxZQUNUO0FBQUEsWUFDQUksWUFBWSxhQUFhO0FBQUEsVUFDM0I7QUFBQSxVQUVDSCxvQkFBVUUsSUFBSUcsS0FBSztBQUFBO0FBQUEsUUFOdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQSxNQUNDSCxJQUFJSSxrQkFDSDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBV1A7QUFBQUEsWUFDVDtBQUFBLFlBQ0FJLFlBQVksYUFBYTtBQUFBLFVBQzNCO0FBQUEsVUFFQ0gsb0JBQVVFLElBQUlJLGNBQWM7QUFBQTtBQUFBLFFBTi9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BO0FBQUEsU0FqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CQTtBQUFBLE9BNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2QkE7QUFFSjtBQUFDQyxLQWpDZU47QUFBVyxJQUFBTTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJjbiIsImZvcm1hdEV0aCIsIk5mdENhcmRJbmZvIiwibmZ0IiwidmFyaWFudCIsIm5hbWUiLCJwcmljZSIsImNvbXBhcmVBdFByaWNlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTmZ0Q2FyZEluZm8udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgTmZ0IH0gZnJvbSAnQC9jb250cmFjdHMvbmZ0JztcbmltcG9ydCB7IGNuIH0gZnJvbSAnQC9saWIvY24nO1xuaW1wb3J0IHsgZm9ybWF0RXRoIH0gZnJvbSAnQC9saWIvbW9uZXknO1xuXG5leHBvcnQgdHlwZSBOZnRDYXJkVmFyaWFudCA9ICdjYXRhbG9nJyB8ICdjYXJvdXNlbCc7XG5cbmV4cG9ydCBmdW5jdGlvbiBOZnRDYXJkSW5mbyh7IG5mdCwgdmFyaWFudCB9OiB7IG5mdDogTmZ0OyB2YXJpYW50OiBOZnRDYXJkVmFyaWFudCB9KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTAgcHgtMiBsZzpzcGFjZS15LTMgbGc6cHgtMFwiPlxuICAgICAgPGgzXG4gICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgJ21pbi13LTAgdGV4dC1ib2R5LXNtIGxlYWRpbmctNCBmb250LW5vcm1hbCB3cmFwLWFueXdoZXJlJyxcbiAgICAgICAgICB2YXJpYW50ID09PSAnY2F0YWxvZycgJiYgJ2xnOnRleHQtYmFzZScsXG4gICAgICAgICl9XG4gICAgICA+XG4gICAgICAgIHtuZnQubmFtZX1cbiAgICAgIDwvaDM+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICA8c3BhblxuICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAndGV4dC1iYXNlIGxlYWRpbmctNCBmb250LWJvbGQgdGV4dC10ZXh0LWFjY2VudCcsXG4gICAgICAgICAgICB2YXJpYW50ID09PSAnY2F0YWxvZycgJiYgJ2xnOnRleHQtbGcnLFxuICAgICAgICAgICl9XG4gICAgICAgID5cbiAgICAgICAgICB7Zm9ybWF0RXRoKG5mdC5wcmljZSl9XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgICAge25mdC5jb21wYXJlQXRQcmljZSAmJiAoXG4gICAgICAgICAgPHNcbiAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICd0ZXh0LXhzIGxlYWRpbmctNCB0ZXh0LXNlY29uZGFyeScsXG4gICAgICAgICAgICAgIHZhcmlhbnQgPT09ICdjYXRhbG9nJyAmJiAnbGc6dGV4dC1sZycsXG4gICAgICAgICAgICApfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHtmb3JtYXRFdGgobmZ0LmNvbXBhcmVBdFByaWNlKX1cbiAgICAgICAgICA8L3M+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2ZpbGlwZWNhdmFsY2FudGUvRG9jdW1lbnRzL0p1bmdsZUdhbWluZ1Rlc3RlL3NyYy9mZWF0dXJlcy9jYXRhbG9nL2NvbXBvbmVudHMvTmZ0Q2FyZEluZm8udHN4In0=