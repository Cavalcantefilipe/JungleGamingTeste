import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/CatalogAnnouncement.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { catalogMessages } from "/src/features/catalog/messages.ts";
export function CatalogAnnouncement({
  query,
  announcement
}) {
  const count = query.isSuccess && !query.isPlaceholderData ? catalogMessages.resultsFound(query.data.total) : "";
  const message = announcement.navigating || query.isFetching ? catalogMessages.updating : count;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    !announcement.enabled && /* @__PURE__ */ jsxDEV("div", { className: "sr-only", children: count }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogAnnouncement.tsx",
      lineNumber: 19,
      columnNumber: 33
    }, this),
    /* @__PURE__ */ jsxDEV("div", { "aria-live": "polite", "aria-atomic": "true", className: "sr-only", children: announcement.enabled ? message : "" }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogAnnouncement.tsx",
      lineNumber: 20,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogAnnouncement.tsx",
    lineNumber: 18,
    columnNumber: 5
  }, this);
}
_c = CatalogAnnouncement;
var _c;
$RefreshReg$(_c, "CatalogAnnouncement");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogAnnouncement.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogAnnouncement.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogAnnouncement.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJJLG1CQUM0QixjQUQ1QjtBQWpCSixTQUFTQSx1QkFBdUI7QUFJekIsZ0JBQVNDLG9CQUFvQjtBQUFBLEVBQ2xDQztBQUFBQSxFQUNBQztBQUlGLEdBQUc7QUFDRCxRQUFNQyxRQUNKRixNQUFNRyxhQUFhLENBQUNILE1BQU1JLG9CQUN0Qk4sZ0JBQWdCTyxhQUFhTCxNQUFNTSxLQUFLQyxLQUFLLElBQzdDO0FBQ04sUUFBTUMsVUFBVVAsYUFBYVEsY0FBY1QsTUFBTVUsYUFBYVosZ0JBQWdCYSxXQUFXVDtBQUN6RixTQUNFLG1DQUNHO0FBQUEsS0FBQ0QsYUFBYVcsV0FBVyx1QkFBQyxTQUFJLFdBQVUsV0FBV1YsbUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0M7QUFBQSxJQUMxRCx1QkFBQyxTQUFJLGFBQVUsVUFBUyxlQUFZLFFBQU8sV0FBVSxXQUNsREQsdUJBQWFXLFVBQVVKLFVBQVUsTUFEcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBS0E7QUFFSjtBQUFDSyxLQXBCZWQ7QUFBbUIsSUFBQWM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiY2F0YWxvZ01lc3NhZ2VzIiwiQ2F0YWxvZ0Fubm91bmNlbWVudCIsInF1ZXJ5IiwiYW5ub3VuY2VtZW50IiwiY291bnQiLCJpc1N1Y2Nlc3MiLCJpc1BsYWNlaG9sZGVyRGF0YSIsInJlc3VsdHNGb3VuZCIsImRhdGEiLCJ0b3RhbCIsIm1lc3NhZ2UiLCJuYXZpZ2F0aW5nIiwiaXNGZXRjaGluZyIsInVwZGF0aW5nIiwiZW5hYmxlZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNhdGFsb2dBbm5vdW5jZW1lbnQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNhdGFsb2dNZXNzYWdlcyB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy9tZXNzYWdlcyc7XG5pbXBvcnQgdHlwZSB7IHVzZUNhdGFsb2dRdWVyeSB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy9xdWVyaWVzJztcbmltcG9ydCB0eXBlIHsgdXNlQ2F0YWxvZ0Fubm91bmNlbWVudCB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy91c2VDYXRhbG9nQW5ub3VuY2VtZW50JztcblxuZXhwb3J0IGZ1bmN0aW9uIENhdGFsb2dBbm5vdW5jZW1lbnQoe1xuICBxdWVyeSxcbiAgYW5ub3VuY2VtZW50LFxufToge1xuICBxdWVyeTogUmV0dXJuVHlwZTx0eXBlb2YgdXNlQ2F0YWxvZ1F1ZXJ5PjtcbiAgYW5ub3VuY2VtZW50OiBSZXR1cm5UeXBlPHR5cGVvZiB1c2VDYXRhbG9nQW5ub3VuY2VtZW50Pjtcbn0pIHtcbiAgY29uc3QgY291bnQgPVxuICAgIHF1ZXJ5LmlzU3VjY2VzcyAmJiAhcXVlcnkuaXNQbGFjZWhvbGRlckRhdGFcbiAgICAgID8gY2F0YWxvZ01lc3NhZ2VzLnJlc3VsdHNGb3VuZChxdWVyeS5kYXRhLnRvdGFsKVxuICAgICAgOiAnJztcbiAgY29uc3QgbWVzc2FnZSA9IGFubm91bmNlbWVudC5uYXZpZ2F0aW5nIHx8IHF1ZXJ5LmlzRmV0Y2hpbmcgPyBjYXRhbG9nTWVzc2FnZXMudXBkYXRpbmcgOiBjb3VudDtcbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgeyFhbm5vdW5jZW1lbnQuZW5hYmxlZCAmJiA8ZGl2IGNsYXNzTmFtZT1cInNyLW9ubHlcIj57Y291bnR9PC9kaXY+fVxuICAgICAgPGRpdiBhcmlhLWxpdmU9XCJwb2xpdGVcIiBhcmlhLWF0b21pYz1cInRydWVcIiBjbGFzc05hbWU9XCJzci1vbmx5XCI+XG4gICAgICAgIHthbm5vdW5jZW1lbnQuZW5hYmxlZCA/IG1lc3NhZ2UgOiAnJ31cbiAgICAgIDwvZGl2PlxuICAgIDwvPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvZmlsaXBlY2F2YWxjYW50ZS9Eb2N1bWVudHMvSnVuZ2xlR2FtaW5nVGVzdGUvc3JjL2ZlYXR1cmVzL2NhdGFsb2cvY29tcG9uZW50cy9DYXRhbG9nQW5ub3VuY2VtZW50LnRzeCJ9