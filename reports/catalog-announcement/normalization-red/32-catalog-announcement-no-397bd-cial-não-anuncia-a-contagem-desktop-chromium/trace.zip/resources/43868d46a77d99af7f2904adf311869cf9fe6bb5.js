import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/media/ArtworkImage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { ArtworkUnavailable } from "/src/components/media/ArtworkUnavailable.tsx";
import { useArtworkSource } from "/src/components/media/useArtworkSource.ts";
export function ArtworkImage({
  src,
  alt,
  sizes,
  loading = "lazy",
  className,
  onError,
  "data-testid": testId,
  ...props
}) {
  _s();
  const artwork = useArtworkSource(src);
  const base = artwork.base;
  const sources = (format) => `${base}-400.${format} 400w, ${base}-800.${format} 800w`;
  if (artwork.unavailable)
    return /* @__PURE__ */ jsxDEV(ArtworkUnavailable, { alt, className, testId, dimensions: props }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/media/ArtworkImage.tsx",
      lineNumber: 28,
      columnNumber: 5
    }, this);
  return /* @__PURE__ */ jsxDEV("picture", { className: "contents", children: [
    base && artwork.avif && /* @__PURE__ */ jsxDEV("source", { className: "hidden", type: "image/avif", srcSet: sources("avif"), sizes }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/media/ArtworkImage.tsx",
      lineNumber: 33,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "img",
      {
        ...props,
        src: artwork.src,
        alt,
        className,
        "data-testid": testId,
        onError: (event) => {
          artwork.fail(event.currentTarget.currentSrc || event.currentTarget.src);
          onError?.(event);
        },
        loading,
        sizes: base ? sizes : void 0,
        srcSet: base ? sources("webp") : void 0
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/media/ArtworkImage.tsx",
        lineNumber: 35,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/media/ArtworkImage.tsx",
    lineNumber: 31,
    columnNumber: 5
  }, this);
}
_s(ArtworkImage, "wtJ5Rs5I8gLoCw6DqRZM2Uxy8ok=", false, function() {
  return [useArtworkSource];
});
_c = ArtworkImage;
var _c;
$RefreshReg$(_c, "ArtworkImage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/media/ArtworkImage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/media/ArtworkImage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/media/ArtworkImage.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkJNOztBQTNCTixTQUFTQSwwQkFBMEI7QUFDbkMsU0FBU0Msd0JBQXdCO0FBVzFCLGdCQUFTQyxhQUFhO0FBQUEsRUFDM0JDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDLFVBQVU7QUFBQSxFQUNWQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBLGVBQWVDO0FBQUFBLEVBQ2YsR0FBR0M7QUFDYyxHQUFHO0FBQUFDLEtBQUE7QUFDcEIsUUFBTUMsVUFBVVgsaUJBQWlCRSxHQUFHO0FBQ3BDLFFBQU1VLE9BQU9ELFFBQVFDO0FBQ3JCLFFBQU1DLFVBQVVBLENBQUNDLFdBQW1CLEdBQUdGLElBQUksUUFBUUUsTUFBTSxVQUFVRixJQUFJLFFBQVFFLE1BQU07QUFDckYsTUFBSUgsUUFBUUk7QUFDVixXQUNFLHVCQUFDLHNCQUFtQixLQUFVLFdBQXNCLFFBQWdCLFlBQVlOLFNBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0Y7QUFFMUYsU0FDRSx1QkFBQyxhQUFRLFdBQVUsWUFDaEJHO0FBQUFBLFlBQVFELFFBQVFLLFFBQ2YsdUJBQUMsWUFBTyxXQUFVLFVBQVMsTUFBSyxjQUFhLFFBQVFILFFBQVEsTUFBTSxHQUFHLFNBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUY7QUFBQSxJQUVyRjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsR0FBSUo7QUFBQUEsUUFDSixLQUFLRSxRQUFRVDtBQUFBQSxRQUNiO0FBQUEsUUFDQTtBQUFBLFFBQ0EsZUFBYU07QUFBQUEsUUFDYixTQUFTLENBQUNTLFVBQVU7QUFDbEJOLGtCQUFRTyxLQUFLRCxNQUFNRSxjQUFjQyxjQUFjSCxNQUFNRSxjQUFjakIsR0FBRztBQUN0RUssb0JBQVVVLEtBQUs7QUFBQSxRQUNqQjtBQUFBLFFBQ0E7QUFBQSxRQUNBLE9BQU9MLE9BQU9SLFFBQVFpQjtBQUFBQSxRQUN0QixRQUFRVCxPQUFPQyxRQUFRLE1BQU0sSUFBSVE7QUFBQUE7QUFBQUEsTUFabkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBWTZDO0FBQUEsT0FoQi9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrQkE7QUFFSjtBQUFDWCxHQXRDZVQsY0FBWTtBQUFBLFVBVVZELGdCQUFnQjtBQUFBO0FBQUEsS0FWbEJDO0FBQVksSUFBQXFCO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkFydHdvcmtVbmF2YWlsYWJsZSIsInVzZUFydHdvcmtTb3VyY2UiLCJBcnR3b3JrSW1hZ2UiLCJzcmMiLCJhbHQiLCJzaXplcyIsImxvYWRpbmciLCJjbGFzc05hbWUiLCJvbkVycm9yIiwidGVzdElkIiwicHJvcHMiLCJfcyIsImFydHdvcmsiLCJiYXNlIiwic291cmNlcyIsImZvcm1hdCIsInVuYXZhaWxhYmxlIiwiYXZpZiIsImV2ZW50IiwiZmFpbCIsImN1cnJlbnRUYXJnZXQiLCJjdXJyZW50U3JjIiwidW5kZWZpbmVkIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQXJ0d29ya0ltYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBcnR3b3JrVW5hdmFpbGFibGUgfSBmcm9tICdAL2NvbXBvbmVudHMvbWVkaWEvQXJ0d29ya1VuYXZhaWxhYmxlJztcbmltcG9ydCB7IHVzZUFydHdvcmtTb3VyY2UgfSBmcm9tICdAL2NvbXBvbmVudHMvbWVkaWEvdXNlQXJ0d29ya1NvdXJjZSc7XG5cbmltcG9ydCB0eXBlIHsgQ29tcG9uZW50UHJvcHMgfSBmcm9tICdyZWFjdCc7XG5cbnR5cGUgQXJ0d29ya0ltYWdlUHJvcHMgPSBPbWl0PENvbXBvbmVudFByb3BzPCdpbWcnPiwgJ3NyYycgfCAnYWx0JyB8ICdzaXplcyc+ICYge1xuICBzcmM6IHN0cmluZyB8IHVuZGVmaW5lZDtcbiAgYWx0OiBzdHJpbmc7XG4gIHNpemVzOiBzdHJpbmc7XG4gICdkYXRhLXRlc3RpZCc/OiBzdHJpbmc7XG59O1xuXG5leHBvcnQgZnVuY3Rpb24gQXJ0d29ya0ltYWdlKHtcbiAgc3JjLFxuICBhbHQsXG4gIHNpemVzLFxuICBsb2FkaW5nID0gJ2xhenknLFxuICBjbGFzc05hbWUsXG4gIG9uRXJyb3IsXG4gICdkYXRhLXRlc3RpZCc6IHRlc3RJZCxcbiAgLi4ucHJvcHNcbn06IEFydHdvcmtJbWFnZVByb3BzKSB7XG4gIGNvbnN0IGFydHdvcmsgPSB1c2VBcnR3b3JrU291cmNlKHNyYyk7XG4gIGNvbnN0IGJhc2UgPSBhcnR3b3JrLmJhc2U7XG4gIGNvbnN0IHNvdXJjZXMgPSAoZm9ybWF0OiBzdHJpbmcpID0+IGAke2Jhc2V9LTQwMC4ke2Zvcm1hdH0gNDAwdywgJHtiYXNlfS04MDAuJHtmb3JtYXR9IDgwMHdgO1xuICBpZiAoYXJ0d29yay51bmF2YWlsYWJsZSlcbiAgICByZXR1cm4gKFxuICAgICAgPEFydHdvcmtVbmF2YWlsYWJsZSBhbHQ9e2FsdH0gY2xhc3NOYW1lPXtjbGFzc05hbWV9IHRlc3RJZD17dGVzdElkfSBkaW1lbnNpb25zPXtwcm9wc30gLz5cbiAgICApO1xuICByZXR1cm4gKFxuICAgIDxwaWN0dXJlIGNsYXNzTmFtZT1cImNvbnRlbnRzXCI+XG4gICAgICB7YmFzZSAmJiBhcnR3b3JrLmF2aWYgJiYgKFxuICAgICAgICA8c291cmNlIGNsYXNzTmFtZT1cImhpZGRlblwiIHR5cGU9XCJpbWFnZS9hdmlmXCIgc3JjU2V0PXtzb3VyY2VzKCdhdmlmJyl9IHNpemVzPXtzaXplc30gLz5cbiAgICAgICl9XG4gICAgICA8aW1nXG4gICAgICAgIHsuLi5wcm9wc31cbiAgICAgICAgc3JjPXthcnR3b3JrLnNyY31cbiAgICAgICAgYWx0PXthbHR9XG4gICAgICAgIGNsYXNzTmFtZT17Y2xhc3NOYW1lfVxuICAgICAgICBkYXRhLXRlc3RpZD17dGVzdElkfVxuICAgICAgICBvbkVycm9yPXsoZXZlbnQpID0+IHtcbiAgICAgICAgICBhcnR3b3JrLmZhaWwoZXZlbnQuY3VycmVudFRhcmdldC5jdXJyZW50U3JjIHx8IGV2ZW50LmN1cnJlbnRUYXJnZXQuc3JjKTtcbiAgICAgICAgICBvbkVycm9yPy4oZXZlbnQpO1xuICAgICAgICB9fVxuICAgICAgICBsb2FkaW5nPXtsb2FkaW5nfVxuICAgICAgICBzaXplcz17YmFzZSA/IHNpemVzIDogdW5kZWZpbmVkfVxuICAgICAgICBzcmNTZXQ9e2Jhc2UgPyBzb3VyY2VzKCd3ZWJwJykgOiB1bmRlZmluZWR9XG4gICAgICAvPlxuICAgIDwvcGljdHVyZT5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2ZpbGlwZWNhdmFsY2FudGUvRG9jdW1lbnRzL0p1bmdsZUdhbWluZ1Rlc3RlL3NyYy9jb21wb25lbnRzL21lZGlhL0FydHdvcmtJbWFnZS50c3gifQ==