import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/CatalogSortSelect.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
export function CatalogSortSelect({
  value,
  change
}) {
  return /* @__PURE__ */ jsxDEV("label", { className: "flex min-h-11 items-center gap-2 text-sm text-foreground md:min-h-6", children: [
    "Ordenar por",
    /* @__PURE__ */ jsxDEV(
      "select",
      {
        "aria-label": "Ordenar por",
        value,
        onChange: (event) => {
          const sort = event.target.value;
          if (sort === "recent" || sort === "price_asc" || sort === "price_desc" || sort === "rating")
            change(sort);
        },
        className: "min-w-0 flex-1 rounded-md bg-transparent py-2 text-foreground md:py-0",
        children: [
          /* @__PURE__ */ jsxDEV("option", { value: "recent", children: "Listados recentemente" }, void 0, false, {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogSortSelect.tsx",
            lineNumber: 28,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("option", { value: "price_asc", children: "Menor preço" }, void 0, false, {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogSortSelect.tsx",
            lineNumber: 29,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("option", { value: "price_desc", children: "Maior preço" }, void 0, false, {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogSortSelect.tsx",
            lineNumber: 30,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("option", { value: "rating", children: "Melhor avaliação" }, void 0, false, {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogSortSelect.tsx",
            lineNumber: 31,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogSortSelect.tsx",
        lineNumber: 13,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogSortSelect.tsx",
    lineNumber: 11,
    columnNumber: 5
  }, this);
}
_c = CatalogSortSelect;
var _c;
$RefreshReg$(_c, "CatalogSortSelect");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogSortSelect.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogSortSelect.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogSortSelect.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkJRO0FBekJELGdCQUFTQSxrQkFBa0I7QUFBQSxFQUNoQ0M7QUFBQUEsRUFDQUM7QUFJRixHQUFHO0FBQ0QsU0FDRSx1QkFBQyxXQUFNLFdBQVUsdUVBQXFFO0FBQUE7QUFBQSxJQUVwRjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsY0FBVztBQUFBLFFBQ1g7QUFBQSxRQUNBLFVBQVUsQ0FBQ0MsVUFBVTtBQUNuQixnQkFBTUMsT0FBT0QsTUFBTUUsT0FBT0o7QUFDMUIsY0FDRUcsU0FBUyxZQUNUQSxTQUFTLGVBQ1RBLFNBQVMsZ0JBQ1RBLFNBQVM7QUFFVEYsbUJBQU9FLElBQUk7QUFBQSxRQUNmO0FBQUEsUUFDQSxXQUFVO0FBQUEsUUFFVjtBQUFBLGlDQUFDLFlBQU8sT0FBTSxVQUFTLHFDQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QztBQUFBLFVBQzVDLHVCQUFDLFlBQU8sT0FBTSxhQUFZLDJCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxQztBQUFBLFVBQ3JDLHVCQUFDLFlBQU8sT0FBTSxjQUFhLDJCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzQztBQUFBLFVBQ3RDLHVCQUFDLFlBQU8sT0FBTSxVQUFTLGdDQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1QztBQUFBO0FBQUE7QUFBQSxNQWxCekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBbUJBO0FBQUEsT0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNCQTtBQUVKO0FBQUNFLEtBaENlTjtBQUFpQixJQUFBTTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJDYXRhbG9nU29ydFNlbGVjdCIsInZhbHVlIiwiY2hhbmdlIiwiZXZlbnQiLCJzb3J0IiwidGFyZ2V0IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ2F0YWxvZ1NvcnRTZWxlY3QudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgTmZ0U29ydCB9IGZyb20gJ0AvY29udHJhY3RzL25mdCc7XG5cbmV4cG9ydCBmdW5jdGlvbiBDYXRhbG9nU29ydFNlbGVjdCh7XG4gIHZhbHVlLFxuICBjaGFuZ2UsXG59OiB7XG4gIHZhbHVlOiBOZnRTb3J0O1xuICBjaGFuZ2U6ICh2YWx1ZTogTmZ0U29ydCkgPT4gdm9pZDtcbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBtaW4taC0xMSBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbSB0ZXh0LWZvcmVncm91bmQgbWQ6bWluLWgtNlwiPlxuICAgICAgT3JkZW5hciBwb3JcbiAgICAgIDxzZWxlY3RcbiAgICAgICAgYXJpYS1sYWJlbD1cIk9yZGVuYXIgcG9yXCJcbiAgICAgICAgdmFsdWU9e3ZhbHVlfVxuICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiB7XG4gICAgICAgICAgY29uc3Qgc29ydCA9IGV2ZW50LnRhcmdldC52YWx1ZTtcbiAgICAgICAgICBpZiAoXG4gICAgICAgICAgICBzb3J0ID09PSAncmVjZW50JyB8fFxuICAgICAgICAgICAgc29ydCA9PT0gJ3ByaWNlX2FzYycgfHxcbiAgICAgICAgICAgIHNvcnQgPT09ICdwcmljZV9kZXNjJyB8fFxuICAgICAgICAgICAgc29ydCA9PT0gJ3JhdGluZydcbiAgICAgICAgICApXG4gICAgICAgICAgICBjaGFuZ2Uoc29ydCk7XG4gICAgICAgIH19XG4gICAgICAgIGNsYXNzTmFtZT1cIm1pbi13LTAgZmxleC0xIHJvdW5kZWQtbWQgYmctdHJhbnNwYXJlbnQgcHktMiB0ZXh0LWZvcmVncm91bmQgbWQ6cHktMFwiXG4gICAgICA+XG4gICAgICAgIDxvcHRpb24gdmFsdWU9XCJyZWNlbnRcIj5MaXN0YWRvcyByZWNlbnRlbWVudGU8L29wdGlvbj5cbiAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInByaWNlX2FzY1wiPk1lbm9yIHByZcOnbzwvb3B0aW9uPlxuICAgICAgICA8b3B0aW9uIHZhbHVlPVwicHJpY2VfZGVzY1wiPk1haW9yIHByZcOnbzwvb3B0aW9uPlxuICAgICAgICA8b3B0aW9uIHZhbHVlPVwicmF0aW5nXCI+TWVsaG9yIGF2YWxpYcOnw6NvPC9vcHRpb24+XG4gICAgICA8L3NlbGVjdD5cbiAgICA8L2xhYmVsPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvZmlsaXBlY2F2YWxjYW50ZS9Eb2N1bWVudHMvSnVuZ2xlR2FtaW5nVGVzdGUvc3JjL2ZlYXR1cmVzL2NhdGFsb2cvY29tcG9uZW50cy9DYXRhbG9nU29ydFNlbGVjdC50c3gifQ==