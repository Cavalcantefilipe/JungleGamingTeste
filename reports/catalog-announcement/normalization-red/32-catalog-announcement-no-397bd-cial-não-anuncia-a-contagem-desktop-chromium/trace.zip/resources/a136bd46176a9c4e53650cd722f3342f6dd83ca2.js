import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/checkbox.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { CheckIcon } from "/node_modules/.vite/deps/lucide-react.js?v=970a124b";
import { Checkbox as CheckboxPrimitive } from "/node_modules/.vite/deps/radix-ui.js?v=970a124b";
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=970a124b"; const React = ((m) => m?.__esModule ? m : {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m})(__vite__cjsImport3_react);
import { cn } from "/src/lib/cn.ts";
function Checkbox({ className, ...props }) {
  return /* @__PURE__ */ jsxDEV(
    CheckboxPrimitive.Root,
    {
      "data-slot": "checkbox",
      className: cn(
        "peer size-4 shrink-0 rounded-[4px] border border-input shadow-xs transition-shadow outline-none focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-destructive/20 data-[state=checked]:border-primary data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground dark:bg-input/30 dark:aria-invalid:ring-destructive/40 dark:data-[state=checked]:bg-primary",
        className
      ),
      ...props,
      children: /* @__PURE__ */ jsxDEV(
        CheckboxPrimitive.Indicator,
        {
          "data-slot": "checkbox-indicator",
          className: "grid place-content-center text-current transition-none",
          children: /* @__PURE__ */ jsxDEV(CheckIcon, { className: "size-3.5" }, void 0, false, {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/checkbox.tsx",
            lineNumber: 21,
            columnNumber: 9
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/checkbox.tsx",
          lineNumber: 17,
          columnNumber: 7
        },
        this
      )
    },
    void 0,
    false,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/checkbox.tsx",
      lineNumber: 9,
      columnNumber: 5
    },
    this
  );
}
_c = Checkbox;
export { Checkbox };
var _c;
$RefreshReg$(_c, "Checkbox");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/checkbox.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/checkbox.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/checkbox.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JRO0FBcEJSLFNBQVNBLGlCQUFpQjtBQUMxQixTQUFTQyxZQUFZQyx5QkFBeUI7QUFDOUMsWUFBWUMsV0FBVztBQUV2QixTQUFTQyxVQUFVO0FBRW5CLFNBQVNILFNBQVMsRUFBRUksV0FBVyxHQUFHQyxNQUEyRCxHQUFHO0FBQzlGLFNBQ0U7QUFBQSxJQUFDLGtCQUFrQjtBQUFBLElBQWxCO0FBQUEsTUFDQyxhQUFVO0FBQUEsTUFDVixXQUFXRjtBQUFBQSxRQUNUO0FBQUEsUUFDQUM7QUFBQUEsTUFDRjtBQUFBLE1BQ0EsR0FBSUM7QUFBQUEsTUFFSjtBQUFBLFFBQUMsa0JBQWtCO0FBQUEsUUFBbEI7QUFBQSxVQUNDLGFBQVU7QUFBQSxVQUNWLFdBQVU7QUFBQSxVQUVWLGlDQUFDLGFBQVUsV0FBVSxjQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErQjtBQUFBO0FBQUEsUUFKakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS0E7QUFBQTtBQUFBLElBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBY0E7QUFFSjtBQUFDQyxLQWxCUU47QUFvQlQsU0FBU0E7QUFBVyxJQUFBTTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJDaGVja0ljb24iLCJDaGVja2JveCIsIkNoZWNrYm94UHJpbWl0aXZlIiwiUmVhY3QiLCJjbiIsImNsYXNzTmFtZSIsInByb3BzIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiY2hlY2tib3gudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENoZWNrSWNvbiB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBDaGVja2JveCBhcyBDaGVja2JveFByaW1pdGl2ZSB9IGZyb20gJ3JhZGl4LXVpJztcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcblxuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi9jbic7XG5cbmZ1bmN0aW9uIENoZWNrYm94KHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9OiBSZWFjdC5Db21wb25lbnRQcm9wczx0eXBlb2YgQ2hlY2tib3hQcmltaXRpdmUuUm9vdD4pIHtcbiAgcmV0dXJuIChcbiAgICA8Q2hlY2tib3hQcmltaXRpdmUuUm9vdFxuICAgICAgZGF0YS1zbG90PVwiY2hlY2tib3hcIlxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgJ3BlZXIgc2l6ZS00IHNocmluay0wIHJvdW5kZWQtWzRweF0gYm9yZGVyIGJvcmRlci1pbnB1dCBzaGFkb3cteHMgdHJhbnNpdGlvbi1zaGFkb3cgb3V0bGluZS1ub25lIGZvY3VzLXZpc2libGU6Ym9yZGVyLXJpbmcgZm9jdXMtdmlzaWJsZTpyaW5nLVszcHhdIGZvY3VzLXZpc2libGU6cmluZy1yaW5nLzUwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCBkaXNhYmxlZDpvcGFjaXR5LTUwIGFyaWEtaW52YWxpZDpib3JkZXItZGVzdHJ1Y3RpdmUgYXJpYS1pbnZhbGlkOnJpbmctZGVzdHJ1Y3RpdmUvMjAgZGF0YS1bc3RhdGU9Y2hlY2tlZF06Ym9yZGVyLXByaW1hcnkgZGF0YS1bc3RhdGU9Y2hlY2tlZF06YmctcHJpbWFyeSBkYXRhLVtzdGF0ZT1jaGVja2VkXTp0ZXh0LXByaW1hcnktZm9yZWdyb3VuZCBkYXJrOmJnLWlucHV0LzMwIGRhcms6YXJpYS1pbnZhbGlkOnJpbmctZGVzdHJ1Y3RpdmUvNDAgZGFyazpkYXRhLVtzdGF0ZT1jaGVja2VkXTpiZy1wcmltYXJ5JyxcbiAgICAgICAgY2xhc3NOYW1lLFxuICAgICAgKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICA8Q2hlY2tib3hQcmltaXRpdmUuSW5kaWNhdG9yXG4gICAgICAgIGRhdGEtc2xvdD1cImNoZWNrYm94LWluZGljYXRvclwiXG4gICAgICAgIGNsYXNzTmFtZT1cImdyaWQgcGxhY2UtY29udGVudC1jZW50ZXIgdGV4dC1jdXJyZW50IHRyYW5zaXRpb24tbm9uZVwiXG4gICAgICA+XG4gICAgICAgIDxDaGVja0ljb24gY2xhc3NOYW1lPVwic2l6ZS0zLjVcIiAvPlxuICAgICAgPC9DaGVja2JveFByaW1pdGl2ZS5JbmRpY2F0b3I+XG4gICAgPC9DaGVja2JveFByaW1pdGl2ZS5Sb290PlxuICApO1xufVxuXG5leHBvcnQgeyBDaGVja2JveCB9O1xuIl0sImZpbGUiOiIvVXNlcnMvZmlsaXBlY2F2YWxjYW50ZS9Eb2N1bWVudHMvSnVuZ2xlR2FtaW5nVGVzdGUvc3JjL2NvbXBvbmVudHMvdWkvY2hlY2tib3gudHN4In0=