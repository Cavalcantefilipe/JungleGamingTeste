import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/MobileCatalogSearch.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { FigmaIcon } from "/src/components/icons/FigmaIcon.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { FilterDrawer } from "/src/features/catalog/components/FilterDrawer.tsx";
export function MobileCatalogSearch({ search, facets, apply, clear }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "mb-4 flex items-center gap-2 md:hidden", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "relative min-w-0 flex-1", children: [
      /* @__PURE__ */ jsxDEV(
        FigmaIcon,
        {
          name: "search-curved",
          "aria-hidden": "true",
          size: 20,
          className: "pointer-events-none absolute top-3 left-3 text-secondary"
        },
        void 0,
        false,
        {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/MobileCatalogSearch.tsx",
          lineNumber: 10,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Input,
        {
          type: "search",
          "aria-label": "Buscar NFTs",
          placeholder: "Explorar coleções",
          value: search.q,
          onChange: (event) => {
            apply({ q: event.target.value });
          },
          className: "h-[45px] rounded-auth border-transparent bg-surface-card pl-[42px] text-sm placeholder:font-bold"
        },
        void 0,
        false,
        {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/MobileCatalogSearch.tsx",
          lineNumber: 16,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/MobileCatalogSearch.tsx",
      lineNumber: 9,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      FilterDrawer,
      {
        compact: true,
        search,
        ...facets ? { facets } : {},
        apply,
        clear
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/MobileCatalogSearch.tsx",
        lineNumber: 27,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/MobileCatalogSearch.tsx",
    lineNumber: 8,
    columnNumber: 5
  }, this);
}
_c = MobileCatalogSearch;
var _c;
$RefreshReg$(_c, "MobileCatalogSearch");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/MobileCatalogSearch.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/MobileCatalogSearch.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/MobileCatalogSearch.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU1E7QUFUUixTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxvQkFBb0I7QUFHdEIsZ0JBQVNDLG9CQUFvQixFQUFFQyxRQUFRQyxRQUFRQyxPQUFPQyxNQUFtQixHQUFHO0FBQ2pGLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLGVBQVk7QUFBQSxVQUNaLE1BQU07QUFBQSxVQUNOLFdBQVU7QUFBQTtBQUFBLFFBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSXNFO0FBQUEsTUFFdEU7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLGNBQVc7QUFBQSxVQUNYLGFBQVk7QUFBQSxVQUNaLE9BQU9ILE9BQU9JO0FBQUFBLFVBQ2QsVUFBVSxDQUFDQyxVQUFVO0FBQ25CSCxrQkFBTSxFQUFFRSxHQUFHQyxNQUFNQyxPQUFPQyxNQUFNLENBQUM7QUFBQSxVQUNqQztBQUFBLFVBQ0EsV0FBVTtBQUFBO0FBQUEsUUFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFROEc7QUFBQSxTQWZoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUJBO0FBQUEsSUFDQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBO0FBQUEsUUFDQSxHQUFLTixTQUFTLEVBQUVBLE9BQU8sSUFBSSxDQUFDO0FBQUEsUUFDNUI7QUFBQSxRQUNBO0FBQUE7QUFBQSxNQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUtlO0FBQUEsT0F4QmpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwQkE7QUFFSjtBQUFDTyxLQTlCZVQ7QUFBbUIsSUFBQVM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiRmlnbWFJY29uIiwiSW5wdXQiLCJGaWx0ZXJEcmF3ZXIiLCJNb2JpbGVDYXRhbG9nU2VhcmNoIiwic2VhcmNoIiwiZmFjZXRzIiwiYXBwbHkiLCJjbGVhciIsInEiLCJldmVudCIsInRhcmdldCIsInZhbHVlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTW9iaWxlQ2F0YWxvZ1NlYXJjaC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRmlnbWFJY29uIH0gZnJvbSAnQC9jb21wb25lbnRzL2ljb25zL0ZpZ21hSWNvbic7XG5pbXBvcnQgeyBJbnB1dCB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9pbnB1dCc7XG5pbXBvcnQgeyBGaWx0ZXJEcmF3ZXIgfSBmcm9tICdAL2ZlYXR1cmVzL2NhdGFsb2cvY29tcG9uZW50cy9GaWx0ZXJEcmF3ZXInO1xuaW1wb3J0IHR5cGUgeyBGaWx0ZXJQcm9wcyB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy9maWx0ZXItcHJvcHMnO1xuXG5leHBvcnQgZnVuY3Rpb24gTW9iaWxlQ2F0YWxvZ1NlYXJjaCh7IHNlYXJjaCwgZmFjZXRzLCBhcHBseSwgY2xlYXIgfTogRmlsdGVyUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWQ6aGlkZGVuXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIG1pbi13LTAgZmxleC0xXCI+XG4gICAgICAgIDxGaWdtYUljb25cbiAgICAgICAgICBuYW1lPVwic2VhcmNoLWN1cnZlZFwiXG4gICAgICAgICAgYXJpYS1oaWRkZW49XCJ0cnVlXCJcbiAgICAgICAgICBzaXplPXsyMH1cbiAgICAgICAgICBjbGFzc05hbWU9XCJwb2ludGVyLWV2ZW50cy1ub25lIGFic29sdXRlIHRvcC0zIGxlZnQtMyB0ZXh0LXNlY29uZGFyeVwiXG4gICAgICAgIC8+XG4gICAgICAgIDxJbnB1dFxuICAgICAgICAgIHR5cGU9XCJzZWFyY2hcIlxuICAgICAgICAgIGFyaWEtbGFiZWw9XCJCdXNjYXIgTkZUc1wiXG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJFeHBsb3JhciBjb2xlw6fDtWVzXCJcbiAgICAgICAgICB2YWx1ZT17c2VhcmNoLnF9XG4gICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4ge1xuICAgICAgICAgICAgYXBwbHkoeyBxOiBldmVudC50YXJnZXQudmFsdWUgfSk7XG4gICAgICAgICAgfX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJoLVs0NXB4XSByb3VuZGVkLWF1dGggYm9yZGVyLXRyYW5zcGFyZW50IGJnLXN1cmZhY2UtY2FyZCBwbC1bNDJweF0gdGV4dC1zbSBwbGFjZWhvbGRlcjpmb250LWJvbGRcIlxuICAgICAgICAvPlxuICAgICAgPC9kaXY+XG4gICAgICA8RmlsdGVyRHJhd2VyXG4gICAgICAgIGNvbXBhY3RcbiAgICAgICAgc2VhcmNoPXtzZWFyY2h9XG4gICAgICAgIHsuLi4oZmFjZXRzID8geyBmYWNldHMgfSA6IHt9KX1cbiAgICAgICAgYXBwbHk9e2FwcGx5fVxuICAgICAgICBjbGVhcj17Y2xlYXJ9XG4gICAgICAvPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvZmlsaXBlY2F2YWxjYW50ZS9Eb2N1bWVudHMvSnVuZ2xlR2FtaW5nVGVzdGUvc3JjL2ZlYXR1cmVzL2NhdGFsb2cvY29tcG9uZW50cy9Nb2JpbGVDYXRhbG9nU2VhcmNoLnRzeCJ9