import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/NftCardMedia.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { ArtworkImage } from "/src/components/media/ArtworkImage.tsx";
export function NftCardMedia({ nft, priority }) {
  const image = nft.images[0];
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      "data-testid": "nft-card-media",
      className: "relative flex aspect-[174/200] items-center justify-center overflow-hidden rounded-[20px] bg-surface-gradient px-1 lg:aspect-[258/300] lg:rounded-none lg:bg-surface-card lg:bg-none",
      children: [
        /* @__PURE__ */ jsxDEV(
          ArtworkImage,
          {
            sizes: "(min-width: 1440px) 250px, (min-width: 1024px) 25vw, 50vw",
            src: image?.src,
            alt: image?.alt ?? nft.name,
            width: 600,
            height: 600,
            loading: priority ? "eager" : "lazy",
            className: "aspect-square w-full rounded-[15px] object-cover"
          },
          void 0,
          false,
          {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCardMedia.tsx",
            lineNumber: 11,
            columnNumber: 7
          },
          this
        ),
        nft.rarity && /* @__PURE__ */ jsxDEV("span", { className: "absolute top-4 left-0 flex h-8 w-[68px] items-center bg-primary px-2 text-caption font-medium text-ink lg:w-20 lg:text-sm", children: "RARO" }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCardMedia.tsx",
          lineNumber: 21,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCardMedia.tsx",
      lineNumber: 7,
      columnNumber: 5
    },
    this
  );
}
_c = NftCardMedia;
var _c;
$RefreshReg$(_c, "NftCardMedia");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCardMedia.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCardMedia.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftCardMedia.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVU07QUFWTixTQUFTQSxvQkFBb0I7QUFHdEIsZ0JBQVNDLGFBQWEsRUFBRUMsS0FBS0MsU0FBMEMsR0FBRztBQUMvRSxRQUFNQyxRQUFRRixJQUFJRyxPQUFPLENBQUM7QUFDMUIsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsZUFBWTtBQUFBLE1BQ1osV0FBVTtBQUFBLE1BRVY7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sS0FBS0QsT0FBT0U7QUFBQUEsWUFDWixLQUFLRixPQUFPRyxPQUFPTCxJQUFJTTtBQUFBQSxZQUN2QixPQUFPO0FBQUEsWUFDUCxRQUFRO0FBQUEsWUFDUixTQUFTTCxXQUFXLFVBQVU7QUFBQSxZQUM5QixXQUFVO0FBQUE7QUFBQSxVQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU84RDtBQUFBLFFBRTdERCxJQUFJTyxVQUNILHVCQUFDLFVBQUssV0FBVSw2SEFBMkgsb0JBQTNJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBO0FBQUE7QUFBQSxJQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFrQkE7QUFFSjtBQUFDQyxLQXZCZVQ7QUFBWSxJQUFBUztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJBcnR3b3JrSW1hZ2UiLCJOZnRDYXJkTWVkaWEiLCJuZnQiLCJwcmlvcml0eSIsImltYWdlIiwiaW1hZ2VzIiwic3JjIiwiYWx0IiwibmFtZSIsInJhcml0eSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk5mdENhcmRNZWRpYS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQXJ0d29ya0ltYWdlIH0gZnJvbSAnQC9jb21wb25lbnRzL21lZGlhL0FydHdvcmtJbWFnZSc7XG5pbXBvcnQgdHlwZSB7IE5mdCB9IGZyb20gJ0AvY29udHJhY3RzL25mdCc7XG5cbmV4cG9ydCBmdW5jdGlvbiBOZnRDYXJkTWVkaWEoeyBuZnQsIHByaW9yaXR5IH06IHsgbmZ0OiBOZnQ7IHByaW9yaXR5OiBib29sZWFuIH0pIHtcbiAgY29uc3QgaW1hZ2UgPSBuZnQuaW1hZ2VzWzBdO1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGRhdGEtdGVzdGlkPVwibmZ0LWNhcmQtbWVkaWFcIlxuICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleCBhc3BlY3QtWzE3NC8yMDBdIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1bMjBweF0gYmctc3VyZmFjZS1ncmFkaWVudCBweC0xIGxnOmFzcGVjdC1bMjU4LzMwMF0gbGc6cm91bmRlZC1ub25lIGxnOmJnLXN1cmZhY2UtY2FyZCBsZzpiZy1ub25lXCJcbiAgICA+XG4gICAgICA8QXJ0d29ya0ltYWdlXG4gICAgICAgIHNpemVzPVwiKG1pbi13aWR0aDogMTQ0MHB4KSAyNTBweCwgKG1pbi13aWR0aDogMTAyNHB4KSAyNXZ3LCA1MHZ3XCJcbiAgICAgICAgc3JjPXtpbWFnZT8uc3JjfVxuICAgICAgICBhbHQ9e2ltYWdlPy5hbHQgPz8gbmZ0Lm5hbWV9XG4gICAgICAgIHdpZHRoPXs2MDB9XG4gICAgICAgIGhlaWdodD17NjAwfVxuICAgICAgICBsb2FkaW5nPXtwcmlvcml0eSA/ICdlYWdlcicgOiAnbGF6eSd9XG4gICAgICAgIGNsYXNzTmFtZT1cImFzcGVjdC1zcXVhcmUgdy1mdWxsIHJvdW5kZWQtWzE1cHhdIG9iamVjdC1jb3ZlclwiXG4gICAgICAvPlxuICAgICAge25mdC5yYXJpdHkgJiYgKFxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtNCBsZWZ0LTAgZmxleCBoLTggdy1bNjhweF0gaXRlbXMtY2VudGVyIGJnLXByaW1hcnkgcHgtMiB0ZXh0LWNhcHRpb24gZm9udC1tZWRpdW0gdGV4dC1pbmsgbGc6dy0yMCBsZzp0ZXh0LXNtXCI+XG4gICAgICAgICAgUkFST1xuICAgICAgICA8L3NwYW4+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvZmlsaXBlY2F2YWxjYW50ZS9Eb2N1bWVudHMvSnVuZ2xlR2FtaW5nVGVzdGUvc3JjL2ZlYXR1cmVzL2NhdGFsb2cvY29tcG9uZW50cy9OZnRDYXJkTWVkaWEudHN4In0=