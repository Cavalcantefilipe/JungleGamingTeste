import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/EditorialArticleCard.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { toast } from "/node_modules/.vite/deps/sonner.js?v=970a124b";
import { FigmaIcon } from "/src/components/icons/FigmaIcon.tsx";
import { ArtworkImage } from "/src/components/media/ArtworkImage.tsx";
export function EditorialArticleCard({ article }) {
  return /* @__PURE__ */ jsxDEV("article", { className: "overflow-hidden rounded-lg bg-surface-card", children: [
    /* @__PURE__ */ jsxDEV(
      ArtworkImage,
      {
        sizes: "(min-width: 1280px) 268px, (min-width: 640px) 50vw, calc(100vw - 48px)",
        src: article.image.src,
        alt: article.image.alt,
        width: 268,
        height: 195,
        loading: "lazy",
        className: "aspect-[268/195] w-full object-cover"
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialArticleCard.tsx",
        lineNumber: 10,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "space-y-3 p-4", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs leading-4 font-medium text-text-secondary", children: [
        article.dateLabel,
        " | ",
        article.readingLabel
      ] }, void 0, true, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialArticleCard.tsx",
        lineNumber: 20,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("h3", { className: "text-base leading-[21px] font-bold", children: article.title }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialArticleCard.tsx",
        lineNumber: 23,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs leading-4 font-medium text-text-secondary", children: article.description }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialArticleCard.tsx",
        lineNumber: 24,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          className: "flex min-h-11 cursor-pointer items-center gap-2 text-xs font-bold text-text-accent hover:text-primary-light active:text-primary-dark md:min-h-4",
          onClick: () => toast.info("Conteúdo indisponível nesta demonstração"),
          children: [
            "Ler mais ",
            /* @__PURE__ */ jsxDEV(FigmaIcon, { name: "arrow-right", "aria-hidden": "true", size: 14 }, void 0, false, {
              fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialArticleCard.tsx",
              lineNumber: 29,
              columnNumber: 20
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialArticleCard.tsx",
          lineNumber: 25,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialArticleCard.tsx",
      lineNumber: 19,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialArticleCard.tsx",
    lineNumber: 9,
    columnNumber: 5
  }, this);
}
_c = EditorialArticleCard;
var _c;
$RefreshReg$(_c, "EditorialArticleCard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialArticleCard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialArticleCard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialArticleCard.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU007QUFUTixTQUFTQSxhQUFhO0FBRXRCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxvQkFBb0I7QUFHdEIsZ0JBQVNDLHFCQUFxQixFQUFFQyxRQUFrRCxHQUFHO0FBQzFGLFNBQ0UsdUJBQUMsYUFBUSxXQUFVLDhDQUNqQjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUFNO0FBQUEsUUFDTixLQUFLQSxRQUFRQyxNQUFNQztBQUFBQSxRQUNuQixLQUFLRixRQUFRQyxNQUFNRTtBQUFBQSxRQUNuQixPQUFPO0FBQUEsUUFDUCxRQUFRO0FBQUEsUUFDUixTQUFRO0FBQUEsUUFDUixXQUFVO0FBQUE7QUFBQSxNQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU9rRDtBQUFBLElBRWxELHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLDZCQUFDLE9BQUUsV0FBVSxxREFDVkg7QUFBQUEsZ0JBQVFJO0FBQUFBLFFBQVU7QUFBQSxRQUFJSixRQUFRSztBQUFBQSxXQURqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFFBQUcsV0FBVSxzQ0FBc0NMLGtCQUFRTSxTQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtFO0FBQUEsTUFDbEUsdUJBQUMsT0FBRSxXQUFVLHFEQUFxRE4sa0JBQVFPLGVBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0Y7QUFBQSxNQUN0RjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVTtBQUFBLFVBQ1YsU0FBUyxNQUFNWCxNQUFNWSxLQUFLLDBDQUEwQztBQUFBLFVBQUU7QUFBQTtBQUFBLFlBRTdELHVCQUFDLGFBQVUsTUFBSyxlQUFjLGVBQVksUUFBTyxNQUFNLE1BQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBEO0FBQUE7QUFBQTtBQUFBLFFBSnJFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtBO0FBQUEsU0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxPQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUJBO0FBRUo7QUFBQ0MsS0EzQmVWO0FBQW9CLElBQUFVO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInRvYXN0IiwiRmlnbWFJY29uIiwiQXJ0d29ya0ltYWdlIiwiRWRpdG9yaWFsQXJ0aWNsZUNhcmQiLCJhcnRpY2xlIiwiaW1hZ2UiLCJzcmMiLCJhbHQiLCJkYXRlTGFiZWwiLCJyZWFkaW5nTGFiZWwiLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwiaW5mbyIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkVkaXRvcmlhbEFydGljbGVDYXJkLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3Nvbm5lcic7XG5cbmltcG9ydCB7IEZpZ21hSWNvbiB9IGZyb20gJ0AvY29tcG9uZW50cy9pY29ucy9GaWdtYUljb24nO1xuaW1wb3J0IHsgQXJ0d29ya0ltYWdlIH0gZnJvbSAnQC9jb21wb25lbnRzL21lZGlhL0FydHdvcmtJbWFnZSc7XG5pbXBvcnQgdHlwZSB7IENvbnRlbnQgfSBmcm9tICdAL2NvbnRyYWN0cy9jb250ZW50JztcblxuZXhwb3J0IGZ1bmN0aW9uIEVkaXRvcmlhbEFydGljbGVDYXJkKHsgYXJ0aWNsZSB9OiB7IGFydGljbGU6IENvbnRlbnRbJ2FydGljbGVzJ11bbnVtYmVyXSB9KSB7XG4gIHJldHVybiAoXG4gICAgPGFydGljbGUgY2xhc3NOYW1lPVwib3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtbGcgYmctc3VyZmFjZS1jYXJkXCI+XG4gICAgICA8QXJ0d29ya0ltYWdlXG4gICAgICAgIHNpemVzPVwiKG1pbi13aWR0aDogMTI4MHB4KSAyNjhweCwgKG1pbi13aWR0aDogNjQwcHgpIDUwdncsIGNhbGMoMTAwdncgLSA0OHB4KVwiXG4gICAgICAgIHNyYz17YXJ0aWNsZS5pbWFnZS5zcmN9XG4gICAgICAgIGFsdD17YXJ0aWNsZS5pbWFnZS5hbHR9XG4gICAgICAgIHdpZHRoPXsyNjh9XG4gICAgICAgIGhlaWdodD17MTk1fVxuICAgICAgICBsb2FkaW5nPVwibGF6eVwiXG4gICAgICAgIGNsYXNzTmFtZT1cImFzcGVjdC1bMjY4LzE5NV0gdy1mdWxsIG9iamVjdC1jb3ZlclwiXG4gICAgICAvPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTMgcC00XCI+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgbGVhZGluZy00IGZvbnQtbWVkaXVtIHRleHQtdGV4dC1zZWNvbmRhcnlcIj5cbiAgICAgICAgICB7YXJ0aWNsZS5kYXRlTGFiZWx9IHwge2FydGljbGUucmVhZGluZ0xhYmVsfVxuICAgICAgICA8L3A+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgbGVhZGluZy1bMjFweF0gZm9udC1ib2xkXCI+e2FydGljbGUudGl0bGV9PC9oMz5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBsZWFkaW5nLTQgZm9udC1tZWRpdW0gdGV4dC10ZXh0LXNlY29uZGFyeVwiPnthcnRpY2xlLmRlc2NyaXB0aW9ufTwvcD5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggbWluLWgtMTEgY3Vyc29yLXBvaW50ZXIgaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgZm9udC1ib2xkIHRleHQtdGV4dC1hY2NlbnQgaG92ZXI6dGV4dC1wcmltYXJ5LWxpZ2h0IGFjdGl2ZTp0ZXh0LXByaW1hcnktZGFyayBtZDptaW4taC00XCJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB0b2FzdC5pbmZvKCdDb250ZcO6ZG8gaW5kaXNwb27DrXZlbCBuZXN0YSBkZW1vbnN0cmHDp8OjbycpfVxuICAgICAgICA+XG4gICAgICAgICAgTGVyIG1haXMgPEZpZ21hSWNvbiBuYW1lPVwiYXJyb3ctcmlnaHRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiBzaXplPXsxNH0gLz5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2FydGljbGU+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9maWxpcGVjYXZhbGNhbnRlL0RvY3VtZW50cy9KdW5nbGVHYW1pbmdUZXN0ZS9zcmMvZmVhdHVyZXMvY2F0YWxvZy9jb21wb25lbnRzL0VkaXRvcmlhbEFydGljbGVDYXJkLnRzeCJ9