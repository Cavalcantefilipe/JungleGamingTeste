import { realtimeResourceKey } from "/src/contracts/realtime.ts";
const MAX_EVENT_IDS = 500;
export function createEventGate() {
  const ids = /* @__PURE__ */ new Set();
  const versions = /* @__PURE__ */ new Map();
  const syncVersion = (resource, version) => {
    versions.set(resource, Math.max(versions.get(resource) ?? -1, version));
  };
  return {
    syncVersion,
    shouldApply(event) {
      if (ids.has(event.id)) return false;
      ids.add(event.id);
      if (ids.size > MAX_EVENT_IDS) {
        const oldest = ids.values().next().value;
        if (oldest) ids.delete(oldest);
      }
      const resource = realtimeResourceKey(event);
      if ((versions.get(resource) ?? -1) >= event.version) return false;
      syncVersion(resource, event.version);
      return true;
    }
  };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImV2ZW50LWdhdGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgcmVhbHRpbWVSZXNvdXJjZUtleSwgdHlwZSBSZWFsdGltZUV2ZW50IH0gZnJvbSAnQC9jb250cmFjdHMvcmVhbHRpbWUnO1xuXG5jb25zdCBNQVhfRVZFTlRfSURTID0gNTAwO1xuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUV2ZW50R2F0ZSgpIHtcbiAgY29uc3QgaWRzID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGNvbnN0IHZlcnNpb25zID0gbmV3IE1hcDxzdHJpbmcsIG51bWJlcj4oKTtcbiAgY29uc3Qgc3luY1ZlcnNpb24gPSAocmVzb3VyY2U6IHN0cmluZywgdmVyc2lvbjogbnVtYmVyKSA9PiB7XG4gICAgdmVyc2lvbnMuc2V0KHJlc291cmNlLCBNYXRoLm1heCh2ZXJzaW9ucy5nZXQocmVzb3VyY2UpID8/IC0xLCB2ZXJzaW9uKSk7XG4gIH07XG4gIHJldHVybiB7XG4gICAgc3luY1ZlcnNpb24sXG4gICAgc2hvdWxkQXBwbHkoZXZlbnQ6IFJlYWx0aW1lRXZlbnQpOiBib29sZWFuIHtcbiAgICAgIGlmIChpZHMuaGFzKGV2ZW50LmlkKSkgcmV0dXJuIGZhbHNlO1xuICAgICAgaWRzLmFkZChldmVudC5pZCk7XG4gICAgICBpZiAoaWRzLnNpemUgPiBNQVhfRVZFTlRfSURTKSB7XG4gICAgICAgIGNvbnN0IG9sZGVzdCA9IGlkcy52YWx1ZXMoKS5uZXh0KCkudmFsdWU7XG4gICAgICAgIGlmIChvbGRlc3QpIGlkcy5kZWxldGUob2xkZXN0KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHJlc291cmNlID0gcmVhbHRpbWVSZXNvdXJjZUtleShldmVudCk7XG4gICAgICBpZiAoKHZlcnNpb25zLmdldChyZXNvdXJjZSkgPz8gLTEpID49IGV2ZW50LnZlcnNpb24pIHJldHVybiBmYWxzZTtcbiAgICAgIHN5bmNWZXJzaW9uKHJlc291cmNlLCBldmVudC52ZXJzaW9uKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0sXG4gIH07XG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsMkJBQStDO0FBRXhELE1BQU0sZ0JBQWdCO0FBQ2YsZ0JBQVMsa0JBQWtCO0FBQ2hDLFFBQU0sTUFBTSxvQkFBSSxJQUFZO0FBQzVCLFFBQU0sV0FBVyxvQkFBSSxJQUFvQjtBQUN6QyxRQUFNLGNBQWMsQ0FBQyxVQUFrQixZQUFvQjtBQUN6RCxhQUFTLElBQUksVUFBVSxLQUFLLElBQUksU0FBUyxJQUFJLFFBQVEsS0FBSyxJQUFJLE9BQU8sQ0FBQztBQUFBLEVBQ3hFO0FBQ0EsU0FBTztBQUFBLElBQ0w7QUFBQSxJQUNBLFlBQVksT0FBK0I7QUFDekMsVUFBSSxJQUFJLElBQUksTUFBTSxFQUFFLEVBQUcsUUFBTztBQUM5QixVQUFJLElBQUksTUFBTSxFQUFFO0FBQ2hCLFVBQUksSUFBSSxPQUFPLGVBQWU7QUFDNUIsY0FBTSxTQUFTLElBQUksT0FBTyxFQUFFLEtBQUssRUFBRTtBQUNuQyxZQUFJLE9BQVEsS0FBSSxPQUFPLE1BQU07QUFBQSxNQUMvQjtBQUNBLFlBQU0sV0FBVyxvQkFBb0IsS0FBSztBQUMxQyxXQUFLLFNBQVMsSUFBSSxRQUFRLEtBQUssT0FBTyxNQUFNLFFBQVMsUUFBTztBQUM1RCxrQkFBWSxVQUFVLE1BQU0sT0FBTztBQUNuQyxhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFDRjsiLCJuYW1lcyI6W119