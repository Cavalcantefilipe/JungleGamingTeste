import { useRouter } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=970a124b";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=970a124b"; const useEffect = __vite__cjsImport1_react["useEffect"]; const useState = __vite__cjsImport1_react["useState"];
export function useCatalogAnnouncement() {
  const router = useRouter();
  const [announcement, setAnnouncement] = useState({ enabled: false, navigating: false });
  useEffect(() => {
    const stopBeforeNavigate = router.subscribe("onBeforeNavigate", (event) => {
      if (event.fromLocation?.pathname === "/" && event.toLocation.pathname === "/" && event.fromLocation.searchStr !== event.toLocation.searchStr)
        setAnnouncement({ enabled: true, navigating: true });
    });
    const stopResolved = router.subscribe("onResolved", () => {
      setAnnouncement(
        (current) => current.navigating ? { ...current, navigating: false } : current
      );
    });
    return () => {
      stopBeforeNavigate();
      stopResolved();
    };
  }, [router]);
  return announcement;
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZUNhdGFsb2dBbm5vdW5jZW1lbnQudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcic7XG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuXG5leHBvcnQgZnVuY3Rpb24gdXNlQ2F0YWxvZ0Fubm91bmNlbWVudCgpIHtcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG4gIGNvbnN0IFthbm5vdW5jZW1lbnQsIHNldEFubm91bmNlbWVudF0gPSB1c2VTdGF0ZSh7IGVuYWJsZWQ6IGZhbHNlLCBuYXZpZ2F0aW5nOiBmYWxzZSB9KTtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBzdG9wQmVmb3JlTmF2aWdhdGUgPSByb3V0ZXIuc3Vic2NyaWJlKCdvbkJlZm9yZU5hdmlnYXRlJywgKGV2ZW50KSA9PiB7XG4gICAgICBpZiAoXG4gICAgICAgIGV2ZW50LmZyb21Mb2NhdGlvbj8ucGF0aG5hbWUgPT09ICcvJyAmJlxuICAgICAgICBldmVudC50b0xvY2F0aW9uLnBhdGhuYW1lID09PSAnLycgJiZcbiAgICAgICAgZXZlbnQuZnJvbUxvY2F0aW9uLnNlYXJjaFN0ciAhPT0gZXZlbnQudG9Mb2NhdGlvbi5zZWFyY2hTdHJcbiAgICAgIClcbiAgICAgICAgc2V0QW5ub3VuY2VtZW50KHsgZW5hYmxlZDogdHJ1ZSwgbmF2aWdhdGluZzogdHJ1ZSB9KTtcbiAgICB9KTtcbiAgICBjb25zdCBzdG9wUmVzb2x2ZWQgPSByb3V0ZXIuc3Vic2NyaWJlKCdvblJlc29sdmVkJywgKCkgPT4ge1xuICAgICAgc2V0QW5ub3VuY2VtZW50KChjdXJyZW50KSA9PlxuICAgICAgICBjdXJyZW50Lm5hdmlnYXRpbmcgPyB7IC4uLmN1cnJlbnQsIG5hdmlnYXRpbmc6IGZhbHNlIH0gOiBjdXJyZW50LFxuICAgICAgKTtcbiAgICB9KTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgc3RvcEJlZm9yZU5hdmlnYXRlKCk7XG4gICAgICBzdG9wUmVzb2x2ZWQoKTtcbiAgICB9O1xuICB9LCBbcm91dGVyXSk7XG4gIHJldHVybiBhbm5vdW5jZW1lbnQ7XG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsaUJBQWlCO0FBQzFCLFNBQVMsV0FBVyxnQkFBZ0I7QUFFN0IsZ0JBQVMseUJBQXlCO0FBQ3ZDLFFBQU0sU0FBUyxVQUFVO0FBQ3pCLFFBQU0sQ0FBQyxjQUFjLGVBQWUsSUFBSSxTQUFTLEVBQUUsU0FBUyxPQUFPLFlBQVksTUFBTSxDQUFDO0FBQ3RGLFlBQVUsTUFBTTtBQUNkLFVBQU0scUJBQXFCLE9BQU8sVUFBVSxvQkFBb0IsQ0FBQyxVQUFVO0FBQ3pFLFVBQ0UsTUFBTSxjQUFjLGFBQWEsT0FDakMsTUFBTSxXQUFXLGFBQWEsT0FDOUIsTUFBTSxhQUFhLGNBQWMsTUFBTSxXQUFXO0FBRWxELHdCQUFnQixFQUFFLFNBQVMsTUFBTSxZQUFZLEtBQUssQ0FBQztBQUFBLElBQ3ZELENBQUM7QUFDRCxVQUFNLGVBQWUsT0FBTyxVQUFVLGNBQWMsTUFBTTtBQUN4RDtBQUFBLFFBQWdCLENBQUMsWUFDZixRQUFRLGFBQWEsRUFBRSxHQUFHLFNBQVMsWUFBWSxNQUFNLElBQUk7QUFBQSxNQUMzRDtBQUFBLElBQ0YsQ0FBQztBQUNELFdBQU8sTUFBTTtBQUNYLHlCQUFtQjtBQUNuQixtQkFBYTtBQUFBLElBQ2Y7QUFBQSxFQUNGLEdBQUcsQ0FBQyxNQUFNLENBQUM7QUFDWCxTQUFPO0FBQ1Q7IiwibmFtZXMiOltdfQ==