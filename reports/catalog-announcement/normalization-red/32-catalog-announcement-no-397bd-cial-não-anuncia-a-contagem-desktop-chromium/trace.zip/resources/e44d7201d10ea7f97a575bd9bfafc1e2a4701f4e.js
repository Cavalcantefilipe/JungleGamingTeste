import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/EditorialContent.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { EditorialArticleCard } from "/src/features/catalog/components/EditorialArticleCard.tsx";
import { PromotionCard } from "/src/features/catalog/components/PromotionCard.tsx";
export function EditorialContent({ content }) {
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("section", { "aria-label": "Explore as coleções", className: "mt-24 grid gap-7 md:grid-cols-2", children: content.promotions.map(
      (promotion) => /* @__PURE__ */ jsxDEV(PromotionCard, { promotion }, promotion.title, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialContent.tsx",
        lineNumber: 10,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialContent.tsx",
      lineNumber: 8,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "mt-24", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-10 space-y-3 text-center", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-heading font-bold", children: "Diário da Cunhagem" }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialContent.tsx",
          lineNumber: 15,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-text-secondary", children: "Histórias, guias e insights para colecionadores sobre o universo da propriedade digital." }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialContent.tsx",
          lineNumber: 16,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialContent.tsx",
        lineNumber: 14,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-[repeat(4,minmax(0,268px))]", children: content.articles.map(
        (article) => /* @__PURE__ */ jsxDEV(EditorialArticleCard, { article }, article.title, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialContent.tsx",
          lineNumber: 22,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialContent.tsx",
        lineNumber: 20,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialContent.tsx",
      lineNumber: 13,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialContent.tsx",
    lineNumber: 7,
    columnNumber: 5
  }, this);
}
_c = EditorialContent;
var _c;
$RefreshReg$(_c, "EditorialContent");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialContent.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialContent.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialContent.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBTUksbUJBR00sY0FITjtBQUxKLFNBQVNBLDRCQUE0QjtBQUNyQyxTQUFTQyxxQkFBcUI7QUFFdkIsZ0JBQVNDLGlCQUFpQixFQUFFQyxRQUE4QixHQUFHO0FBQ2xFLFNBQ0UsbUNBQ0U7QUFBQSwyQkFBQyxhQUFRLGNBQVcsdUJBQXNCLFdBQVUsbUNBQ2pEQSxrQkFBUUMsV0FBV0M7QUFBQUEsTUFBSSxDQUFDQyxjQUN2Qix1QkFBQyxpQkFBb0MsYUFBakJBLFVBQVVDLE9BQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEQ7QUFBQSxJQUMzRCxLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLElBQ0EsdUJBQUMsYUFBUSxXQUFVLFNBQ2pCO0FBQUEsNkJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDBCQUF5QixrQ0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RDtBQUFBLFFBQ3pELHVCQUFDLE9BQUUsV0FBVSwrQkFBNkIsd0dBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsa0ZBQ1pKLGtCQUFRSyxTQUFTSDtBQUFBQSxRQUFJLENBQUNJLFlBQ3JCLHVCQUFDLHdCQUF5QyxXQUFmQSxRQUFRRixPQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJEO0FBQUEsTUFDNUQsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxTQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLE9BbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtQkE7QUFFSjtBQUFDRyxLQXZCZVI7QUFBZ0IsSUFBQVE7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiRWRpdG9yaWFsQXJ0aWNsZUNhcmQiLCJQcm9tb3Rpb25DYXJkIiwiRWRpdG9yaWFsQ29udGVudCIsImNvbnRlbnQiLCJwcm9tb3Rpb25zIiwibWFwIiwicHJvbW90aW9uIiwidGl0bGUiLCJhcnRpY2xlcyIsImFydGljbGUiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJFZGl0b3JpYWxDb250ZW50LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IENvbnRlbnQgfSBmcm9tICdAL2NvbnRyYWN0cy9jb250ZW50JztcbmltcG9ydCB7IEVkaXRvcmlhbEFydGljbGVDYXJkIH0gZnJvbSAnQC9mZWF0dXJlcy9jYXRhbG9nL2NvbXBvbmVudHMvRWRpdG9yaWFsQXJ0aWNsZUNhcmQnO1xuaW1wb3J0IHsgUHJvbW90aW9uQ2FyZCB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy9jb21wb25lbnRzL1Byb21vdGlvbkNhcmQnO1xuXG5leHBvcnQgZnVuY3Rpb24gRWRpdG9yaWFsQ29udGVudCh7IGNvbnRlbnQgfTogeyBjb250ZW50OiBDb250ZW50IH0pIHtcbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPHNlY3Rpb24gYXJpYS1sYWJlbD1cIkV4cGxvcmUgYXMgY29sZcOnw7Vlc1wiIGNsYXNzTmFtZT1cIm10LTI0IGdyaWQgZ2FwLTcgbWQ6Z3JpZC1jb2xzLTJcIj5cbiAgICAgICAge2NvbnRlbnQucHJvbW90aW9ucy5tYXAoKHByb21vdGlvbikgPT4gKFxuICAgICAgICAgIDxQcm9tb3Rpb25DYXJkIGtleT17cHJvbW90aW9uLnRpdGxlfSBwcm9tb3Rpb249e3Byb21vdGlvbn0gLz5cbiAgICAgICAgKSl9XG4gICAgICA8L3NlY3Rpb24+XG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJtdC0yNFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTEwIHNwYWNlLXktMyB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWhlYWRpbmcgZm9udC1ib2xkXCI+RGnDoXJpbyBkYSBDdW5oYWdlbTwvaDI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXRleHQtc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICBIaXN0w7NyaWFzLCBndWlhcyBlIGluc2lnaHRzIHBhcmEgY29sZWNpb25hZG9yZXMgc29icmUgbyB1bml2ZXJzbyBkYSBwcm9wcmllZGFkZSBkaWdpdGFsLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBnYXAtNiBzbTpncmlkLWNvbHMtMiB4bDpncmlkLWNvbHMtW3JlcGVhdCg0LG1pbm1heCgwLDI2OHB4KSldXCI+XG4gICAgICAgICAge2NvbnRlbnQuYXJ0aWNsZXMubWFwKChhcnRpY2xlKSA9PiAoXG4gICAgICAgICAgICA8RWRpdG9yaWFsQXJ0aWNsZUNhcmQga2V5PXthcnRpY2xlLnRpdGxlfSBhcnRpY2xlPXthcnRpY2xlfSAvPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvc2VjdGlvbj5cbiAgICA8Lz5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2ZpbGlwZWNhdmFsY2FudGUvRG9jdW1lbnRzL0p1bmdsZUdhbWluZ1Rlc3RlL3NyYy9mZWF0dXJlcy9jYXRhbG9nL2NvbXBvbmVudHMvRWRpdG9yaWFsQ29udGVudC50c3gifQ==