import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/slider.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { Slider as SliderPrimitive } from "/node_modules/.vite/deps/radix-ui.js?v=970a124b";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=970a124b"; const React = ((m) => m?.__esModule ? m : {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m})(__vite__cjsImport2_react);
import { cn } from "/src/lib/cn.ts";
function Slider({
  className,
  defaultValue,
  value,
  min = 0,
  max = 100,
  ...props
}) {
  _s();
  const _values = React.useMemo(
    () => Array.isArray(value) ? value : Array.isArray(defaultValue) ? defaultValue : [min, max],
    [value, defaultValue, min, max]
  );
  return /* @__PURE__ */ jsxDEV(
    SliderPrimitive.Root,
    {
      "data-slot": "slider",
      defaultValue,
      value,
      min,
      max,
      className: cn(
        "relative flex w-full touch-none items-center select-none data-[disabled]:opacity-50 data-[orientation=vertical]:h-full data-[orientation=vertical]:min-h-44 data-[orientation=vertical]:w-auto data-[orientation=vertical]:flex-col",
        className
      ),
      ...props,
      children: [
        /* @__PURE__ */ jsxDEV(
          SliderPrimitive.Track,
          {
            "data-slot": "slider-track",
            className: cn(
              "relative grow overflow-hidden rounded-full bg-muted data-[orientation=horizontal]:h-1 data-[orientation=horizontal]:w-full data-[orientation=vertical]:h-full data-[orientation=vertical]:w-1.5"
            ),
            children: /* @__PURE__ */ jsxDEV(
              SliderPrimitive.Range,
              {
                "data-slot": "slider-range",
                className: cn(
                  "absolute bg-primary data-[orientation=horizontal]:h-full data-[orientation=vertical]:w-full"
                )
              },
              void 0,
              false,
              {
                fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/slider.tsx",
                lineNumber: 38,
                columnNumber: 9
              },
              this
            )
          },
          void 0,
          false,
          {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/slider.tsx",
            lineNumber: 32,
            columnNumber: 7
          },
          this
        ),
        Array.from(
          { length: _values.length },
          (_, index) => /* @__PURE__ */ jsxDEV(
            SliderPrimitive.Thumb,
            {
              "data-slot": "slider-thumb",
              "aria-label": index === 0 ? "Preço mínimo" : "Preço máximo",
              className: "relative block size-5 shrink-0 rounded-full border-[3px] border-ink bg-primary shadow-sm ring-ring/50 transition-[color,box-shadow] before:absolute before:top-1/2 before:left-1/2 before:size-11 before:-translate-1/2 before:rounded-full hover:ring-4 focus-visible:ring-4 focus-visible:outline-hidden disabled:pointer-events-none disabled:opacity-50"
            },
            index,
            false,
            {
              fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/slider.tsx",
              lineNumber: 46,
              columnNumber: 7
            },
            this
          )
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/slider.tsx",
      lineNumber: 20,
      columnNumber: 5
    },
    this
  );
}
_s(Slider, "g0y/PG/feYg861SE8jxuAUMRVc0=");
_c = Slider;
export { Slider };
var _c;
$RefreshReg$(_c, "Slider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/slider.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/slider.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/ui/slider.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUNROztBQXJDUixTQUFTQSxVQUFVQyx1QkFBdUI7QUFDMUMsWUFBWUMsV0FBVztBQUV2QixTQUFTQyxVQUFVO0FBRW5CLFNBQVNILE9BQU87QUFBQSxFQUNkSTtBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxNQUFNO0FBQUEsRUFDTkMsTUFBTTtBQUFBLEVBQ04sR0FBR0M7QUFDOEMsR0FBRztBQUFBQyxLQUFBO0FBQ3BELFFBQU1DLFVBQVVULE1BQU1VO0FBQUFBLElBQ3BCLE1BQU9DLE1BQU1DLFFBQVFSLEtBQUssSUFBSUEsUUFBUU8sTUFBTUMsUUFBUVQsWUFBWSxJQUFJQSxlQUFlLENBQUNFLEtBQUtDLEdBQUc7QUFBQSxJQUM1RixDQUFDRixPQUFPRCxjQUFjRSxLQUFLQyxHQUFHO0FBQUEsRUFDaEM7QUFFQSxTQUNFO0FBQUEsSUFBQyxnQkFBZ0I7QUFBQSxJQUFoQjtBQUFBLE1BQ0MsYUFBVTtBQUFBLE1BQ1Y7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBLFdBQVdMO0FBQUFBLFFBQ1Q7QUFBQSxRQUNBQztBQUFBQSxNQUNGO0FBQUEsTUFDQSxHQUFJSztBQUFBQSxNQUVKO0FBQUE7QUFBQSxVQUFDLGdCQUFnQjtBQUFBLFVBQWhCO0FBQUEsWUFDQyxhQUFVO0FBQUEsWUFDVixXQUFXTjtBQUFBQSxjQUNUO0FBQUEsWUFDRjtBQUFBLFlBRUE7QUFBQSxjQUFDLGdCQUFnQjtBQUFBLGNBQWhCO0FBQUEsZ0JBQ0MsYUFBVTtBQUFBLGdCQUNWLFdBQVdBO0FBQUFBLGtCQUNUO0FBQUEsZ0JBQ0Y7QUFBQTtBQUFBLGNBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSUk7QUFBQTtBQUFBLFVBVk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBWUE7QUFBQSxRQUNDVSxNQUFNRTtBQUFBQSxVQUFLLEVBQUVDLFFBQVFMLFFBQVFLLE9BQU87QUFBQSxVQUFHLENBQUNDLEdBQUdDLFVBQzFDO0FBQUEsWUFBQyxnQkFBZ0I7QUFBQSxZQUFoQjtBQUFBLGNBQ0MsYUFBVTtBQUFBLGNBQ1YsY0FBWUEsVUFBVSxJQUFJLGlCQUFpQjtBQUFBLGNBRTNDLFdBQVU7QUFBQTtBQUFBLFlBRExBO0FBQUFBLFlBSFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUl5VztBQUFBLFFBRTFXO0FBQUE7QUFBQTtBQUFBLElBaENIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWlDQTtBQUVKO0FBQUNSLEdBakRRVixRQUFNO0FBQUEsS0FBTkE7QUFtRFQsU0FBU0E7QUFBUyxJQUFBbUI7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiU2xpZGVyIiwiU2xpZGVyUHJpbWl0aXZlIiwiUmVhY3QiLCJjbiIsImNsYXNzTmFtZSIsImRlZmF1bHRWYWx1ZSIsInZhbHVlIiwibWluIiwibWF4IiwicHJvcHMiLCJfcyIsIl92YWx1ZXMiLCJ1c2VNZW1vIiwiQXJyYXkiLCJpc0FycmF5IiwiZnJvbSIsImxlbmd0aCIsIl8iLCJpbmRleCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbInNsaWRlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU2xpZGVyIGFzIFNsaWRlclByaW1pdGl2ZSB9IGZyb20gJ3JhZGl4LXVpJztcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcblxuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi9jbic7XG5cbmZ1bmN0aW9uIFNsaWRlcih7XG4gIGNsYXNzTmFtZSxcbiAgZGVmYXVsdFZhbHVlLFxuICB2YWx1ZSxcbiAgbWluID0gMCxcbiAgbWF4ID0gMTAwLFxuICAuLi5wcm9wc1xufTogUmVhY3QuQ29tcG9uZW50UHJvcHM8dHlwZW9mIFNsaWRlclByaW1pdGl2ZS5Sb290Pikge1xuICBjb25zdCBfdmFsdWVzID0gUmVhY3QudXNlTWVtbyhcbiAgICAoKSA9PiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkgPyB2YWx1ZSA6IEFycmF5LmlzQXJyYXkoZGVmYXVsdFZhbHVlKSA/IGRlZmF1bHRWYWx1ZSA6IFttaW4sIG1heF0pLFxuICAgIFt2YWx1ZSwgZGVmYXVsdFZhbHVlLCBtaW4sIG1heF0sXG4gICk7XG5cbiAgcmV0dXJuIChcbiAgICA8U2xpZGVyUHJpbWl0aXZlLlJvb3RcbiAgICAgIGRhdGEtc2xvdD1cInNsaWRlclwiXG4gICAgICBkZWZhdWx0VmFsdWU9e2RlZmF1bHRWYWx1ZX1cbiAgICAgIHZhbHVlPXt2YWx1ZX1cbiAgICAgIG1pbj17bWlufVxuICAgICAgbWF4PXttYXh9XG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAncmVsYXRpdmUgZmxleCB3LWZ1bGwgdG91Y2gtbm9uZSBpdGVtcy1jZW50ZXIgc2VsZWN0LW5vbmUgZGF0YS1bZGlzYWJsZWRdOm9wYWNpdHktNTAgZGF0YS1bb3JpZW50YXRpb249dmVydGljYWxdOmgtZnVsbCBkYXRhLVtvcmllbnRhdGlvbj12ZXJ0aWNhbF06bWluLWgtNDQgZGF0YS1bb3JpZW50YXRpb249dmVydGljYWxdOnctYXV0byBkYXRhLVtvcmllbnRhdGlvbj12ZXJ0aWNhbF06ZmxleC1jb2wnLFxuICAgICAgICBjbGFzc05hbWUsXG4gICAgICApfVxuICAgICAgey4uLnByb3BzfVxuICAgID5cbiAgICAgIDxTbGlkZXJQcmltaXRpdmUuVHJhY2tcbiAgICAgICAgZGF0YS1zbG90PVwic2xpZGVyLXRyYWNrXCJcbiAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAncmVsYXRpdmUgZ3JvdyBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1mdWxsIGJnLW11dGVkIGRhdGEtW29yaWVudGF0aW9uPWhvcml6b250YWxdOmgtMSBkYXRhLVtvcmllbnRhdGlvbj1ob3Jpem9udGFsXTp3LWZ1bGwgZGF0YS1bb3JpZW50YXRpb249dmVydGljYWxdOmgtZnVsbCBkYXRhLVtvcmllbnRhdGlvbj12ZXJ0aWNhbF06dy0xLjUnLFxuICAgICAgICApfVxuICAgICAgPlxuICAgICAgICA8U2xpZGVyUHJpbWl0aXZlLlJhbmdlXG4gICAgICAgICAgZGF0YS1zbG90PVwic2xpZGVyLXJhbmdlXCJcbiAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgJ2Fic29sdXRlIGJnLXByaW1hcnkgZGF0YS1bb3JpZW50YXRpb249aG9yaXpvbnRhbF06aC1mdWxsIGRhdGEtW29yaWVudGF0aW9uPXZlcnRpY2FsXTp3LWZ1bGwnLFxuICAgICAgICAgICl9XG4gICAgICAgIC8+XG4gICAgICA8L1NsaWRlclByaW1pdGl2ZS5UcmFjaz5cbiAgICAgIHtBcnJheS5mcm9tKHsgbGVuZ3RoOiBfdmFsdWVzLmxlbmd0aCB9LCAoXywgaW5kZXgpID0+IChcbiAgICAgICAgPFNsaWRlclByaW1pdGl2ZS5UaHVtYlxuICAgICAgICAgIGRhdGEtc2xvdD1cInNsaWRlci10aHVtYlwiXG4gICAgICAgICAgYXJpYS1sYWJlbD17aW5kZXggPT09IDAgPyAnUHJlw6dvIG3DrW5pbW8nIDogJ1ByZcOnbyBtw6F4aW1vJ31cbiAgICAgICAgICBrZXk9e2luZGV4fVxuICAgICAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlIGJsb2NrIHNpemUtNSBzaHJpbmstMCByb3VuZGVkLWZ1bGwgYm9yZGVyLVszcHhdIGJvcmRlci1pbmsgYmctcHJpbWFyeSBzaGFkb3ctc20gcmluZy1yaW5nLzUwIHRyYW5zaXRpb24tW2NvbG9yLGJveC1zaGFkb3ddIGJlZm9yZTphYnNvbHV0ZSBiZWZvcmU6dG9wLTEvMiBiZWZvcmU6bGVmdC0xLzIgYmVmb3JlOnNpemUtMTEgYmVmb3JlOi10cmFuc2xhdGUtMS8yIGJlZm9yZTpyb3VuZGVkLWZ1bGwgaG92ZXI6cmluZy00IGZvY3VzLXZpc2libGU6cmluZy00IGZvY3VzLXZpc2libGU6b3V0bGluZS1oaWRkZW4gZGlzYWJsZWQ6cG9pbnRlci1ldmVudHMtbm9uZSBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcbiAgICAgICAgLz5cbiAgICAgICkpfVxuICAgIDwvU2xpZGVyUHJpbWl0aXZlLlJvb3Q+XG4gICk7XG59XG5cbmV4cG9ydCB7IFNsaWRlciB9O1xuIl0sImZpbGUiOiIvVXNlcnMvZmlsaXBlY2F2YWxjYW50ZS9Eb2N1bWVudHMvSnVuZ2xlR2FtaW5nVGVzdGUvc3JjL2NvbXBvbmVudHMvdWkvc2xpZGVyLnRzeCJ9