import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/PriceRangeFilter.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=970a124b"; const useState = __vite__cjsImport1_react["useState"];
import { Button } from "/src/components/ui/button.tsx";
import { Slider } from "/src/components/ui/slider.tsx";
export function PriceRangeFilter({
  search,
  apply
}) {
  _s();
  const [range, setRange] = useState(
    [
      Number(search.minPrice ?? "0.02"),
      Number(search.maxPrice ?? "12.3")
    ]
  );
  return /* @__PURE__ */ jsxDEV("section", { className: "space-y-3", children: [
    /* @__PURE__ */ jsxDEV("h3", { className: "text-lg leading-[22px] font-bold", children: "Faixa de preço" }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PriceRangeFilter.tsx",
      lineNumber: 20,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Slider, { min: 0.02, max: 12.3, step: 0.01, value: range, onValueChange: setRange }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PriceRangeFilter.tsx",
      lineNumber: 21,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "text-body-sm", children: [
      "Preço: ",
      range[0]?.toFixed(2).replace(".", ","),
      " – ",
      range[1]?.toFixed(2).replace(".", ","),
      " ",
      "ETH"
    ] }, void 0, true, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PriceRangeFilter.tsx",
      lineNumber: 22,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Button,
      {
        size: "filter",
        onClick: () => {
          apply({ minPrice: String(range[0] ?? 0.02), maxPrice: String(range[1] ?? 12.3) });
        },
        children: "Aplicar"
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PriceRangeFilter.tsx",
        lineNumber: 26,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PriceRangeFilter.tsx",
    lineNumber: 19,
    columnNumber: 5
  }, this);
}
_s(PriceRangeFilter, "qhKdX3/gYB/zkOjim+mUodg2aGA=");
_c = PriceRangeFilter;
var _c;
$RefreshReg$(_c, "PriceRangeFilter");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PriceRangeFilter.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PriceRangeFilter.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PriceRangeFilter.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUJNOztBQW5CTixTQUFTQSxnQkFBZ0I7QUFFekIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxjQUFjO0FBR2hCLGdCQUFTQyxpQkFBaUI7QUFBQSxFQUMvQkM7QUFBQUEsRUFDQUM7QUFJRixHQUFHO0FBQUFDLEtBQUE7QUFDRCxRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSVI7QUFBQUEsSUFBUztBQUFBLE1BQ2pDUyxPQUFPTCxPQUFPTSxZQUFZLE1BQU07QUFBQSxNQUNoQ0QsT0FBT0wsT0FBT08sWUFBWSxNQUFNO0FBQUEsSUFBQztBQUFBLEVBQ2xDO0FBQ0QsU0FDRSx1QkFBQyxhQUFRLFdBQVUsYUFDakI7QUFBQSwyQkFBQyxRQUFHLFdBQVUsb0NBQW1DLDhCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStEO0FBQUEsSUFDL0QsdUJBQUMsVUFBTyxLQUFLLE1BQU0sS0FBSyxNQUFNLE1BQU0sTUFBTSxPQUFPSixPQUFPLGVBQWVDLFlBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0Y7QUFBQSxJQUNoRix1QkFBQyxPQUFFLFdBQVUsZ0JBQWM7QUFBQTtBQUFBLE1BQ2pCRCxNQUFNLENBQUMsR0FBR0ssUUFBUSxDQUFDLEVBQUVDLFFBQVEsS0FBSyxHQUFHO0FBQUEsTUFBRTtBQUFBLE1BQUlOLE1BQU0sQ0FBQyxHQUFHSyxRQUFRLENBQUMsRUFBRUMsUUFBUSxLQUFLLEdBQUc7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLFNBRGhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQUs7QUFBQSxRQUNMLFNBQVMsTUFBTTtBQUNiUixnQkFBTSxFQUFFSyxVQUFVSSxPQUFPUCxNQUFNLENBQUMsS0FBSyxJQUFJLEdBQUdJLFVBQVVHLE9BQU9QLE1BQU0sQ0FBQyxLQUFLLElBQUksRUFBRSxDQUFDO0FBQUEsUUFDbEY7QUFBQSxRQUFFO0FBQUE7QUFBQSxNQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU9BO0FBQUEsT0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZUE7QUFFSjtBQUFDRCxHQTdCZUgsa0JBQWdCO0FBQUEsS0FBaEJBO0FBQWdCLElBQUFZO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQnV0dG9uIiwiU2xpZGVyIiwiUHJpY2VSYW5nZUZpbHRlciIsInNlYXJjaCIsImFwcGx5IiwiX3MiLCJyYW5nZSIsInNldFJhbmdlIiwiTnVtYmVyIiwibWluUHJpY2UiLCJtYXhQcmljZSIsInRvRml4ZWQiLCJyZXBsYWNlIiwiU3RyaW5nIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUHJpY2VSYW5nZUZpbHRlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5cbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nO1xuaW1wb3J0IHsgU2xpZGVyIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL3NsaWRlcic7XG5pbXBvcnQgdHlwZSB7IENhdGFsb2dTZWFyY2ggfSBmcm9tICdAL2ZlYXR1cmVzL2NhdGFsb2cvc2VhcmNoLXBhcmFtcyc7XG5cbmV4cG9ydCBmdW5jdGlvbiBQcmljZVJhbmdlRmlsdGVyKHtcbiAgc2VhcmNoLFxuICBhcHBseSxcbn06IHtcbiAgc2VhcmNoOiBDYXRhbG9nU2VhcmNoO1xuICBhcHBseTogKHZhbHVlczogUGFydGlhbDxDYXRhbG9nU2VhcmNoPikgPT4gdm9pZDtcbn0pIHtcbiAgY29uc3QgW3JhbmdlLCBzZXRSYW5nZV0gPSB1c2VTdGF0ZShbXG4gICAgTnVtYmVyKHNlYXJjaC5taW5QcmljZSA/PyAnMC4wMicpLFxuICAgIE51bWJlcihzZWFyY2gubWF4UHJpY2UgPz8gJzEyLjMnKSxcbiAgXSk7XG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBsZWFkaW5nLVsyMnB4XSBmb250LWJvbGRcIj5GYWl4YSBkZSBwcmXDp288L2gzPlxuICAgICAgPFNsaWRlciBtaW49ezAuMDJ9IG1heD17MTIuM30gc3RlcD17MC4wMX0gdmFsdWU9e3JhbmdlfSBvblZhbHVlQ2hhbmdlPXtzZXRSYW5nZX0gLz5cbiAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtYm9keS1zbVwiPlxuICAgICAgICBQcmXDp286IHtyYW5nZVswXT8udG9GaXhlZCgyKS5yZXBsYWNlKCcuJywgJywnKX0g4oCTIHtyYW5nZVsxXT8udG9GaXhlZCgyKS5yZXBsYWNlKCcuJywgJywnKX17JyAnfVxuICAgICAgICBFVEhcbiAgICAgIDwvcD5cbiAgICAgIDxCdXR0b25cbiAgICAgICAgc2l6ZT1cImZpbHRlclwiXG4gICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICBhcHBseSh7IG1pblByaWNlOiBTdHJpbmcocmFuZ2VbMF0gPz8gMC4wMiksIG1heFByaWNlOiBTdHJpbmcocmFuZ2VbMV0gPz8gMTIuMykgfSk7XG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIEFwbGljYXJcbiAgICAgIDwvQnV0dG9uPlxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2ZpbGlwZWNhdmFsY2FudGUvRG9jdW1lbnRzL0p1bmdsZUdhbWluZ1Rlc3RlL3NyYy9mZWF0dXJlcy9jYXRhbG9nL2NvbXBvbmVudHMvUHJpY2VSYW5nZUZpbHRlci50c3gifQ==