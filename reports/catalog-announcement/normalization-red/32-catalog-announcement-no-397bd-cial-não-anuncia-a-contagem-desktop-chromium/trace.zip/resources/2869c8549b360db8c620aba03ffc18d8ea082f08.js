import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/CatalogSection.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { CatalogResults } from "/src/features/catalog/components/CatalogResults.tsx?t=1792850937924";
import { FeaturedCard } from "/src/features/catalog/components/FeaturedCard.tsx";
import { FilterDrawer } from "/src/features/catalog/components/FilterDrawer.tsx";
import { FilterSidebar } from "/src/features/catalog/components/FilterSidebar.tsx";
export function CatalogSection({
  search,
  query,
  hero,
  navigation
}) {
  const filterProps = {
    search,
    ...query.data ? { facets: query.data.facets } : {},
    apply: navigation.setFilter,
    clear: navigation.clear
  };
  return /* @__PURE__ */ jsxDEV("section", { id: "catalogo", className: "scroll-mt-6", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "sr-only", children: "Catálogo de NFTs" }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogSection.tsx",
      lineNumber: 28,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mb-6 hidden items-center justify-between gap-4 md:flex lg:hidden", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-title font-bold", children: "Explorar coleções" }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogSection.tsx",
        lineNumber: 30,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(FilterDrawer, { ...filterProps }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogSection.tsx",
        lineNumber: 31,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogSection.tsx",
      lineNumber: 29,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid gap-12 lg:grid-cols-[310px_minmax(0,1fr)]", children: [
      /* @__PURE__ */ jsxDEV("aside", { className: "hidden lg:block", children: [
        /* @__PURE__ */ jsxDEV(FilterSidebar, { ...filterProps }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogSection.tsx",
          lineNumber: 35,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(FeaturedCard, { ...hero.data?.items[1] ? { nft: hero.data.items[1] } : {} }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogSection.tsx",
          lineNumber: 36,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogSection.tsx",
        lineNumber: 34,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(CatalogResults, { search, query, navigation }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogSection.tsx",
        lineNumber: 38,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogSection.tsx",
      lineNumber: 33,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogSection.tsx",
    lineNumber: 27,
    columnNumber: 5
  }, this);
}
_c = CatalogSection;
var _c;
$RefreshReg$(_c, "CatalogSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogSection.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogSection.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogSection.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkJNO0FBM0JOLFNBQVNBLHNCQUFzQjtBQUMvQixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLHFCQUFxQjtBQUt2QixnQkFBU0MsZUFBZTtBQUFBLEVBQzdCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQU1GLEdBQUc7QUFDRCxRQUFNQyxjQUFjO0FBQUEsSUFDbEJKO0FBQUFBLElBQ0EsR0FBSUMsTUFBTUksT0FBTyxFQUFFQyxRQUFRTCxNQUFNSSxLQUFLQyxPQUFPLElBQUksQ0FBQztBQUFBLElBQ2xEQyxPQUFPSixXQUFXSztBQUFBQSxJQUNsQkMsT0FBT04sV0FBV007QUFBQUEsRUFDcEI7QUFDQSxTQUNFLHVCQUFDLGFBQVEsSUFBRyxZQUFXLFdBQVUsZUFDL0I7QUFBQSwyQkFBQyxRQUFHLFdBQVUsV0FBVSxnQ0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3QztBQUFBLElBQ3hDLHVCQUFDLFNBQUksV0FBVSxvRUFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSx3QkFBdUIsaUNBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0Q7QUFBQSxNQUN0RCx1QkFBQyxnQkFBYSxHQUFJTCxlQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThCO0FBQUEsU0FGaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsa0RBQ2I7QUFBQSw2QkFBQyxXQUFNLFdBQVUsbUJBQ2Y7QUFBQSwrQkFBQyxpQkFBYyxHQUFJQSxlQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStCO0FBQUEsUUFDL0IsdUJBQUMsZ0JBQWEsR0FBS0YsS0FBS0csTUFBTUssTUFBTSxDQUFDLElBQUksRUFBRUMsS0FBS1QsS0FBS0csS0FBS0ssTUFBTSxDQUFDLEVBQUUsSUFBSSxDQUFDLEtBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkU7QUFBQSxXQUY3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLGtCQUFlLFFBQWdCLE9BQWMsY0FBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRTtBQUFBLFNBTHZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLE9BWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWFBO0FBRUo7QUFBQ0UsS0FqQ2ViO0FBQWMsSUFBQWE7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiQ2F0YWxvZ1Jlc3VsdHMiLCJGZWF0dXJlZENhcmQiLCJGaWx0ZXJEcmF3ZXIiLCJGaWx0ZXJTaWRlYmFyIiwiQ2F0YWxvZ1NlY3Rpb24iLCJzZWFyY2giLCJxdWVyeSIsImhlcm8iLCJuYXZpZ2F0aW9uIiwiZmlsdGVyUHJvcHMiLCJkYXRhIiwiZmFjZXRzIiwiYXBwbHkiLCJzZXRGaWx0ZXIiLCJjbGVhciIsIml0ZW1zIiwibmZ0IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ2F0YWxvZ1NlY3Rpb24udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENhdGFsb2dSZXN1bHRzIH0gZnJvbSAnQC9mZWF0dXJlcy9jYXRhbG9nL2NvbXBvbmVudHMvQ2F0YWxvZ1Jlc3VsdHMnO1xuaW1wb3J0IHsgRmVhdHVyZWRDYXJkIH0gZnJvbSAnQC9mZWF0dXJlcy9jYXRhbG9nL2NvbXBvbmVudHMvRmVhdHVyZWRDYXJkJztcbmltcG9ydCB7IEZpbHRlckRyYXdlciB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy9jb21wb25lbnRzL0ZpbHRlckRyYXdlcic7XG5pbXBvcnQgeyBGaWx0ZXJTaWRlYmFyIH0gZnJvbSAnQC9mZWF0dXJlcy9jYXRhbG9nL2NvbXBvbmVudHMvRmlsdGVyU2lkZWJhcic7XG5pbXBvcnQgdHlwZSB7IHVzZUNhdGFsb2dRdWVyeSB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy9xdWVyaWVzJztcbmltcG9ydCB0eXBlIHsgQ2F0YWxvZ1NlYXJjaCB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy9zZWFyY2gtcGFyYW1zJztcbmltcG9ydCB0eXBlIHsgdXNlQ2F0YWxvZ05hdmlnYXRpb24gfSBmcm9tICdAL2ZlYXR1cmVzL2NhdGFsb2cvdXNlQ2F0YWxvZ05hdmlnYXRpb24nO1xuXG5leHBvcnQgZnVuY3Rpb24gQ2F0YWxvZ1NlY3Rpb24oe1xuICBzZWFyY2gsXG4gIHF1ZXJ5LFxuICBoZXJvLFxuICBuYXZpZ2F0aW9uLFxufToge1xuICBzZWFyY2g6IENhdGFsb2dTZWFyY2g7XG4gIHF1ZXJ5OiBSZXR1cm5UeXBlPHR5cGVvZiB1c2VDYXRhbG9nUXVlcnk+O1xuICBoZXJvOiBSZXR1cm5UeXBlPHR5cGVvZiB1c2VDYXRhbG9nUXVlcnk+O1xuICBuYXZpZ2F0aW9uOiBSZXR1cm5UeXBlPHR5cGVvZiB1c2VDYXRhbG9nTmF2aWdhdGlvbj47XG59KSB7XG4gIGNvbnN0IGZpbHRlclByb3BzID0ge1xuICAgIHNlYXJjaCxcbiAgICAuLi4ocXVlcnkuZGF0YSA/IHsgZmFjZXRzOiBxdWVyeS5kYXRhLmZhY2V0cyB9IDoge30pLFxuICAgIGFwcGx5OiBuYXZpZ2F0aW9uLnNldEZpbHRlcixcbiAgICBjbGVhcjogbmF2aWdhdGlvbi5jbGVhcixcbiAgfTtcbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBpZD1cImNhdGFsb2dvXCIgY2xhc3NOYW1lPVwic2Nyb2xsLW10LTZcIj5cbiAgICAgIDxoMiBjbGFzc05hbWU9XCJzci1vbmx5XCI+Q2F0w6Fsb2dvIGRlIE5GVHM8L2gyPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02IGhpZGRlbiBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IG1kOmZsZXggbGc6aGlkZGVuXCI+XG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXRpdGxlIGZvbnQtYm9sZFwiPkV4cGxvcmFyIGNvbGXDp8O1ZXM8L2gyPlxuICAgICAgICA8RmlsdGVyRHJhd2VyIHsuLi5maWx0ZXJQcm9wc30gLz5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC0xMiBsZzpncmlkLWNvbHMtWzMxMHB4X21pbm1heCgwLDFmcildXCI+XG4gICAgICAgIDxhc2lkZSBjbGFzc05hbWU9XCJoaWRkZW4gbGc6YmxvY2tcIj5cbiAgICAgICAgICA8RmlsdGVyU2lkZWJhciB7Li4uZmlsdGVyUHJvcHN9IC8+XG4gICAgICAgICAgPEZlYXR1cmVkQ2FyZCB7Li4uKGhlcm8uZGF0YT8uaXRlbXNbMV0gPyB7IG5mdDogaGVyby5kYXRhLml0ZW1zWzFdIH0gOiB7fSl9IC8+XG4gICAgICAgIDwvYXNpZGU+XG4gICAgICAgIDxDYXRhbG9nUmVzdWx0cyBzZWFyY2g9e3NlYXJjaH0gcXVlcnk9e3F1ZXJ5fSBuYXZpZ2F0aW9uPXtuYXZpZ2F0aW9ufSAvPlxuICAgICAgPC9kaXY+XG4gICAgPC9zZWN0aW9uPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvZmlsaXBlY2F2YWxjYW50ZS9Eb2N1bWVudHMvSnVuZ2xlR2FtaW5nVGVzdGUvc3JjL2ZlYXR1cmVzL2NhdGFsb2cvY29tcG9uZW50cy9DYXRhbG9nU2VjdGlvbi50c3gifQ==