import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/media/ArtworkUnavailable.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { ImageOff } from "/node_modules/.vite/deps/lucide-react.js?v=970a124b";
import { artworkMessages } from "/src/components/media/messages.ts";
import { cn } from "/src/lib/cn.ts";
export function ArtworkUnavailable({
  alt,
  className,
  testId,
  dimensions
}) {
  const width = Number(dimensions.width) || 24;
  const height = Number(dimensions.height) || 24;
  return /* @__PURE__ */ jsxDEV(
    "svg",
    {
      role: alt ? "img" : void 0,
      "aria-label": alt ? `${artworkMessages.unavailable}: ${alt}` : void 0,
      "aria-hidden": !alt,
      "data-testid": testId,
      "data-artwork-state": "unavailable",
      width,
      height,
      viewBox: `0 0 ${width} ${height}`,
      className: cn("h-auto", className, "bg-surface-raised text-text-secondary"),
      children: /* @__PURE__ */ jsxDEV(ImageOff, { "aria-hidden": "true", size: 24, x: (width - 24) / 2, y: (height - 24) / 2 }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/media/ArtworkUnavailable.tsx",
        lineNumber: 33,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/media/ArtworkUnavailable.tsx",
      lineNumber: 22,
      columnNumber: 5
    },
    this
  );
}
_c = ArtworkUnavailable;
var _c;
$RefreshReg$(_c, "ArtworkUnavailable");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/media/ArtworkUnavailable.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/media/ArtworkUnavailable.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/media/ArtworkUnavailable.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0NNO0FBaENOLFNBQVNBLGdCQUFnQjtBQUV6QixTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsVUFBVTtBQUlaLGdCQUFTQyxtQkFBbUI7QUFBQSxFQUNqQ0M7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFNRixHQUFHO0FBQ0QsUUFBTUMsUUFBUUMsT0FBT0YsV0FBV0MsS0FBSyxLQUFLO0FBQzFDLFFBQU1FLFNBQVNELE9BQU9GLFdBQVdHLE1BQU0sS0FBSztBQUM1QyxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxNQUFNTixNQUFNLFFBQVFPO0FBQUFBLE1BQ3BCLGNBQVlQLE1BQU0sR0FBR0gsZ0JBQWdCVyxXQUFXLEtBQUtSLEdBQUcsS0FBS087QUFBQUEsTUFDN0QsZUFBYSxDQUFDUDtBQUFBQSxNQUNkLGVBQWFFO0FBQUFBLE1BQ2Isc0JBQW1CO0FBQUEsTUFDbkI7QUFBQSxNQUNBO0FBQUEsTUFDQSxTQUFTLE9BQU9FLEtBQUssSUFBSUUsTUFBTTtBQUFBLE1BQy9CLFdBQVdSLEdBQUcsVUFBVUcsV0FBVyx1Q0FBdUM7QUFBQSxNQUUxRSxpQ0FBQyxZQUFTLGVBQVksUUFBTyxNQUFNLElBQUksSUFBSUcsUUFBUSxNQUFNLEdBQUcsSUFBSUUsU0FBUyxNQUFNLEtBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUY7QUFBQTtBQUFBLElBWG5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVlBO0FBRUo7QUFBQ0csS0E1QmVWO0FBQWtCLElBQUFVO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkltYWdlT2ZmIiwiYXJ0d29ya01lc3NhZ2VzIiwiY24iLCJBcnR3b3JrVW5hdmFpbGFibGUiLCJhbHQiLCJjbGFzc05hbWUiLCJ0ZXN0SWQiLCJkaW1lbnNpb25zIiwid2lkdGgiLCJOdW1iZXIiLCJoZWlnaHQiLCJ1bmRlZmluZWQiLCJ1bmF2YWlsYWJsZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkFydHdvcmtVbmF2YWlsYWJsZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW1hZ2VPZmYgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5pbXBvcnQgeyBhcnR3b3JrTWVzc2FnZXMgfSBmcm9tICdAL2NvbXBvbmVudHMvbWVkaWEvbWVzc2FnZXMnO1xuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi9jbic7XG5cbmltcG9ydCB0eXBlIHsgQ29tcG9uZW50UHJvcHMgfSBmcm9tICdyZWFjdCc7XG5cbmV4cG9ydCBmdW5jdGlvbiBBcnR3b3JrVW5hdmFpbGFibGUoe1xuICBhbHQsXG4gIGNsYXNzTmFtZSxcbiAgdGVzdElkLFxuICBkaW1lbnNpb25zLFxufToge1xuICBhbHQ6IHN0cmluZztcbiAgY2xhc3NOYW1lOiBzdHJpbmcgfCB1bmRlZmluZWQ7XG4gIHRlc3RJZDogc3RyaW5nIHwgdW5kZWZpbmVkO1xuICBkaW1lbnNpb25zOiBQaWNrPENvbXBvbmVudFByb3BzPCdpbWcnPiwgJ3dpZHRoJyB8ICdoZWlnaHQnPjtcbn0pIHtcbiAgY29uc3Qgd2lkdGggPSBOdW1iZXIoZGltZW5zaW9ucy53aWR0aCkgfHwgMjQ7XG4gIGNvbnN0IGhlaWdodCA9IE51bWJlcihkaW1lbnNpb25zLmhlaWdodCkgfHwgMjQ7XG4gIHJldHVybiAoXG4gICAgPHN2Z1xuICAgICAgcm9sZT17YWx0ID8gJ2ltZycgOiB1bmRlZmluZWR9XG4gICAgICBhcmlhLWxhYmVsPXthbHQgPyBgJHthcnR3b3JrTWVzc2FnZXMudW5hdmFpbGFibGV9OiAke2FsdH1gIDogdW5kZWZpbmVkfVxuICAgICAgYXJpYS1oaWRkZW49eyFhbHR9XG4gICAgICBkYXRhLXRlc3RpZD17dGVzdElkfVxuICAgICAgZGF0YS1hcnR3b3JrLXN0YXRlPVwidW5hdmFpbGFibGVcIlxuICAgICAgd2lkdGg9e3dpZHRofVxuICAgICAgaGVpZ2h0PXtoZWlnaHR9XG4gICAgICB2aWV3Qm94PXtgMCAwICR7d2lkdGh9ICR7aGVpZ2h0fWB9XG4gICAgICBjbGFzc05hbWU9e2NuKCdoLWF1dG8nLCBjbGFzc05hbWUsICdiZy1zdXJmYWNlLXJhaXNlZCB0ZXh0LXRleHQtc2Vjb25kYXJ5Jyl9XG4gICAgPlxuICAgICAgPEltYWdlT2ZmIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIHNpemU9ezI0fSB4PXsod2lkdGggLSAyNCkgLyAyfSB5PXsoaGVpZ2h0IC0gMjQpIC8gMn0gLz5cbiAgICA8L3N2Zz5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2ZpbGlwZWNhdmFsY2FudGUvRG9jdW1lbnRzL0p1bmdsZUdhbWluZ1Rlc3RlL3NyYy9jb21wb25lbnRzL21lZGlhL0FydHdvcmtVbmF2YWlsYWJsZS50c3gifQ==