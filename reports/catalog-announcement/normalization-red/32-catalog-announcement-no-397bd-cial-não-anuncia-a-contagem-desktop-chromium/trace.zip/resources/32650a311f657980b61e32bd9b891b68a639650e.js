import { z } from "/node_modules/.vite/deps/zod.js?v=970a124b";
import { nftImageSchema } from "/src/contracts/nft.ts";
export const contentSchema = z.object({
  promotions: z.array(
    z.object({ title: z.string(), description: z.string(), image: nftImageSchema })
  ),
  articles: z.array(
    z.object({
      title: z.string(),
      description: z.string(),
      image: nftImageSchema,
      dateLabel: z.string(),
      readingLabel: z.string()
    })
  )
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbnRlbnQudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgeiB9IGZyb20gJ3pvZCc7XG5cbmltcG9ydCB7IG5mdEltYWdlU2NoZW1hIH0gZnJvbSAnQC9jb250cmFjdHMvbmZ0JztcblxuZXhwb3J0IGNvbnN0IGNvbnRlbnRTY2hlbWEgPSB6Lm9iamVjdCh7XG4gIHByb21vdGlvbnM6IHouYXJyYXkoXG4gICAgei5vYmplY3QoeyB0aXRsZTogei5zdHJpbmcoKSwgZGVzY3JpcHRpb246IHouc3RyaW5nKCksIGltYWdlOiBuZnRJbWFnZVNjaGVtYSB9KSxcbiAgKSxcbiAgYXJ0aWNsZXM6IHouYXJyYXkoXG4gICAgei5vYmplY3Qoe1xuICAgICAgdGl0bGU6IHouc3RyaW5nKCksXG4gICAgICBkZXNjcmlwdGlvbjogei5zdHJpbmcoKSxcbiAgICAgIGltYWdlOiBuZnRJbWFnZVNjaGVtYSxcbiAgICAgIGRhdGVMYWJlbDogei5zdHJpbmcoKSxcbiAgICAgIHJlYWRpbmdMYWJlbDogei5zdHJpbmcoKSxcbiAgICB9KSxcbiAgKSxcbn0pO1xuZXhwb3J0IHR5cGUgQ29udGVudCA9IHouaW5mZXI8dHlwZW9mIGNvbnRlbnRTY2hlbWE+O1xuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLFNBQVM7QUFFbEIsU0FBUyxzQkFBc0I7QUFFeEIsYUFBTSxnQkFBZ0IsRUFBRSxPQUFPO0FBQUEsRUFDcEMsWUFBWSxFQUFFO0FBQUEsSUFDWixFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUUsT0FBTyxHQUFHLGFBQWEsRUFBRSxPQUFPLEdBQUcsT0FBTyxlQUFlLENBQUM7QUFBQSxFQUNoRjtBQUFBLEVBQ0EsVUFBVSxFQUFFO0FBQUEsSUFDVixFQUFFLE9BQU87QUFBQSxNQUNQLE9BQU8sRUFBRSxPQUFPO0FBQUEsTUFDaEIsYUFBYSxFQUFFLE9BQU87QUFBQSxNQUN0QixPQUFPO0FBQUEsTUFDUCxXQUFXLEVBQUUsT0FBTztBQUFBLE1BQ3BCLGNBQWMsRUFBRSxPQUFPO0FBQUEsSUFDekIsQ0FBQztBQUFBLEVBQ0g7QUFDRixDQUFDOyIsIm5hbWVzIjpbXX0=