import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/NftGrid.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { NftCardSkeleton } from "/src/components/feedback/NftCardSkeleton.tsx";
import { NftCard } from "/src/features/catalog/components/NftCard.tsx";
export function NftGrid({ items, loading = false }) {
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      "data-testid": "nft-grid",
      "aria-busy": loading,
      className: "grid grid-cols-2 gap-x-4 gap-y-6 pb-8 sm:gap-6 sm:pb-0 lg:grid-cols-3 lg:gap-x-[34px] lg:gap-y-[72px] max-sm:[&>*:nth-child(even)]:translate-y-8",
      children: loading ? Array.from({ length: 9 }, (_, index) => /* @__PURE__ */ jsxDEV(NftCardSkeleton, {}, index, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftGrid.tsx",
        lineNumber: 13,
        columnNumber: 47
      }, this)) : items?.map((nft, index) => /* @__PURE__ */ jsxDEV(NftCard, { nft, priority: index < 3 }, nft.id, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftGrid.tsx",
        lineNumber: 14,
        columnNumber: 34
      }, this))
    },
    void 0,
    false,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftGrid.tsx",
      lineNumber: 7,
      columnNumber: 5
    },
    this
  );
}
_c = NftGrid;
var _c;
$RefreshReg$(_c, "NftGrid");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftGrid.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftGrid.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/NftGrid.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWWtEO0FBWmxELFNBQVNBLHVCQUF1QjtBQUVoQyxTQUFTQyxlQUFlO0FBRWpCLGdCQUFTQyxRQUFRLEVBQUVDLE9BQU9DLFVBQVUsTUFBNEMsR0FBRztBQUN4RixTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxlQUFZO0FBQUEsTUFDWixhQUFXQTtBQUFBQSxNQUNYLFdBQVU7QUFBQSxNQUVUQSxvQkFDR0MsTUFBTUMsS0FBSyxFQUFFQyxRQUFRLEVBQUUsR0FBRyxDQUFDQyxHQUFHQyxVQUFVLHVCQUFDLHFCQUFxQkEsT0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0QixDQUFHLElBQ3ZFTixPQUFPTyxJQUFJLENBQUNDLEtBQUtGLFVBQVUsdUJBQUMsV0FBUSxLQUF1QixVQUFVQSxRQUFRLEtBQTFCRSxJQUFJQyxJQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9ELENBQUc7QUFBQTtBQUFBLElBUHhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVFBO0FBRUo7QUFBQ0MsS0FaZVg7QUFBTyxJQUFBVztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJOZnRDYXJkU2tlbGV0b24iLCJOZnRDYXJkIiwiTmZ0R3JpZCIsIml0ZW1zIiwibG9hZGluZyIsIkFycmF5IiwiZnJvbSIsImxlbmd0aCIsIl8iLCJpbmRleCIsIm1hcCIsIm5mdCIsImlkIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTmZ0R3JpZC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmZ0Q2FyZFNrZWxldG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL2ZlZWRiYWNrL05mdENhcmRTa2VsZXRvbic7XG5pbXBvcnQgdHlwZSB7IE5mdCB9IGZyb20gJ0AvY29udHJhY3RzL25mdCc7XG5pbXBvcnQgeyBOZnRDYXJkIH0gZnJvbSAnQC9mZWF0dXJlcy9jYXRhbG9nL2NvbXBvbmVudHMvTmZ0Q2FyZCc7XG5cbmV4cG9ydCBmdW5jdGlvbiBOZnRHcmlkKHsgaXRlbXMsIGxvYWRpbmcgPSBmYWxzZSB9OiB7IGl0ZW1zPzogTmZ0W107IGxvYWRpbmc/OiBib29sZWFuIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2XG4gICAgICBkYXRhLXRlc3RpZD1cIm5mdC1ncmlkXCJcbiAgICAgIGFyaWEtYnVzeT17bG9hZGluZ31cbiAgICAgIGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLXgtNCBnYXAteS02IHBiLTggc206Z2FwLTYgc206cGItMCBsZzpncmlkLWNvbHMtMyBsZzpnYXAteC1bMzRweF0gbGc6Z2FwLXktWzcycHhdIG1heC1zbTpbJj4qOm50aC1jaGlsZChldmVuKV06dHJhbnNsYXRlLXktOFwiXG4gICAgPlxuICAgICAge2xvYWRpbmdcbiAgICAgICAgPyBBcnJheS5mcm9tKHsgbGVuZ3RoOiA5IH0sIChfLCBpbmRleCkgPT4gPE5mdENhcmRTa2VsZXRvbiBrZXk9e2luZGV4fSAvPilcbiAgICAgICAgOiBpdGVtcz8ubWFwKChuZnQsIGluZGV4KSA9PiA8TmZ0Q2FyZCBuZnQ9e25mdH0ga2V5PXtuZnQuaWR9IHByaW9yaXR5PXtpbmRleCA8IDN9IC8+KX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2ZpbGlwZWNhdmFsY2FudGUvRG9jdW1lbnRzL0p1bmdsZUdhbWluZ1Rlc3RlL3NyYy9mZWF0dXJlcy9jYXRhbG9nL2NvbXBvbmVudHMvTmZ0R3JpZC50c3gifQ==