import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=970a124b"; const useState = __vite__cjsImport0_react["useState"];
import { useArtworkRecovery } from "/src/components/media/useArtworkRecovery.ts";
function retrySource(src, attempt) {
  if (!src) return src;
  const [path, hash] = src.split("#");
  return `${path}${src.includes("?") ? "&" : "?"}kurio_retry=${attempt}${hash ? `#${hash}` : ""}`;
}
export function useArtworkSource(src) {
  const [state, setState] = useState();
  if (state && state.src !== src) setState(void 0);
  const current = state?.src === src ? state : void 0;
  const phase = current?.phase ?? "responsive";
  const attempt = current?.attempt ?? 0;
  const base = src?.match(/^(\/images\/nfts\/[^/]+)-800\.webp$/)?.[1];
  useArtworkRecovery(phase === "unavailable" && Boolean(src && !src.startsWith("data:")), () => {
    setState({ src, phase: "retry", attempt: attempt + 1 });
  });
  const fail = (failedSource) => {
    const fallback = base && phase === "responsive" && /\.avif(?:[?#]|$)/.test(failedSource);
    const canRetry = src && !src.startsWith("data:") && phase !== "retry";
    const nextPhase = fallback ? "webp" : canRetry ? "retry" : "unavailable";
    setState({ src, phase: nextPhase, attempt: nextPhase === "retry" ? attempt + 1 : attempt });
  };
  return {
    src: phase === "retry" ? retrySource(src, attempt) : src,
    base: phase === "responsive" || phase === "webp" ? base : void 0,
    avif: phase === "responsive",
    unavailable: !src || phase === "unavailable",
    fail
  };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZUFydHdvcmtTb3VyY2UudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5cbmltcG9ydCB7IHVzZUFydHdvcmtSZWNvdmVyeSB9IGZyb20gJ0AvY29tcG9uZW50cy9tZWRpYS91c2VBcnR3b3JrUmVjb3ZlcnknO1xuXG50eXBlIEFydHdvcmtQaGFzZSA9ICdyZXNwb25zaXZlJyB8ICd3ZWJwJyB8ICdyZXRyeScgfCAndW5hdmFpbGFibGUnO1xuaW50ZXJmYWNlIEFydHdvcmtTdGF0ZSB7XG4gIHNyYzogc3RyaW5nIHwgdW5kZWZpbmVkO1xuICBwaGFzZTogQXJ0d29ya1BoYXNlO1xuICBhdHRlbXB0OiBudW1iZXI7XG59XG5cbmZ1bmN0aW9uIHJldHJ5U291cmNlKHNyYzogc3RyaW5nIHwgdW5kZWZpbmVkLCBhdHRlbXB0OiBudW1iZXIpIHtcbiAgaWYgKCFzcmMpIHJldHVybiBzcmM7XG4gIGNvbnN0IFtwYXRoLCBoYXNoXSA9IHNyYy5zcGxpdCgnIycpO1xuICByZXR1cm4gYCR7cGF0aH0ke3NyYy5pbmNsdWRlcygnPycpID8gJyYnIDogJz8nfWt1cmlvX3JldHJ5PSR7YXR0ZW1wdH0ke2hhc2ggPyBgIyR7aGFzaH1gIDogJyd9YDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHVzZUFydHdvcmtTb3VyY2Uoc3JjOiBzdHJpbmcgfCB1bmRlZmluZWQpIHtcbiAgY29uc3QgW3N0YXRlLCBzZXRTdGF0ZV0gPSB1c2VTdGF0ZTxBcnR3b3JrU3RhdGU+KCk7XG4gIGlmIChzdGF0ZSAmJiBzdGF0ZS5zcmMgIT09IHNyYykgc2V0U3RhdGUodW5kZWZpbmVkKTtcbiAgY29uc3QgY3VycmVudCA9IHN0YXRlPy5zcmMgPT09IHNyYyA/IHN0YXRlIDogdW5kZWZpbmVkO1xuICBjb25zdCBwaGFzZSA9IGN1cnJlbnQ/LnBoYXNlID8/ICdyZXNwb25zaXZlJztcbiAgY29uc3QgYXR0ZW1wdCA9IGN1cnJlbnQ/LmF0dGVtcHQgPz8gMDtcbiAgY29uc3QgYmFzZSA9IHNyYz8ubWF0Y2goL14oXFwvaW1hZ2VzXFwvbmZ0c1xcL1teL10rKS04MDBcXC53ZWJwJC8pPy5bMV07XG4gIHVzZUFydHdvcmtSZWNvdmVyeShwaGFzZSA9PT0gJ3VuYXZhaWxhYmxlJyAmJiBCb29sZWFuKHNyYyAmJiAhc3JjLnN0YXJ0c1dpdGgoJ2RhdGE6JykpLCAoKSA9PiB7XG4gICAgc2V0U3RhdGUoeyBzcmMsIHBoYXNlOiAncmV0cnknLCBhdHRlbXB0OiBhdHRlbXB0ICsgMSB9KTtcbiAgfSk7XG4gIGNvbnN0IGZhaWwgPSAoZmFpbGVkU291cmNlOiBzdHJpbmcpID0+IHtcbiAgICBjb25zdCBmYWxsYmFjayA9IGJhc2UgJiYgcGhhc2UgPT09ICdyZXNwb25zaXZlJyAmJiAvXFwuYXZpZig/Ols/I118JCkvLnRlc3QoZmFpbGVkU291cmNlKTtcbiAgICBjb25zdCBjYW5SZXRyeSA9IHNyYyAmJiAhc3JjLnN0YXJ0c1dpdGgoJ2RhdGE6JykgJiYgcGhhc2UgIT09ICdyZXRyeSc7XG4gICAgY29uc3QgbmV4dFBoYXNlID0gZmFsbGJhY2sgPyAnd2VicCcgOiBjYW5SZXRyeSA/ICdyZXRyeScgOiAndW5hdmFpbGFibGUnO1xuICAgIHNldFN0YXRlKHsgc3JjLCBwaGFzZTogbmV4dFBoYXNlLCBhdHRlbXB0OiBuZXh0UGhhc2UgPT09ICdyZXRyeScgPyBhdHRlbXB0ICsgMSA6IGF0dGVtcHQgfSk7XG4gIH07XG4gIHJldHVybiB7XG4gICAgc3JjOiBwaGFzZSA9PT0gJ3JldHJ5JyA/IHJldHJ5U291cmNlKHNyYywgYXR0ZW1wdCkgOiBzcmMsXG4gICAgYmFzZTogcGhhc2UgPT09ICdyZXNwb25zaXZlJyB8fCBwaGFzZSA9PT0gJ3dlYnAnID8gYmFzZSA6IHVuZGVmaW5lZCxcbiAgICBhdmlmOiBwaGFzZSA9PT0gJ3Jlc3BvbnNpdmUnLFxuICAgIHVuYXZhaWxhYmxlOiAhc3JjIHx8IHBoYXNlID09PSAndW5hdmFpbGFibGUnLFxuICAgIGZhaWwsXG4gIH07XG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsZ0JBQWdCO0FBRXpCLFNBQVMsMEJBQTBCO0FBU25DLFNBQVMsWUFBWSxLQUF5QixTQUFpQjtBQUM3RCxNQUFJLENBQUMsSUFBSyxRQUFPO0FBQ2pCLFFBQU0sQ0FBQyxNQUFNLElBQUksSUFBSSxJQUFJLE1BQU0sR0FBRztBQUNsQyxTQUFPLEdBQUcsSUFBSSxHQUFHLElBQUksU0FBUyxHQUFHLElBQUksTUFBTSxHQUFHLGVBQWUsT0FBTyxHQUFHLE9BQU8sSUFBSSxJQUFJLEtBQUssRUFBRTtBQUMvRjtBQUVPLGdCQUFTLGlCQUFpQixLQUF5QjtBQUN4RCxRQUFNLENBQUMsT0FBTyxRQUFRLElBQUksU0FBdUI7QUFDakQsTUFBSSxTQUFTLE1BQU0sUUFBUSxJQUFLLFVBQVMsTUFBUztBQUNsRCxRQUFNLFVBQVUsT0FBTyxRQUFRLE1BQU0sUUFBUTtBQUM3QyxRQUFNLFFBQVEsU0FBUyxTQUFTO0FBQ2hDLFFBQU0sVUFBVSxTQUFTLFdBQVc7QUFDcEMsUUFBTSxPQUFPLEtBQUssTUFBTSxxQ0FBcUMsSUFBSSxDQUFDO0FBQ2xFLHFCQUFtQixVQUFVLGlCQUFpQixRQUFRLE9BQU8sQ0FBQyxJQUFJLFdBQVcsT0FBTyxDQUFDLEdBQUcsTUFBTTtBQUM1RixhQUFTLEVBQUUsS0FBSyxPQUFPLFNBQVMsU0FBUyxVQUFVLEVBQUUsQ0FBQztBQUFBLEVBQ3hELENBQUM7QUFDRCxRQUFNLE9BQU8sQ0FBQyxpQkFBeUI7QUFDckMsVUFBTSxXQUFXLFFBQVEsVUFBVSxnQkFBZ0IsbUJBQW1CLEtBQUssWUFBWTtBQUN2RixVQUFNLFdBQVcsT0FBTyxDQUFDLElBQUksV0FBVyxPQUFPLEtBQUssVUFBVTtBQUM5RCxVQUFNLFlBQVksV0FBVyxTQUFTLFdBQVcsVUFBVTtBQUMzRCxhQUFTLEVBQUUsS0FBSyxPQUFPLFdBQVcsU0FBUyxjQUFjLFVBQVUsVUFBVSxJQUFJLFFBQVEsQ0FBQztBQUFBLEVBQzVGO0FBQ0EsU0FBTztBQUFBLElBQ0wsS0FBSyxVQUFVLFVBQVUsWUFBWSxLQUFLLE9BQU8sSUFBSTtBQUFBLElBQ3JELE1BQU0sVUFBVSxnQkFBZ0IsVUFBVSxTQUFTLE9BQU87QUFBQSxJQUMxRCxNQUFNLFVBQVU7QUFBQSxJQUNoQixhQUFhLENBQUMsT0FBTyxVQUFVO0FBQUEsSUFDL0I7QUFBQSxFQUNGO0FBQ0Y7IiwibmFtZXMiOltdfQ==