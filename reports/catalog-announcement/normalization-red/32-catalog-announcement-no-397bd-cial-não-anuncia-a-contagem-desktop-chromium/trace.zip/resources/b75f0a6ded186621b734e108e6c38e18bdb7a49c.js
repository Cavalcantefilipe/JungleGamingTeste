import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=970a124b"; const useEffect = __vite__cjsImport0_react["useEffect"];
export function useArtworkRecovery(enabled, retry) {
  useEffect(() => {
    if (!enabled) return;
    const resume = () => {
      if (navigator.onLine && document.visibilityState === "visible") retry();
    };
    window.addEventListener("online", resume);
    window.addEventListener("focus", resume);
    document.addEventListener("visibilitychange", resume);
    return () => {
      window.removeEventListener("online", resume);
      window.removeEventListener("focus", resume);
      document.removeEventListener("visibilitychange", resume);
    };
  }, [enabled, retry]);
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZUFydHdvcmtSZWNvdmVyeS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VBcnR3b3JrUmVjb3ZlcnkoZW5hYmxlZDogYm9vbGVhbiwgcmV0cnk6ICgpID0+IHZvaWQpIHtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWVuYWJsZWQpIHJldHVybjtcbiAgICBjb25zdCByZXN1bWUgPSAoKSA9PiB7XG4gICAgICBpZiAobmF2aWdhdG9yLm9uTGluZSAmJiBkb2N1bWVudC52aXNpYmlsaXR5U3RhdGUgPT09ICd2aXNpYmxlJykgcmV0cnkoKTtcbiAgICB9O1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdvbmxpbmUnLCByZXN1bWUpO1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdmb2N1cycsIHJlc3VtZSk7XG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigndmlzaWJpbGl0eWNoYW5nZScsIHJlc3VtZSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdvbmxpbmUnLCByZXN1bWUpO1xuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2ZvY3VzJywgcmVzdW1lKTtcbiAgICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Zpc2liaWxpdHljaGFuZ2UnLCByZXN1bWUpO1xuICAgIH07XG4gIH0sIFtlbmFibGVkLCByZXRyeV0pO1xufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLGlCQUFpQjtBQUVuQixnQkFBUyxtQkFBbUIsU0FBa0IsT0FBbUI7QUFDdEUsWUFBVSxNQUFNO0FBQ2QsUUFBSSxDQUFDLFFBQVM7QUFDZCxVQUFNLFNBQVMsTUFBTTtBQUNuQixVQUFJLFVBQVUsVUFBVSxTQUFTLG9CQUFvQixVQUFXLE9BQU07QUFBQSxJQUN4RTtBQUNBLFdBQU8saUJBQWlCLFVBQVUsTUFBTTtBQUN4QyxXQUFPLGlCQUFpQixTQUFTLE1BQU07QUFDdkMsYUFBUyxpQkFBaUIsb0JBQW9CLE1BQU07QUFDcEQsV0FBTyxNQUFNO0FBQ1gsYUFBTyxvQkFBb0IsVUFBVSxNQUFNO0FBQzNDLGFBQU8sb0JBQW9CLFNBQVMsTUFBTTtBQUMxQyxlQUFTLG9CQUFvQixvQkFBb0IsTUFBTTtBQUFBLElBQ3pEO0FBQUEsRUFDRixHQUFHLENBQUMsU0FBUyxLQUFLLENBQUM7QUFDckI7IiwibmFtZXMiOltdfQ==