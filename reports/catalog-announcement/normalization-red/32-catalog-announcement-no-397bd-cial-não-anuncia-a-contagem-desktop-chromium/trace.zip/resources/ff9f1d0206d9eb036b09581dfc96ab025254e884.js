import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/CatalogToolbar.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { useRouterState } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=970a124b";
import { Input } from "/src/components/ui/input.tsx";
import { CatalogSortSelect } from "/src/features/catalog/components/CatalogSortSelect.tsx";
import { CatalogTabs } from "/src/features/catalog/components/CatalogTabs.tsx";
import { cn } from "/src/lib/cn.ts";
export function CatalogToolbar({
  search,
  change
}) {
  _s();
  const hash = useRouterState({ select: (state) => state.location.hash });
  return /* @__PURE__ */ jsxDEV("div", { className: "mb-2 space-y-4 md:mb-[26px]", children: [
    /* @__PURE__ */ jsxDEV(
      Input,
      {
        id: "busca",
        type: "search",
        "aria-label": "Buscar NFTs",
        placeholder: "Buscar NFTs, coleções e criadores...",
        value: search.q,
        onChange: (event) => {
          change({ q: event.target.value });
        },
        className: cn("hidden h-11", (search.q || hash === "busca") && "md:block")
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogToolbar.tsx",
        lineNumber: 19,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center justify-between gap-4", children: [
      /* @__PURE__ */ jsxDEV(
        CatalogTabs,
        {
          selected: search.tab,
          change: (tab) => {
            change({ tab });
          }
        },
        void 0,
        false,
        {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogToolbar.tsx",
          lineNumber: 31,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "hidden md:block", children: /* @__PURE__ */ jsxDEV(
        CatalogSortSelect,
        {
          value: search.sort,
          change: (sort) => {
            change({ sort });
          }
        },
        void 0,
        false,
        {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogToolbar.tsx",
          lineNumber: 38,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogToolbar.tsx",
        lineNumber: 37,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogToolbar.tsx",
      lineNumber: 30,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogToolbar.tsx",
    lineNumber: 18,
    columnNumber: 5
  }, this);
}
_s(CatalogToolbar, "5vZ4BHikXU9Wc7fAIvKEZdpsBms=", false, function() {
  return [useRouterState];
});
_c = CatalogToolbar;
var _c;
$RefreshReg$(_c, "CatalogToolbar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogToolbar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogToolbar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogToolbar.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JNOztBQWxCTixTQUFTQSxzQkFBc0I7QUFFL0IsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0MsbUJBQW1CO0FBRTVCLFNBQVNDLFVBQVU7QUFFWixnQkFBU0MsZUFBZTtBQUFBLEVBQzdCQztBQUFBQSxFQUNBQztBQUlGLEdBQUc7QUFBQUMsS0FBQTtBQUNELFFBQU1DLE9BQU9ULGVBQWUsRUFBRVUsUUFBUUEsQ0FBQ0MsVUFBVUEsTUFBTUMsU0FBU0gsS0FBSyxDQUFDO0FBQ3RFLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLElBQUc7QUFBQSxRQUNILE1BQUs7QUFBQSxRQUNMLGNBQVc7QUFBQSxRQUNYLGFBQVk7QUFBQSxRQUNaLE9BQU9ILE9BQU9PO0FBQUFBLFFBQ2QsVUFBVSxDQUFDQyxVQUFVO0FBQ25CUCxpQkFBTyxFQUFFTSxHQUFHQyxNQUFNQyxPQUFPQyxNQUFNLENBQUM7QUFBQSxRQUNsQztBQUFBLFFBQ0EsV0FBV1osR0FBRyxnQkFBZ0JFLE9BQU9PLEtBQUtKLFNBQVMsWUFBWSxVQUFVO0FBQUE7QUFBQSxNQVQzRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFTNkU7QUFBQSxJQUU3RSx1QkFBQyxTQUFJLFdBQVUscURBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsVUFBVUgsT0FBT1c7QUFBQUEsVUFDakIsUUFBUSxDQUFDQSxRQUFRO0FBQ2ZWLG1CQUFPLEVBQUVVLElBQUksQ0FBQztBQUFBLFVBQ2hCO0FBQUE7QUFBQSxRQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUlJO0FBQUEsTUFFSix1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU9YLE9BQU9ZO0FBQUFBLFVBQ2QsUUFBUSxDQUFDQSxTQUFTO0FBQ2hCWCxtQkFBTyxFQUFFVyxLQUFLLENBQUM7QUFBQSxVQUNqQjtBQUFBO0FBQUEsUUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJSSxLQUxOO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLFNBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWVBO0FBQUEsT0EzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRCQTtBQUVKO0FBQUNWLEdBdkNlSCxnQkFBYztBQUFBLFVBT2ZMLGNBQWM7QUFBQTtBQUFBLEtBUGJLO0FBQWMsSUFBQWM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlUm91dGVyU3RhdGUiLCJJbnB1dCIsIkNhdGFsb2dTb3J0U2VsZWN0IiwiQ2F0YWxvZ1RhYnMiLCJjbiIsIkNhdGFsb2dUb29sYmFyIiwic2VhcmNoIiwiY2hhbmdlIiwiX3MiLCJoYXNoIiwic2VsZWN0Iiwic3RhdGUiLCJsb2NhdGlvbiIsInEiLCJldmVudCIsInRhcmdldCIsInZhbHVlIiwidGFiIiwic29ydCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNhdGFsb2dUb29sYmFyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VSb3V0ZXJTdGF0ZSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInO1xuXG5pbXBvcnQgeyBJbnB1dCB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9pbnB1dCc7XG5pbXBvcnQgeyBDYXRhbG9nU29ydFNlbGVjdCB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy9jb21wb25lbnRzL0NhdGFsb2dTb3J0U2VsZWN0JztcbmltcG9ydCB7IENhdGFsb2dUYWJzIH0gZnJvbSAnQC9mZWF0dXJlcy9jYXRhbG9nL2NvbXBvbmVudHMvQ2F0YWxvZ1RhYnMnO1xuaW1wb3J0IHR5cGUgeyBDYXRhbG9nU2VhcmNoIH0gZnJvbSAnQC9mZWF0dXJlcy9jYXRhbG9nL3NlYXJjaC1wYXJhbXMnO1xuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi9jbic7XG5cbmV4cG9ydCBmdW5jdGlvbiBDYXRhbG9nVG9vbGJhcih7XG4gIHNlYXJjaCxcbiAgY2hhbmdlLFxufToge1xuICBzZWFyY2g6IENhdGFsb2dTZWFyY2g7XG4gIGNoYW5nZTogKHZhbHVlOiBQYXJ0aWFsPENhdGFsb2dTZWFyY2g+KSA9PiB2b2lkO1xufSkge1xuICBjb25zdCBoYXNoID0gdXNlUm91dGVyU3RhdGUoeyBzZWxlY3Q6IChzdGF0ZSkgPT4gc3RhdGUubG9jYXRpb24uaGFzaCB9KTtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTIgc3BhY2UteS00IG1kOm1iLVsyNnB4XVwiPlxuICAgICAgPElucHV0XG4gICAgICAgIGlkPVwiYnVzY2FcIlxuICAgICAgICB0eXBlPVwic2VhcmNoXCJcbiAgICAgICAgYXJpYS1sYWJlbD1cIkJ1c2NhciBORlRzXCJcbiAgICAgICAgcGxhY2Vob2xkZXI9XCJCdXNjYXIgTkZUcywgY29sZcOnw7VlcyBlIGNyaWFkb3Jlcy4uLlwiXG4gICAgICAgIHZhbHVlPXtzZWFyY2gucX1cbiAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4ge1xuICAgICAgICAgIGNoYW5nZSh7IHE6IGV2ZW50LnRhcmdldC52YWx1ZSB9KTtcbiAgICAgICAgfX1cbiAgICAgICAgY2xhc3NOYW1lPXtjbignaGlkZGVuIGgtMTEnLCAoc2VhcmNoLnEgfHwgaGFzaCA9PT0gJ2J1c2NhJykgJiYgJ21kOmJsb2NrJyl9XG4gICAgICAvPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XG4gICAgICAgIDxDYXRhbG9nVGFic1xuICAgICAgICAgIHNlbGVjdGVkPXtzZWFyY2gudGFifVxuICAgICAgICAgIGNoYW5nZT17KHRhYikgPT4ge1xuICAgICAgICAgICAgY2hhbmdlKHsgdGFiIH0pO1xuICAgICAgICAgIH19XG4gICAgICAgIC8+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIG1kOmJsb2NrXCI+XG4gICAgICAgICAgPENhdGFsb2dTb3J0U2VsZWN0XG4gICAgICAgICAgICB2YWx1ZT17c2VhcmNoLnNvcnR9XG4gICAgICAgICAgICBjaGFuZ2U9eyhzb3J0KSA9PiB7XG4gICAgICAgICAgICAgIGNoYW5nZSh7IHNvcnQgfSk7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9maWxpcGVjYXZhbGNhbnRlL0RvY3VtZW50cy9KdW5nbGVHYW1pbmdUZXN0ZS9zcmMvZmVhdHVyZXMvY2F0YWxvZy9jb21wb25lbnRzL0NhdGFsb2dUb29sYmFyLnRzeCJ9