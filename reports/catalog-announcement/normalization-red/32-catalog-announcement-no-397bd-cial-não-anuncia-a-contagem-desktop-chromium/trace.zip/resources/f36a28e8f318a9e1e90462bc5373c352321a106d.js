import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/Pagination.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Button } from "/src/components/ui/button.tsx";
import { PaginationArrow } from "/src/features/catalog/components/PaginationArrow.tsx";
export function Pagination({ page, totalPages, change }) {
  if (totalPages < 2) return null;
  return /* @__PURE__ */ jsxDEV(
    "nav",
    {
      "aria-label": "Paginação do catálogo",
      className: "mt-10 flex flex-wrap items-center justify-end gap-2",
      children: [
        /* @__PURE__ */ jsxDEV(
          PaginationArrow,
          {
            previous: true,
            disabled: page === 1,
            go: () => {
              change(page - 1);
            }
          },
          void 0,
          false,
          {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/Pagination.tsx",
            lineNumber: 16,
            columnNumber: 7
          },
          this
        ),
        Array.from({ length: totalPages }, (_, index) => index + 1).map(
          (number) => /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "pagination",
              size: "pagination",
              "aria-label": `Página ${number}`,
              "aria-current": page === number ? "page" : void 0,
              onClick: () => {
                change(number);
              },
              children: number
            },
            number,
            false,
            {
              fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/Pagination.tsx",
              lineNumber: 24,
              columnNumber: 7
            },
            this
          )
        ),
        /* @__PURE__ */ jsxDEV(
          PaginationArrow,
          {
            disabled: page >= totalPages,
            go: () => {
              change(page + 1);
            }
          },
          void 0,
          false,
          {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/Pagination.tsx",
            lineNumber: 37,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/Pagination.tsx",
      lineNumber: 12,
      columnNumber: 5
    },
    this
  );
}
_c = Pagination;
var _c;
$RefreshReg$(_c, "Pagination");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/Pagination.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/Pagination.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/Pagination.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZU07QUFmTixTQUFTQSxjQUFjO0FBQ3ZCLFNBQVNDLHVCQUF1QjtBQU96QixnQkFBU0MsV0FBVyxFQUFFQyxNQUFNQyxZQUFZQyxPQUF3QixHQUFHO0FBQ3hFLE1BQUlELGFBQWEsRUFBRyxRQUFPO0FBQzNCLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLGNBQVc7QUFBQSxNQUNYLFdBQVU7QUFBQSxNQUVWO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxVQUFVRCxTQUFTO0FBQUEsWUFDbkIsSUFBSSxNQUFNO0FBQ1JFLHFCQUFPRixPQUFPLENBQUM7QUFBQSxZQUNqQjtBQUFBO0FBQUEsVUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLSTtBQUFBLFFBRUhHLE1BQU1DLEtBQUssRUFBRUMsUUFBUUosV0FBVyxHQUFHLENBQUNLLEdBQUdDLFVBQVVBLFFBQVEsQ0FBQyxFQUFFQztBQUFBQSxVQUFJLENBQUNDLFdBQ2hFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxTQUFRO0FBQUEsY0FDUixNQUFLO0FBQUEsY0FDTCxjQUFZLFVBQVVBLE1BQU07QUFBQSxjQUM1QixnQkFBY1QsU0FBU1MsU0FBUyxTQUFTQztBQUFBQSxjQUN6QyxTQUFTLE1BQU07QUFDYlIsdUJBQU9PLE1BQU07QUFBQSxjQUNmO0FBQUEsY0FFQ0E7QUFBQUE7QUFBQUEsWUFUSUE7QUFBQUEsWUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBV0E7QUFBQSxRQUNEO0FBQUEsUUFDRDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsVUFBVVQsUUFBUUM7QUFBQUEsWUFDbEIsSUFBSSxNQUFNO0FBQ1JDLHFCQUFPRixPQUFPLENBQUM7QUFBQSxZQUNqQjtBQUFBO0FBQUEsVUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJSTtBQUFBO0FBQUE7QUFBQSxJQTdCTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUErQkE7QUFFSjtBQUFDVyxLQXBDZVo7QUFBVSxJQUFBWTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJCdXR0b24iLCJQYWdpbmF0aW9uQXJyb3ciLCJQYWdpbmF0aW9uIiwicGFnZSIsInRvdGFsUGFnZXMiLCJjaGFuZ2UiLCJBcnJheSIsImZyb20iLCJsZW5ndGgiLCJfIiwiaW5kZXgiLCJtYXAiLCJudW1iZXIiLCJ1bmRlZmluZWQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQYWdpbmF0aW9uLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJztcbmltcG9ydCB7IFBhZ2luYXRpb25BcnJvdyB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy9jb21wb25lbnRzL1BhZ2luYXRpb25BcnJvdyc7XG5cbmludGVyZmFjZSBQYWdpbmF0aW9uUHJvcHMge1xuICBwYWdlOiBudW1iZXI7XG4gIHRvdGFsUGFnZXM6IG51bWJlcjtcbiAgY2hhbmdlOiAocGFnZTogbnVtYmVyKSA9PiB2b2lkO1xufVxuZXhwb3J0IGZ1bmN0aW9uIFBhZ2luYXRpb24oeyBwYWdlLCB0b3RhbFBhZ2VzLCBjaGFuZ2UgfTogUGFnaW5hdGlvblByb3BzKSB7XG4gIGlmICh0b3RhbFBhZ2VzIDwgMikgcmV0dXJuIG51bGw7XG4gIHJldHVybiAoXG4gICAgPG5hdlxuICAgICAgYXJpYS1sYWJlbD1cIlBhZ2luYcOnw6NvIGRvIGNhdMOhbG9nb1wiXG4gICAgICBjbGFzc05hbWU9XCJtdC0xMCBmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1lbmQgZ2FwLTJcIlxuICAgID5cbiAgICAgIDxQYWdpbmF0aW9uQXJyb3dcbiAgICAgICAgcHJldmlvdXNcbiAgICAgICAgZGlzYWJsZWQ9e3BhZ2UgPT09IDF9XG4gICAgICAgIGdvPXsoKSA9PiB7XG4gICAgICAgICAgY2hhbmdlKHBhZ2UgLSAxKTtcbiAgICAgICAgfX1cbiAgICAgIC8+XG4gICAgICB7QXJyYXkuZnJvbSh7IGxlbmd0aDogdG90YWxQYWdlcyB9LCAoXywgaW5kZXgpID0+IGluZGV4ICsgMSkubWFwKChudW1iZXIpID0+IChcbiAgICAgICAgPEJ1dHRvblxuICAgICAgICAgIGtleT17bnVtYmVyfVxuICAgICAgICAgIHZhcmlhbnQ9XCJwYWdpbmF0aW9uXCJcbiAgICAgICAgICBzaXplPVwicGFnaW5hdGlvblwiXG4gICAgICAgICAgYXJpYS1sYWJlbD17YFDDoWdpbmEgJHtudW1iZXJ9YH1cbiAgICAgICAgICBhcmlhLWN1cnJlbnQ9e3BhZ2UgPT09IG51bWJlciA/ICdwYWdlJyA6IHVuZGVmaW5lZH1cbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICBjaGFuZ2UobnVtYmVyKTtcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAge251bWJlcn1cbiAgICAgICAgPC9CdXR0b24+XG4gICAgICApKX1cbiAgICAgIDxQYWdpbmF0aW9uQXJyb3dcbiAgICAgICAgZGlzYWJsZWQ9e3BhZ2UgPj0gdG90YWxQYWdlc31cbiAgICAgICAgZ289eygpID0+IHtcbiAgICAgICAgICBjaGFuZ2UocGFnZSArIDEpO1xuICAgICAgICB9fVxuICAgICAgLz5cbiAgICA8L25hdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2ZpbGlwZWNhdmFsY2FudGUvRG9jdW1lbnRzL0p1bmdsZUdhbWluZ1Rlc3RlL3NyYy9mZWF0dXJlcy9jYXRhbG9nL2NvbXBvbmVudHMvUGFnaW5hdGlvbi50c3gifQ==