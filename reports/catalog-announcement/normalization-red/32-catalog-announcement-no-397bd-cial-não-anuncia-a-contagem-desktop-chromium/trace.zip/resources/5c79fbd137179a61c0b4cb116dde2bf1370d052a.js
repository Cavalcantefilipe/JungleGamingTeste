import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/CatalogResults.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { CatalogAnnouncement } from "/src/features/catalog/components/CatalogAnnouncement.tsx?t=1792850937924";
import { CatalogItems } from "/src/features/catalog/components/CatalogItems.tsx";
import { CatalogToolbar } from "/src/features/catalog/components/CatalogToolbar.tsx";
import { Pagination } from "/src/features/catalog/components/Pagination.tsx";
export function CatalogResults({
  search,
  query,
  navigation
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
    /* @__PURE__ */ jsxDEV(CatalogToolbar, { search, change: navigation.setFilter }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogResults.tsx",
      lineNumber: 20,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CatalogAnnouncement, { query, announcement: navigation.announcement }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogResults.tsx",
      lineNumber: 21,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        id: "catalog-results",
        role: "tabpanel",
        "aria-labelledby": `catalog-tab-${search.tab}`,
        tabIndex: 0,
        children: /* @__PURE__ */ jsxDEV(CatalogItems, { query, clear: navigation.clear }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogResults.tsx",
          lineNumber: 28,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogResults.tsx",
        lineNumber: 22,
        columnNumber: 7
      },
      this
    ),
    query.data && /* @__PURE__ */ jsxDEV(
      Pagination,
      {
        page: search.page,
        totalPages: query.data.totalPages,
        change: navigation.setPage
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogResults.tsx",
        lineNumber: 31,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogResults.tsx",
    lineNumber: 19,
    columnNumber: 5
  }, this);
}
_c = CatalogResults;
var _c;
$RefreshReg$(_c, "CatalogResults");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogResults.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogResults.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogResults.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUJNO0FBbkJOLFNBQVNBLDJCQUEyQjtBQUNwQyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLGtCQUFrQjtBQUtwQixnQkFBU0MsZUFBZTtBQUFBLEVBQzdCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUtGLEdBQUc7QUFDRCxTQUNFLHVCQUFDLFNBQUksV0FBVSxXQUNiO0FBQUEsMkJBQUMsa0JBQWUsUUFBZ0IsUUFBUUEsV0FBV0MsYUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2RDtBQUFBLElBQzdELHVCQUFDLHVCQUFvQixPQUFjLGNBQWNELFdBQVdFLGdCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlFO0FBQUEsSUFDekU7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLElBQUc7QUFBQSxRQUNILE1BQUs7QUFBQSxRQUNMLG1CQUFpQixlQUFlSixPQUFPSyxHQUFHO0FBQUEsUUFDMUMsVUFBVTtBQUFBLFFBRVYsaUNBQUMsZ0JBQWEsT0FBYyxPQUFPSCxXQUFXSSxTQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9EO0FBQUE7QUFBQSxNQU50RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFPQTtBQUFBLElBQ0NMLE1BQU1NLFFBQ0w7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQU1QLE9BQU9RO0FBQUFBLFFBQ2IsWUFBWVAsTUFBTU0sS0FBS0U7QUFBQUEsUUFDdkIsUUFBUVAsV0FBV1E7QUFBQUE7QUFBQUEsTUFIckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRzZCO0FBQUEsT0FmakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtCQTtBQUVKO0FBQUNDLEtBOUJlWjtBQUFjLElBQUFZO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkNhdGFsb2dBbm5vdW5jZW1lbnQiLCJDYXRhbG9nSXRlbXMiLCJDYXRhbG9nVG9vbGJhciIsIlBhZ2luYXRpb24iLCJDYXRhbG9nUmVzdWx0cyIsInNlYXJjaCIsInF1ZXJ5IiwibmF2aWdhdGlvbiIsInNldEZpbHRlciIsImFubm91bmNlbWVudCIsInRhYiIsImNsZWFyIiwiZGF0YSIsInBhZ2UiLCJ0b3RhbFBhZ2VzIiwic2V0UGFnZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNhdGFsb2dSZXN1bHRzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDYXRhbG9nQW5ub3VuY2VtZW50IH0gZnJvbSAnQC9mZWF0dXJlcy9jYXRhbG9nL2NvbXBvbmVudHMvQ2F0YWxvZ0Fubm91bmNlbWVudCc7XG5pbXBvcnQgeyBDYXRhbG9nSXRlbXMgfSBmcm9tICdAL2ZlYXR1cmVzL2NhdGFsb2cvY29tcG9uZW50cy9DYXRhbG9nSXRlbXMnO1xuaW1wb3J0IHsgQ2F0YWxvZ1Rvb2xiYXIgfSBmcm9tICdAL2ZlYXR1cmVzL2NhdGFsb2cvY29tcG9uZW50cy9DYXRhbG9nVG9vbGJhcic7XG5pbXBvcnQgeyBQYWdpbmF0aW9uIH0gZnJvbSAnQC9mZWF0dXJlcy9jYXRhbG9nL2NvbXBvbmVudHMvUGFnaW5hdGlvbic7XG5pbXBvcnQgdHlwZSB7IHVzZUNhdGFsb2dRdWVyeSB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy9xdWVyaWVzJztcbmltcG9ydCB0eXBlIHsgQ2F0YWxvZ1NlYXJjaCB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy9zZWFyY2gtcGFyYW1zJztcbmltcG9ydCB0eXBlIHsgdXNlQ2F0YWxvZ05hdmlnYXRpb24gfSBmcm9tICdAL2ZlYXR1cmVzL2NhdGFsb2cvdXNlQ2F0YWxvZ05hdmlnYXRpb24nO1xuXG5leHBvcnQgZnVuY3Rpb24gQ2F0YWxvZ1Jlc3VsdHMoe1xuICBzZWFyY2gsXG4gIHF1ZXJ5LFxuICBuYXZpZ2F0aW9uLFxufToge1xuICBzZWFyY2g6IENhdGFsb2dTZWFyY2g7XG4gIHF1ZXJ5OiBSZXR1cm5UeXBlPHR5cGVvZiB1c2VDYXRhbG9nUXVlcnk+O1xuICBuYXZpZ2F0aW9uOiBSZXR1cm5UeXBlPHR5cGVvZiB1c2VDYXRhbG9nTmF2aWdhdGlvbj47XG59KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wXCI+XG4gICAgICA8Q2F0YWxvZ1Rvb2xiYXIgc2VhcmNoPXtzZWFyY2h9IGNoYW5nZT17bmF2aWdhdGlvbi5zZXRGaWx0ZXJ9IC8+XG4gICAgICA8Q2F0YWxvZ0Fubm91bmNlbWVudCBxdWVyeT17cXVlcnl9IGFubm91bmNlbWVudD17bmF2aWdhdGlvbi5hbm5vdW5jZW1lbnR9IC8+XG4gICAgICA8ZGl2XG4gICAgICAgIGlkPVwiY2F0YWxvZy1yZXN1bHRzXCJcbiAgICAgICAgcm9sZT1cInRhYnBhbmVsXCJcbiAgICAgICAgYXJpYS1sYWJlbGxlZGJ5PXtgY2F0YWxvZy10YWItJHtzZWFyY2gudGFifWB9XG4gICAgICAgIHRhYkluZGV4PXswfVxuICAgICAgPlxuICAgICAgICA8Q2F0YWxvZ0l0ZW1zIHF1ZXJ5PXtxdWVyeX0gY2xlYXI9e25hdmlnYXRpb24uY2xlYXJ9IC8+XG4gICAgICA8L2Rpdj5cbiAgICAgIHtxdWVyeS5kYXRhICYmIChcbiAgICAgICAgPFBhZ2luYXRpb25cbiAgICAgICAgICBwYWdlPXtzZWFyY2gucGFnZX1cbiAgICAgICAgICB0b3RhbFBhZ2VzPXtxdWVyeS5kYXRhLnRvdGFsUGFnZXN9XG4gICAgICAgICAgY2hhbmdlPXtuYXZpZ2F0aW9uLnNldFBhZ2V9XG4gICAgICAgIC8+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvZmlsaXBlY2F2YWxjYW50ZS9Eb2N1bWVudHMvSnVuZ2xlR2FtaW5nVGVzdGUvc3JjL2ZlYXR1cmVzL2NhdGFsb2cvY29tcG9uZW50cy9DYXRhbG9nUmVzdWx0cy50c3gifQ==