import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/feedback/EmptyState.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
export function EmptyState({
  title,
  description,
  action
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-72 flex-col items-center justify-center gap-5 rounded-xl border border-dashed border-border-soft p-6 text-center", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "text-title font-bold", children: title }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/feedback/EmptyState.tsx",
      lineNumber: 14,
      columnNumber: 7
    }, this),
    description && /* @__PURE__ */ jsxDEV("p", { className: "max-w-md text-sm text-text-secondary", children: description }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/feedback/EmptyState.tsx",
      lineNumber: 15,
      columnNumber: 23
    }, this),
    action
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/feedback/EmptyState.tsx",
    lineNumber: 13,
    columnNumber: 5
  }, this);
}
_c = EmptyState;
var _c;
$RefreshReg$(_c, "EmptyState");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/feedback/EmptyState.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/feedback/EmptyState.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/components/feedback/EmptyState.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYU07QUFYQyxnQkFBU0EsV0FBVztBQUFBLEVBQ3pCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUtGLEdBQUc7QUFDRCxTQUNFLHVCQUFDLFNBQUksV0FBVSwrSEFDYjtBQUFBLDJCQUFDLFFBQUcsV0FBVSx3QkFBd0JGLG1CQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRDO0FBQUEsSUFDM0NDLGVBQWUsdUJBQUMsT0FBRSxXQUFVLHdDQUF3Q0EseUJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUU7QUFBQSxJQUNoRkM7QUFBQUEsT0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBSUE7QUFFSjtBQUFDQyxLQWhCZUo7QUFBVSxJQUFBSTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJFbXB0eVN0YXRlIiwidGl0bGUiLCJkZXNjcmlwdGlvbiIsImFjdGlvbiIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkVtcHR5U3RhdGUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgUmVhY3ROb2RlIH0gZnJvbSAncmVhY3QnO1xuXG5leHBvcnQgZnVuY3Rpb24gRW1wdHlTdGF0ZSh7XG4gIHRpdGxlLFxuICBkZXNjcmlwdGlvbixcbiAgYWN0aW9uLFxufToge1xuICB0aXRsZTogc3RyaW5nO1xuICBkZXNjcmlwdGlvbj86IHN0cmluZztcbiAgYWN0aW9uPzogUmVhY3ROb2RlO1xufSkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtaW4taC03MiBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWRhc2hlZCBib3JkZXItYm9yZGVyLXNvZnQgcC02IHRleHQtY2VudGVyXCI+XG4gICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC10aXRsZSBmb250LWJvbGRcIj57dGl0bGV9PC9oMj5cbiAgICAgIHtkZXNjcmlwdGlvbiAmJiA8cCBjbGFzc05hbWU9XCJtYXgtdy1tZCB0ZXh0LXNtIHRleHQtdGV4dC1zZWNvbmRhcnlcIj57ZGVzY3JpcHRpb259PC9wPn1cbiAgICAgIHthY3Rpb259XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9maWxpcGVjYXZhbGNhbnRlL0RvY3VtZW50cy9KdW5nbGVHYW1pbmdUZXN0ZS9zcmMvY29tcG9uZW50cy9mZWVkYmFjay9FbXB0eVN0YXRlLnRzeCJ9