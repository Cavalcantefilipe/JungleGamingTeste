import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/HeroPagination.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
export function HeroPagination({ items, selected, select }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "absolute right-0 bottom-0 flex min-[390px]:right-auto min-[390px]:left-1/2 min-[390px]:-translate-x-1/2 md:bottom-10 md:left-[64%] md:gap-2 lg:left-[60%] xl:left-[56%]", children: items.map(
    (item, index) => /* @__PURE__ */ jsxDEV(
      "button",
      {
        "aria-label": `Mostrar destaque ${index + 1}`,
        "aria-pressed": selected === index,
        onClick: () => {
          select(index);
        },
        className: "flex size-11 cursor-pointer items-center justify-center rounded-full md:size-4",
        children: /* @__PURE__ */ jsxDEV(
          "span",
          {
            className: `size-1.5 translate-y-3.5 rounded-full md:translate-y-0 ${selected === index ? "bg-primary" : "bg-border-soft"}`
          },
          void 0,
          false,
          {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroPagination.tsx",
            lineNumber: 21,
            columnNumber: 11
          },
          this
        )
      },
      item.id,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroPagination.tsx",
        lineNumber: 12,
        columnNumber: 7
      },
      this
    )
  ) }, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroPagination.tsx",
    lineNumber: 10,
    columnNumber: 5
  }, this);
}
_c = HeroPagination;
var _c;
$RefreshReg$(_c, "HeroPagination");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroPagination.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroPagination.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroPagination.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JVO0FBYkgsZ0JBQVNBLGVBQWUsRUFBRUMsT0FBT0MsVUFBVUMsT0FBNEIsR0FBRztBQUMvRSxTQUNFLHVCQUFDLFNBQUksV0FBVSwyS0FDWkYsZ0JBQU1HO0FBQUFBLElBQUksQ0FBQ0MsTUFBTUMsVUFDaEI7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUVDLGNBQVksb0JBQW9CQSxRQUFRLENBQUM7QUFBQSxRQUN6QyxnQkFBY0osYUFBYUk7QUFBQUEsUUFDM0IsU0FBUyxNQUFNO0FBQ2JILGlCQUFPRyxLQUFLO0FBQUEsUUFDZDtBQUFBLFFBQ0EsV0FBVTtBQUFBLFFBRVY7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVcsMERBQTBESixhQUFhSSxRQUFRLGVBQWUsZ0JBQWdCO0FBQUE7QUFBQSxVQUQzSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFDOEg7QUFBQTtBQUFBLE1BVHpIRCxLQUFLRTtBQUFBQSxNQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFZQTtBQUFBLEVBQ0QsS0FmSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ0JBO0FBRUo7QUFBQ0MsS0FwQmVSO0FBQWMsSUFBQVE7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiSGVyb1BhZ2luYXRpb24iLCJpdGVtcyIsInNlbGVjdGVkIiwic2VsZWN0IiwibWFwIiwiaXRlbSIsImluZGV4IiwiaWQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJIZXJvUGFnaW5hdGlvbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBOZnQgfSBmcm9tICdAL2NvbnRyYWN0cy9uZnQnO1xuXG5pbnRlcmZhY2UgSGVyb1BhZ2luYXRpb25Qcm9wcyB7XG4gIGl0ZW1zOiBOZnRbXTtcbiAgc2VsZWN0ZWQ6IG51bWJlcjtcbiAgc2VsZWN0OiAoaW5kZXg6IG51bWJlcikgPT4gdm9pZDtcbn1cbmV4cG9ydCBmdW5jdGlvbiBIZXJvUGFnaW5hdGlvbih7IGl0ZW1zLCBzZWxlY3RlZCwgc2VsZWN0IH06IEhlcm9QYWdpbmF0aW9uUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHJpZ2h0LTAgYm90dG9tLTAgZmxleCBtaW4tWzM5MHB4XTpyaWdodC1hdXRvIG1pbi1bMzkwcHhdOmxlZnQtMS8yIG1pbi1bMzkwcHhdOi10cmFuc2xhdGUteC0xLzIgbWQ6Ym90dG9tLTEwIG1kOmxlZnQtWzY0JV0gbWQ6Z2FwLTIgbGc6bGVmdC1bNjAlXSB4bDpsZWZ0LVs1NiVdXCI+XG4gICAgICB7aXRlbXMubWFwKChpdGVtLCBpbmRleCkgPT4gKFxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAga2V5PXtpdGVtLmlkfVxuICAgICAgICAgIGFyaWEtbGFiZWw9e2BNb3N0cmFyIGRlc3RhcXVlICR7aW5kZXggKyAxfWB9XG4gICAgICAgICAgYXJpYS1wcmVzc2VkPXtzZWxlY3RlZCA9PT0gaW5kZXh9XG4gICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgc2VsZWN0KGluZGV4KTtcbiAgICAgICAgICB9fVxuICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggc2l6ZS0xMSBjdXJzb3ItcG9pbnRlciBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIG1kOnNpemUtNFwiXG4gICAgICAgID5cbiAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgc2l6ZS0xLjUgdHJhbnNsYXRlLXktMy41IHJvdW5kZWQtZnVsbCBtZDp0cmFuc2xhdGUteS0wICR7c2VsZWN0ZWQgPT09IGluZGV4ID8gJ2JnLXByaW1hcnknIDogJ2JnLWJvcmRlci1zb2Z0J31gfVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgKSl9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9maWxpcGVjYXZhbGNhbnRlL0RvY3VtZW50cy9KdW5nbGVHYW1pbmdUZXN0ZS9zcmMvZmVhdHVyZXMvY2F0YWxvZy9jb21wb25lbnRzL0hlcm9QYWdpbmF0aW9uLnRzeCJ9