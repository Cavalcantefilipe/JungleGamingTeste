import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=970a124b";
import { contentSchema } from "/src/contracts/content.ts";
import { apiRequest } from "/src/lib/http.ts";
export function useContentQuery() {
  return useQuery({
    queryKey: ["content"],
    queryFn: ({ signal }) => apiRequest(contentSchema, { url: "/content", signal }),
    staleTime: Infinity
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZUNvbnRlbnRRdWVyeS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSc7XG5cbmltcG9ydCB7IGNvbnRlbnRTY2hlbWEgfSBmcm9tICdAL2NvbnRyYWN0cy9jb250ZW50JztcbmltcG9ydCB7IGFwaVJlcXVlc3QgfSBmcm9tICdAL2xpYi9odHRwJztcblxuZXhwb3J0IGZ1bmN0aW9uIHVzZUNvbnRlbnRRdWVyeSgpIHtcbiAgcmV0dXJuIHVzZVF1ZXJ5KHtcbiAgICBxdWVyeUtleTogWydjb250ZW50J10sXG4gICAgcXVlcnlGbjogKHsgc2lnbmFsIH0pID0+IGFwaVJlcXVlc3QoY29udGVudFNjaGVtYSwgeyB1cmw6ICcvY29udGVudCcsIHNpZ25hbCB9KSxcbiAgICBzdGFsZVRpbWU6IEluZmluaXR5LFxuICB9KTtcbn1cbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFFekIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxrQkFBa0I7QUFFcEIsZ0JBQVMsa0JBQWtCO0FBQ2hDLFNBQU8sU0FBUztBQUFBLElBQ2QsVUFBVSxDQUFDLFNBQVM7QUFBQSxJQUNwQixTQUFTLENBQUMsRUFBRSxPQUFPLE1BQU0sV0FBVyxlQUFlLEVBQUUsS0FBSyxZQUFZLE9BQU8sQ0FBQztBQUFBLElBQzlFLFdBQVc7QUFBQSxFQUNiLENBQUM7QUFDSDsiLCJuYW1lcyI6W119