import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/PromotionCard.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { FigmaIcon } from "/src/components/icons/FigmaIcon.tsx";
import { ArtworkImage } from "/src/components/media/ArtworkImage.tsx";
import { Button } from "/src/components/ui/button.tsx";
export function PromotionCard({ promotion }) {
  return /* @__PURE__ */ jsxDEV("article", { className: "relative grid min-h-[250px] grid-cols-1 items-center overflow-hidden rounded-lg bg-surface-card sm:grid-cols-2", children: [
    /* @__PURE__ */ jsxDEV(
      ArtworkImage,
      {
        sizes: "(min-width: 1280px) 292px, (min-width: 768px) 25vw, (min-width: 640px) 50vw, calc(100vw - 48px)",
        src: promotion.image.src,
        alt: promotion.image.alt,
        width: 292,
        height: 250,
        loading: "lazy",
        className: "aspect-[292/250] w-full rounded-[18px] object-cover sm:h-full"
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PromotionCard.tsx",
        lineNumber: 9,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "relative space-y-3 p-5 text-right xl:py-6 xl:pr-[30px] xl:pl-0", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-lg leading-6 font-bold", children: promotion.title }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PromotionCard.tsx",
        lineNumber: 19,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-sm leading-6 text-text-secondary", children: promotion.description }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PromotionCard.tsx",
        lineNumber: 20,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { asChild: true, size: "promotion", children: /* @__PURE__ */ jsxDEV("a", { href: "#catalogo", children: [
        "Explorar ",
        /* @__PURE__ */ jsxDEV(FigmaIcon, { name: "arrow-right", "aria-hidden": "true", size: 16 }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PromotionCard.tsx",
          lineNumber: 23,
          columnNumber: 22
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PromotionCard.tsx",
        lineNumber: 22,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PromotionCard.tsx",
        lineNumber: 21,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PromotionCard.tsx",
      lineNumber: 18,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "svg",
      {
        "aria-hidden": "true",
        viewBox: "0 0 586 250",
        className: "pointer-events-none absolute inset-0 hidden size-full text-primary sm:block",
        preserveAspectRatio: "none",
        children: [
          /* @__PURE__ */ jsxDEV("circle", { cx: "-63", cy: "270", r: "127", fill: "none", stroke: "currentColor", strokeWidth: "2" }, void 0, false, {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PromotionCard.tsx",
            lineNumber: 33,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("circle", { cx: "-71", cy: "262", r: "127.5", fill: "none", stroke: "currentColor" }, void 0, false, {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PromotionCard.tsx",
            lineNumber: 34,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PromotionCard.tsx",
        lineNumber: 27,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PromotionCard.tsx",
    lineNumber: 8,
    columnNumber: 5
  }, this);
}
_c = PromotionCard;
var _c;
$RefreshReg$(_c, "PromotionCard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PromotionCard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PromotionCard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/PromotionCard.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUU07QUFSTixTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGNBQWM7QUFHaEIsZ0JBQVNDLGNBQWMsRUFBRUMsVUFBd0QsR0FBRztBQUN6RixTQUNFLHVCQUFDLGFBQVEsV0FBVSxrSEFDakI7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTTtBQUFBLFFBQ04sS0FBS0EsVUFBVUMsTUFBTUM7QUFBQUEsUUFDckIsS0FBS0YsVUFBVUMsTUFBTUU7QUFBQUEsUUFDckIsT0FBTztBQUFBLFFBQ1AsUUFBUTtBQUFBLFFBQ1IsU0FBUTtBQUFBLFFBQ1IsV0FBVTtBQUFBO0FBQUEsTUFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFPMkU7QUFBQSxJQUUzRSx1QkFBQyxTQUFJLFdBQVUsa0VBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsK0JBQStCSCxvQkFBVUksU0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RDtBQUFBLE1BQzdELHVCQUFDLE9BQUUsV0FBVSx5Q0FBeUNKLG9CQUFVSyxlQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRFO0FBQUEsTUFDNUUsdUJBQUMsVUFBTyxTQUFPLE1BQUMsTUFBSyxhQUNuQixpQ0FBQyxPQUFFLE1BQUssYUFBVztBQUFBO0FBQUEsUUFDUix1QkFBQyxhQUFVLE1BQUssZUFBYyxlQUFZLFFBQU8sTUFBTSxNQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBEO0FBQUEsV0FEckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsU0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUNBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxlQUFZO0FBQUEsUUFDWixTQUFRO0FBQUEsUUFDUixXQUFVO0FBQUEsUUFDVixxQkFBb0I7QUFBQSxRQUVwQjtBQUFBLGlDQUFDLFlBQU8sSUFBRyxPQUFNLElBQUcsT0FBTSxHQUFFLE9BQU0sTUFBSyxRQUFPLFFBQU8sZ0JBQWUsYUFBWSxPQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRjtBQUFBLFVBQ25GLHVCQUFDLFlBQU8sSUFBRyxPQUFNLElBQUcsT0FBTSxHQUFFLFNBQVEsTUFBSyxRQUFPLFFBQU8sa0JBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFFO0FBQUE7QUFBQTtBQUFBLE1BUHZFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVFBO0FBQUEsT0EzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRCQTtBQUVKO0FBQUNDLEtBaENlUDtBQUFhLElBQUFPO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkZpZ21hSWNvbiIsIkFydHdvcmtJbWFnZSIsIkJ1dHRvbiIsIlByb21vdGlvbkNhcmQiLCJwcm9tb3Rpb24iLCJpbWFnZSIsInNyYyIsImFsdCIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQcm9tb3Rpb25DYXJkLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGaWdtYUljb24gfSBmcm9tICdAL2NvbXBvbmVudHMvaWNvbnMvRmlnbWFJY29uJztcbmltcG9ydCB7IEFydHdvcmtJbWFnZSB9IGZyb20gJ0AvY29tcG9uZW50cy9tZWRpYS9BcnR3b3JrSW1hZ2UnO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbic7XG5pbXBvcnQgdHlwZSB7IENvbnRlbnQgfSBmcm9tICdAL2NvbnRyYWN0cy9jb250ZW50JztcblxuZXhwb3J0IGZ1bmN0aW9uIFByb21vdGlvbkNhcmQoeyBwcm9tb3Rpb24gfTogeyBwcm9tb3Rpb246IENvbnRlbnRbJ3Byb21vdGlvbnMnXVtudW1iZXJdIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8YXJ0aWNsZSBjbGFzc05hbWU9XCJyZWxhdGl2ZSBncmlkIG1pbi1oLVsyNTBweF0gZ3JpZC1jb2xzLTEgaXRlbXMtY2VudGVyIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLWxnIGJnLXN1cmZhY2UtY2FyZCBzbTpncmlkLWNvbHMtMlwiPlxuICAgICAgPEFydHdvcmtJbWFnZVxuICAgICAgICBzaXplcz1cIihtaW4td2lkdGg6IDEyODBweCkgMjkycHgsIChtaW4td2lkdGg6IDc2OHB4KSAyNXZ3LCAobWluLXdpZHRoOiA2NDBweCkgNTB2dywgY2FsYygxMDB2dyAtIDQ4cHgpXCJcbiAgICAgICAgc3JjPXtwcm9tb3Rpb24uaW1hZ2Uuc3JjfVxuICAgICAgICBhbHQ9e3Byb21vdGlvbi5pbWFnZS5hbHR9XG4gICAgICAgIHdpZHRoPXsyOTJ9XG4gICAgICAgIGhlaWdodD17MjUwfVxuICAgICAgICBsb2FkaW5nPVwibGF6eVwiXG4gICAgICAgIGNsYXNzTmFtZT1cImFzcGVjdC1bMjkyLzI1MF0gdy1mdWxsIHJvdW5kZWQtWzE4cHhdIG9iamVjdC1jb3ZlciBzbTpoLWZ1bGxcIlxuICAgICAgLz5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgc3BhY2UteS0zIHAtNSB0ZXh0LXJpZ2h0IHhsOnB5LTYgeGw6cHItWzMwcHhdIHhsOnBsLTBcIj5cbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgbGVhZGluZy02IGZvbnQtYm9sZFwiPntwcm9tb3Rpb24udGl0bGV9PC9oMj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBsZWFkaW5nLTYgdGV4dC10ZXh0LXNlY29uZGFyeVwiPntwcm9tb3Rpb24uZGVzY3JpcHRpb259PC9wPlxuICAgICAgICA8QnV0dG9uIGFzQ2hpbGQgc2l6ZT1cInByb21vdGlvblwiPlxuICAgICAgICAgIDxhIGhyZWY9XCIjY2F0YWxvZ29cIj5cbiAgICAgICAgICAgIEV4cGxvcmFyIDxGaWdtYUljb24gbmFtZT1cImFycm93LXJpZ2h0XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgc2l6ZT17MTZ9IC8+XG4gICAgICAgICAgPC9hPlxuICAgICAgICA8L0J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgICAgPHN2Z1xuICAgICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxuICAgICAgICB2aWV3Qm94PVwiMCAwIDU4NiAyNTBcIlxuICAgICAgICBjbGFzc05hbWU9XCJwb2ludGVyLWV2ZW50cy1ub25lIGFic29sdXRlIGluc2V0LTAgaGlkZGVuIHNpemUtZnVsbCB0ZXh0LXByaW1hcnkgc206YmxvY2tcIlxuICAgICAgICBwcmVzZXJ2ZUFzcGVjdFJhdGlvPVwibm9uZVwiXG4gICAgICA+XG4gICAgICAgIDxjaXJjbGUgY3g9XCItNjNcIiBjeT1cIjI3MFwiIHI9XCIxMjdcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMlwiIC8+XG4gICAgICAgIDxjaXJjbGUgY3g9XCItNzFcIiBjeT1cIjI2MlwiIHI9XCIxMjcuNVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgLz5cbiAgICAgIDwvc3ZnPlxuICAgIDwvYXJ0aWNsZT5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2ZpbGlwZWNhdmFsY2FudGUvRG9jdW1lbnRzL0p1bmdsZUdhbWluZ1Rlc3RlL3NyYy9mZWF0dXJlcy9jYXRhbG9nL2NvbXBvbmVudHMvUHJvbW90aW9uQ2FyZC50c3gifQ==