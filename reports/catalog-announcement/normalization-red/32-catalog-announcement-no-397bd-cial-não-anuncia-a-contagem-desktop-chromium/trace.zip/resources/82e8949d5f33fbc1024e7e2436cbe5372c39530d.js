import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/FilterDrawer.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=970a124b"; const useState = __vite__cjsImport1_react["useState"];
import { Button } from "/src/components/ui/button.tsx";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle
} from "/src/components/ui/sheet.tsx";
import { CatalogSortSelect } from "/src/features/catalog/components/CatalogSortSelect.tsx";
import { FilterDrawerTrigger } from "/src/features/catalog/components/FilterDrawerTrigger.tsx";
import { FilterSidebar } from "/src/features/catalog/components/FilterSidebar.tsx";
export function FilterDrawer({
  search,
  compact = false,
  facets,
  apply,
  clear
}) {
  _s();
  const [open, setOpen] = useState(false);
  const close = () => {
    setOpen(false);
  };
  return /* @__PURE__ */ jsxDEV(Sheet, { open, onOpenChange: setOpen, children: [
    /* @__PURE__ */ jsxDEV(FilterDrawerTrigger, { compact }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterDrawer.tsx",
      lineNumber: 29,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(SheetContent, { side: "left", className: "w-[min(360px,100vw)] overflow-y-auto bg-ink p-6", children: [
      /* @__PURE__ */ jsxDEV(SheetHeader, { className: "px-0", children: [
        /* @__PURE__ */ jsxDEV(SheetTitle, { children: "Filtrar NFTs" }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterDrawer.tsx",
          lineNumber: 32,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(SheetDescription, { children: "Combine coleções, preço e rede." }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterDrawer.tsx",
          lineNumber: 33,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterDrawer.tsx",
        lineNumber: 31,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        FilterSidebar,
        {
          search,
          ...facets ? { facets } : {},
          apply,
          clear
        },
        void 0,
        false,
        {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterDrawer.tsx",
          lineNumber: 35,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "my-5", children: /* @__PURE__ */ jsxDEV(
        CatalogSortSelect,
        {
          value: search.sort,
          change: (sort) => {
            apply({ sort });
          }
        },
        void 0,
        false,
        {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterDrawer.tsx",
          lineNumber: 42,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterDrawer.tsx",
        lineNumber: 41,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { className: "w-full", onClick: close, children: "Aplicar filtros" }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterDrawer.tsx",
        lineNumber: 49,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterDrawer.tsx",
      lineNumber: 30,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterDrawer.tsx",
    lineNumber: 28,
    columnNumber: 5
  }, this);
}
_s(FilterDrawer, "xG1TONbKtDWtdOTrXaTAsNhPg/Q=");
_c = FilterDrawer;
var _c;
$RefreshReg$(_c, "FilterDrawer");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterDrawer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterDrawer.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FilterDrawer.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEJNOztBQTVCTixTQUFTQSxnQkFBZ0I7QUFFekIsU0FBU0MsY0FBYztBQUN2QjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0MsMkJBQTJCO0FBQ3BDLFNBQVNDLHFCQUFxQjtBQUd2QixnQkFBU0MsYUFBYTtBQUFBLEVBQzNCQztBQUFBQSxFQUNBQyxVQUFVO0FBQUEsRUFDVkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDbUMsR0FBRztBQUFBQyxLQUFBO0FBQ3RDLFFBQU0sQ0FBQ0MsTUFBTUMsT0FBTyxJQUFJbEIsU0FBUyxLQUFLO0FBQ3RDLFFBQU1tQixRQUFRQSxNQUFNO0FBQ2xCRCxZQUFRLEtBQUs7QUFBQSxFQUNmO0FBQ0EsU0FDRSx1QkFBQyxTQUFNLE1BQVksY0FBY0EsU0FDL0I7QUFBQSwyQkFBQyx1QkFBb0IsV0FBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzQztBQUFBLElBQ3RDLHVCQUFDLGdCQUFhLE1BQUssUUFBTyxXQUFVLG1EQUNsQztBQUFBLDZCQUFDLGVBQVksV0FBVSxRQUNyQjtBQUFBLCtCQUFDLGNBQVcsNEJBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3QjtBQUFBLFFBQ3hCLHVCQUFDLG9CQUFpQiwrQ0FBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRDtBQUFBLFdBRm5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDO0FBQUEsVUFDQSxHQUFLTCxTQUFTLEVBQUVBLE9BQU8sSUFBSSxDQUFDO0FBQUEsVUFDNUI7QUFBQSxVQUNBO0FBQUE7QUFBQSxRQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUllO0FBQUEsTUFFZix1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBT0YsT0FBT1M7QUFBQUEsVUFDZCxRQUFRLENBQUNBLFNBQVM7QUFDaEJOLGtCQUFNLEVBQUVNLEtBQUssQ0FBQztBQUFBLFVBQ2hCO0FBQUE7QUFBQSxRQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUlJLEtBTE47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFDQSx1QkFBQyxVQUFPLFdBQVUsVUFBUyxTQUFTRCxPQUFNLCtCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0JBO0FBQUEsT0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXlCQTtBQUVKO0FBQUNILEdBdkNlTixjQUFZO0FBQUEsS0FBWkE7QUFBWSxJQUFBVztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkJ1dHRvbiIsIlNoZWV0IiwiU2hlZXRDb250ZW50IiwiU2hlZXREZXNjcmlwdGlvbiIsIlNoZWV0SGVhZGVyIiwiU2hlZXRUaXRsZSIsIkNhdGFsb2dTb3J0U2VsZWN0IiwiRmlsdGVyRHJhd2VyVHJpZ2dlciIsIkZpbHRlclNpZGViYXIiLCJGaWx0ZXJEcmF3ZXIiLCJzZWFyY2giLCJjb21wYWN0IiwiZmFjZXRzIiwiYXBwbHkiLCJjbGVhciIsIl9zIiwib3BlbiIsInNldE9wZW4iLCJjbG9zZSIsInNvcnQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJGaWx0ZXJEcmF3ZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJztcbmltcG9ydCB7XG4gIFNoZWV0LFxuICBTaGVldENvbnRlbnQsXG4gIFNoZWV0RGVzY3JpcHRpb24sXG4gIFNoZWV0SGVhZGVyLFxuICBTaGVldFRpdGxlLFxufSBmcm9tICdAL2NvbXBvbmVudHMvdWkvc2hlZXQnO1xuaW1wb3J0IHsgQ2F0YWxvZ1NvcnRTZWxlY3QgfSBmcm9tICdAL2ZlYXR1cmVzL2NhdGFsb2cvY29tcG9uZW50cy9DYXRhbG9nU29ydFNlbGVjdCc7XG5pbXBvcnQgeyBGaWx0ZXJEcmF3ZXJUcmlnZ2VyIH0gZnJvbSAnQC9mZWF0dXJlcy9jYXRhbG9nL2NvbXBvbmVudHMvRmlsdGVyRHJhd2VyVHJpZ2dlcic7XG5pbXBvcnQgeyBGaWx0ZXJTaWRlYmFyIH0gZnJvbSAnQC9mZWF0dXJlcy9jYXRhbG9nL2NvbXBvbmVudHMvRmlsdGVyU2lkZWJhcic7XG5pbXBvcnQgdHlwZSB7IEZpbHRlclByb3BzIH0gZnJvbSAnQC9mZWF0dXJlcy9jYXRhbG9nL2ZpbHRlci1wcm9wcyc7XG5cbmV4cG9ydCBmdW5jdGlvbiBGaWx0ZXJEcmF3ZXIoe1xuICBzZWFyY2gsXG4gIGNvbXBhY3QgPSBmYWxzZSxcbiAgZmFjZXRzLFxuICBhcHBseSxcbiAgY2xlYXIsXG59OiBGaWx0ZXJQcm9wcyAmIHsgY29tcGFjdD86IGJvb2xlYW4gfSkge1xuICBjb25zdCBbb3Blbiwgc2V0T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IGNsb3NlID0gKCkgPT4ge1xuICAgIHNldE9wZW4oZmFsc2UpO1xuICB9O1xuICByZXR1cm4gKFxuICAgIDxTaGVldCBvcGVuPXtvcGVufSBvbk9wZW5DaGFuZ2U9e3NldE9wZW59PlxuICAgICAgPEZpbHRlckRyYXdlclRyaWdnZXIgY29tcGFjdD17Y29tcGFjdH0gLz5cbiAgICAgIDxTaGVldENvbnRlbnQgc2lkZT1cImxlZnRcIiBjbGFzc05hbWU9XCJ3LVttaW4oMzYwcHgsMTAwdncpXSBvdmVyZmxvdy15LWF1dG8gYmctaW5rIHAtNlwiPlxuICAgICAgICA8U2hlZXRIZWFkZXIgY2xhc3NOYW1lPVwicHgtMFwiPlxuICAgICAgICAgIDxTaGVldFRpdGxlPkZpbHRyYXIgTkZUczwvU2hlZXRUaXRsZT5cbiAgICAgICAgICA8U2hlZXREZXNjcmlwdGlvbj5Db21iaW5lIGNvbGXDp8O1ZXMsIHByZcOnbyBlIHJlZGUuPC9TaGVldERlc2NyaXB0aW9uPlxuICAgICAgICA8L1NoZWV0SGVhZGVyPlxuICAgICAgICA8RmlsdGVyU2lkZWJhclxuICAgICAgICAgIHNlYXJjaD17c2VhcmNofVxuICAgICAgICAgIHsuLi4oZmFjZXRzID8geyBmYWNldHMgfSA6IHt9KX1cbiAgICAgICAgICBhcHBseT17YXBwbHl9XG4gICAgICAgICAgY2xlYXI9e2NsZWFyfVxuICAgICAgICAvPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm15LTVcIj5cbiAgICAgICAgICA8Q2F0YWxvZ1NvcnRTZWxlY3RcbiAgICAgICAgICAgIHZhbHVlPXtzZWFyY2guc29ydH1cbiAgICAgICAgICAgIGNoYW5nZT17KHNvcnQpID0+IHtcbiAgICAgICAgICAgICAgYXBwbHkoeyBzb3J0IH0pO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPEJ1dHRvbiBjbGFzc05hbWU9XCJ3LWZ1bGxcIiBvbkNsaWNrPXtjbG9zZX0+XG4gICAgICAgICAgQXBsaWNhciBmaWx0cm9zXG4gICAgICAgIDwvQnV0dG9uPlxuICAgICAgPC9TaGVldENvbnRlbnQ+XG4gICAgPC9TaGVldD5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2ZpbGlwZWNhdmFsY2FudGUvRG9jdW1lbnRzL0p1bmdsZUdhbWluZ1Rlc3RlL3NyYy9mZWF0dXJlcy9jYXRhbG9nL2NvbXBvbmVudHMvRmlsdGVyRHJhd2VyLnRzeCJ9