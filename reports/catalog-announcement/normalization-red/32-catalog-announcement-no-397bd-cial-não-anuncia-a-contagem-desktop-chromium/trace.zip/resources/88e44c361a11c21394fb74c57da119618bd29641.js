import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/CatalogTabs.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { useCatalogTabs } from "/src/features/catalog/useCatalogTabs.ts";
const tabs = [
  { key: "all", label: "Todos os NFTs" },
  { key: "new", label: "Novos lançamentos" },
  { key: "trending", label: "Em alta" }
];
export function CatalogTabs({
  selected,
  change
}) {
  _s();
  const navigateTab = useCatalogTabs(change);
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      role: "tablist",
      "aria-label": "Catálogo",
      className: "flex min-w-0 flex-wrap gap-2 text-xs min-[390px]:text-sm md:text-body-sm xl:gap-4",
      children: tabs.map(
        ({ key, label }, index) => /* @__PURE__ */ jsxDEV(
          "button",
          {
            role: "tab",
            id: `catalog-tab-${key}`,
            "aria-controls": "catalog-results",
            tabIndex: selected === key ? 0 : -1,
            "aria-selected": selected === key,
            onKeyDown: (event) => {
              navigateTab(event, index);
            },
            className: "relative min-h-11 cursor-pointer py-2 whitespace-nowrap text-foreground after:pointer-events-none after:absolute after:inset-x-0 after:bottom-2 after:h-0.5 hover:text-primary aria-selected:font-bold aria-selected:text-text-accent aria-selected:after:bg-primary md:min-h-6 md:py-0 md:after:bottom-0",
            onClick: () => {
              change(key);
            },
            children: label
          },
          key,
          false,
          {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogTabs.tsx",
            lineNumber: 24,
            columnNumber: 7
          },
          this
        )
      )
    },
    void 0,
    false,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogTabs.tsx",
      lineNumber: 18,
      columnNumber: 5
    },
    this
  );
}
_s(CatalogTabs, "lp37w/UkGQGxrdgUEguQt+ML/Fo=", false, function() {
  return [useCatalogTabs];
});
_c = CatalogTabs;
var _c;
$RefreshReg$(_c, "CatalogTabs");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogTabs.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogTabs.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogTabs.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUJROztBQXRCUixTQUFTQSxzQkFBc0I7QUFFL0IsTUFBTUMsT0FBTztBQUFBLEVBQ1gsRUFBRUMsS0FBSyxPQUFPQyxPQUFPLGdCQUFnQjtBQUFBLEVBQ3JDLEVBQUVELEtBQUssT0FBT0MsT0FBTyxvQkFBb0I7QUFBQSxFQUN6QyxFQUFFRCxLQUFLLFlBQVlDLE9BQU8sVUFBVTtBQUFDO0FBRWhDLGdCQUFTQyxZQUFZO0FBQUEsRUFDMUJDO0FBQUFBLEVBQ0FDO0FBSUYsR0FBRztBQUFBQyxLQUFBO0FBQ0QsUUFBTUMsY0FBY1IsZUFBZU0sTUFBTTtBQUN6QyxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxNQUFLO0FBQUEsTUFDTCxjQUFXO0FBQUEsTUFDWCxXQUFVO0FBQUEsTUFFVEwsZUFBS1E7QUFBQUEsUUFBSSxDQUFDLEVBQUVQLEtBQUtDLE1BQU0sR0FBR08sVUFDekI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVDLE1BQUs7QUFBQSxZQUNMLElBQUksZUFBZVIsR0FBRztBQUFBLFlBQ3RCLGlCQUFjO0FBQUEsWUFDZCxVQUFVRyxhQUFhSCxNQUFNLElBQUk7QUFBQSxZQUNqQyxpQkFBZUcsYUFBYUg7QUFBQUEsWUFDNUIsV0FBVyxDQUFDUyxVQUFVO0FBQ3BCSCwwQkFBWUcsT0FBT0QsS0FBSztBQUFBLFlBQzFCO0FBQUEsWUFDQSxXQUFVO0FBQUEsWUFDVixTQUFTLE1BQU07QUFDYkoscUJBQU9KLEdBQUc7QUFBQSxZQUNaO0FBQUEsWUFFQ0M7QUFBQUE7QUFBQUEsVUFkSUQ7QUFBQUEsVUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBZ0JBO0FBQUEsTUFDRDtBQUFBO0FBQUEsSUF2Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBd0JBO0FBRUo7QUFBQ0ssR0FuQ2VILGFBQVc7QUFBQSxVQU9MSixjQUFjO0FBQUE7QUFBQSxLQVBwQkk7QUFBVyxJQUFBUTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VDYXRhbG9nVGFicyIsInRhYnMiLCJrZXkiLCJsYWJlbCIsIkNhdGFsb2dUYWJzIiwic2VsZWN0ZWQiLCJjaGFuZ2UiLCJfcyIsIm5hdmlnYXRlVGFiIiwibWFwIiwiaW5kZXgiLCJldmVudCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNhdGFsb2dUYWJzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IENhdGFsb2dTZWFyY2ggfSBmcm9tICdAL2ZlYXR1cmVzL2NhdGFsb2cvc2VhcmNoLXBhcmFtcyc7XG5pbXBvcnQgeyB1c2VDYXRhbG9nVGFicyB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy91c2VDYXRhbG9nVGFicyc7XG5cbmNvbnN0IHRhYnMgPSBbXG4gIHsga2V5OiAnYWxsJywgbGFiZWw6ICdUb2RvcyBvcyBORlRzJyB9LFxuICB7IGtleTogJ25ldycsIGxhYmVsOiAnTm92b3MgbGFuw6dhbWVudG9zJyB9LFxuICB7IGtleTogJ3RyZW5kaW5nJywgbGFiZWw6ICdFbSBhbHRhJyB9LFxuXSBhcyBjb25zdDtcbmV4cG9ydCBmdW5jdGlvbiBDYXRhbG9nVGFicyh7XG4gIHNlbGVjdGVkLFxuICBjaGFuZ2UsXG59OiB7XG4gIHNlbGVjdGVkOiBDYXRhbG9nU2VhcmNoWyd0YWInXTtcbiAgY2hhbmdlOiAodGFiOiBDYXRhbG9nU2VhcmNoWyd0YWInXSkgPT4gdm9pZDtcbn0pIHtcbiAgY29uc3QgbmF2aWdhdGVUYWIgPSB1c2VDYXRhbG9nVGFicyhjaGFuZ2UpO1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIHJvbGU9XCJ0YWJsaXN0XCJcbiAgICAgIGFyaWEtbGFiZWw9XCJDYXTDoWxvZ29cIlxuICAgICAgY2xhc3NOYW1lPVwiZmxleCBtaW4tdy0wIGZsZXgtd3JhcCBnYXAtMiB0ZXh0LXhzIG1pbi1bMzkwcHhdOnRleHQtc20gbWQ6dGV4dC1ib2R5LXNtIHhsOmdhcC00XCJcbiAgICA+XG4gICAgICB7dGFicy5tYXAoKHsga2V5LCBsYWJlbCB9LCBpbmRleCkgPT4gKFxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAga2V5PXtrZXl9XG4gICAgICAgICAgcm9sZT1cInRhYlwiXG4gICAgICAgICAgaWQ9e2BjYXRhbG9nLXRhYi0ke2tleX1gfVxuICAgICAgICAgIGFyaWEtY29udHJvbHM9XCJjYXRhbG9nLXJlc3VsdHNcIlxuICAgICAgICAgIHRhYkluZGV4PXtzZWxlY3RlZCA9PT0ga2V5ID8gMCA6IC0xfVxuICAgICAgICAgIGFyaWEtc2VsZWN0ZWQ9e3NlbGVjdGVkID09PSBrZXl9XG4gICAgICAgICAgb25LZXlEb3duPXsoZXZlbnQpID0+IHtcbiAgICAgICAgICAgIG5hdmlnYXRlVGFiKGV2ZW50LCBpbmRleCk7XG4gICAgICAgICAgfX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSBtaW4taC0xMSBjdXJzb3ItcG9pbnRlciBweS0yIHdoaXRlc3BhY2Utbm93cmFwIHRleHQtZm9yZWdyb3VuZCBhZnRlcjpwb2ludGVyLWV2ZW50cy1ub25lIGFmdGVyOmFic29sdXRlIGFmdGVyOmluc2V0LXgtMCBhZnRlcjpib3R0b20tMiBhZnRlcjpoLTAuNSBob3Zlcjp0ZXh0LXByaW1hcnkgYXJpYS1zZWxlY3RlZDpmb250LWJvbGQgYXJpYS1zZWxlY3RlZDp0ZXh0LXRleHQtYWNjZW50IGFyaWEtc2VsZWN0ZWQ6YWZ0ZXI6YmctcHJpbWFyeSBtZDptaW4taC02IG1kOnB5LTAgbWQ6YWZ0ZXI6Ym90dG9tLTBcIlxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgIGNoYW5nZShrZXkpO1xuICAgICAgICAgIH19XG4gICAgICAgID5cbiAgICAgICAgICB7bGFiZWx9XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgKSl9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9maWxpcGVjYXZhbGNhbnRlL0RvY3VtZW50cy9KdW5nbGVHYW1pbmdUZXN0ZS9zcmMvZmVhdHVyZXMvY2F0YWxvZy9jb21wb25lbnRzL0NhdGFsb2dUYWJzLnRzeCJ9