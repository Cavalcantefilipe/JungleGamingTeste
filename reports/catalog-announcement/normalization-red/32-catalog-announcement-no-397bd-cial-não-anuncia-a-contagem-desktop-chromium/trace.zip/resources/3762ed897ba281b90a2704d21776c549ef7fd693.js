import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/CatalogItems.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { EmptyState } from "/src/components/feedback/EmptyState.tsx";
import { ErrorState } from "/src/components/feedback/ErrorState.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { NftGrid } from "/src/features/catalog/components/NftGrid.tsx";
export function CatalogItems({
  query,
  clear
}) {
  if (query.isError)
    return /* @__PURE__ */ jsxDEV(
      ErrorState,
      {
        error: query.error,
        retry: () => {
          void query.refetch();
        }
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogItems.tsx",
        lineNumber: 16,
        columnNumber: 5
      },
      this
    );
  if (query.data?.total === 0)
    return /* @__PURE__ */ jsxDEV(
      EmptyState,
      {
        title: "Nenhum NFT encontrado",
        description: "Experimente combinar outros filtros para encontrar sua próxima coleção.",
        action: /* @__PURE__ */ jsxDEV(Button, { onClick: clear, children: "Limpar filtros" }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogItems.tsx",
          lineNumber: 28,
          columnNumber: 15
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogItems.tsx",
        lineNumber: 25,
        columnNumber: 5
      },
      this
    );
  return /* @__PURE__ */ jsxDEV(NftGrid, { ...query.data ? { items: query.data.items } : {}, loading: query.isPending }, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogItems.tsx",
    lineNumber: 31,
    columnNumber: 10
  }, this);
}
_c = CatalogItems;
var _c;
$RefreshReg$(_c, "CatalogItems");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogItems.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogItems.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/CatalogItems.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZU07QUFmTixTQUFTQSxrQkFBa0I7QUFDM0IsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsZUFBZTtBQUdqQixnQkFBU0MsYUFBYTtBQUFBLEVBQzNCQztBQUFBQSxFQUNBQztBQUlGLEdBQUc7QUFDRCxNQUFJRCxNQUFNRTtBQUNSLFdBQ0U7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU9GLE1BQU1HO0FBQUFBLFFBQ2IsT0FBTyxNQUFNO0FBQ1gsZUFBS0gsTUFBTUksUUFBUTtBQUFBLFFBQ3JCO0FBQUE7QUFBQSxNQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUlJO0FBR1IsTUFBSUosTUFBTUssTUFBTUMsVUFBVTtBQUN4QixXQUNFO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUFNO0FBQUEsUUFDTixhQUFZO0FBQUEsUUFDWixRQUFRLHVCQUFDLFVBQU8sU0FBU0wsT0FBTyw4QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQztBQUFBO0FBQUEsTUFIaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRzBEO0FBRzlELFNBQU8sdUJBQUMsV0FBUSxHQUFLRCxNQUFNSyxPQUFPLEVBQUVFLE9BQU9QLE1BQU1LLEtBQUtFLE1BQU0sSUFBSSxDQUFDLEdBQUksU0FBU1AsTUFBTVEsYUFBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF1RjtBQUNoRztBQUFDQyxLQXpCZVY7QUFBWSxJQUFBVTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJFbXB0eVN0YXRlIiwiRXJyb3JTdGF0ZSIsIkJ1dHRvbiIsIk5mdEdyaWQiLCJDYXRhbG9nSXRlbXMiLCJxdWVyeSIsImNsZWFyIiwiaXNFcnJvciIsImVycm9yIiwicmVmZXRjaCIsImRhdGEiLCJ0b3RhbCIsIml0ZW1zIiwiaXNQZW5kaW5nIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ2F0YWxvZ0l0ZW1zLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBFbXB0eVN0YXRlIH0gZnJvbSAnQC9jb21wb25lbnRzL2ZlZWRiYWNrL0VtcHR5U3RhdGUnO1xuaW1wb3J0IHsgRXJyb3JTdGF0ZSB9IGZyb20gJ0AvY29tcG9uZW50cy9mZWVkYmFjay9FcnJvclN0YXRlJztcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nO1xuaW1wb3J0IHsgTmZ0R3JpZCB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy9jb21wb25lbnRzL05mdEdyaWQnO1xuaW1wb3J0IHR5cGUgeyB1c2VDYXRhbG9nUXVlcnkgfSBmcm9tICdAL2ZlYXR1cmVzL2NhdGFsb2cvcXVlcmllcyc7XG5cbmV4cG9ydCBmdW5jdGlvbiBDYXRhbG9nSXRlbXMoe1xuICBxdWVyeSxcbiAgY2xlYXIsXG59OiB7XG4gIHF1ZXJ5OiBSZXR1cm5UeXBlPHR5cGVvZiB1c2VDYXRhbG9nUXVlcnk+O1xuICBjbGVhcjogKCkgPT4gdm9pZDtcbn0pIHtcbiAgaWYgKHF1ZXJ5LmlzRXJyb3IpXG4gICAgcmV0dXJuIChcbiAgICAgIDxFcnJvclN0YXRlXG4gICAgICAgIGVycm9yPXtxdWVyeS5lcnJvcn1cbiAgICAgICAgcmV0cnk9eygpID0+IHtcbiAgICAgICAgICB2b2lkIHF1ZXJ5LnJlZmV0Y2goKTtcbiAgICAgICAgfX1cbiAgICAgIC8+XG4gICAgKTtcbiAgaWYgKHF1ZXJ5LmRhdGE/LnRvdGFsID09PSAwKVxuICAgIHJldHVybiAoXG4gICAgICA8RW1wdHlTdGF0ZVxuICAgICAgICB0aXRsZT1cIk5lbmh1bSBORlQgZW5jb250cmFkb1wiXG4gICAgICAgIGRlc2NyaXB0aW9uPVwiRXhwZXJpbWVudGUgY29tYmluYXIgb3V0cm9zIGZpbHRyb3MgcGFyYSBlbmNvbnRyYXIgc3VhIHByw7N4aW1hIGNvbGXDp8Ojby5cIlxuICAgICAgICBhY3Rpb249ezxCdXR0b24gb25DbGljaz17Y2xlYXJ9PkxpbXBhciBmaWx0cm9zPC9CdXR0b24+fVxuICAgICAgLz5cbiAgICApO1xuICByZXR1cm4gPE5mdEdyaWQgey4uLihxdWVyeS5kYXRhID8geyBpdGVtczogcXVlcnkuZGF0YS5pdGVtcyB9IDoge30pfSBsb2FkaW5nPXtxdWVyeS5pc1BlbmRpbmd9IC8+O1xufVxuIl0sImZpbGUiOiIvVXNlcnMvZmlsaXBlY2F2YWxjYW50ZS9Eb2N1bWVudHMvSnVuZ2xlR2FtaW5nVGVzdGUvc3JjL2ZlYXR1cmVzL2NhdGFsb2cvY29tcG9uZW50cy9DYXRhbG9nSXRlbXMudHN4In0=