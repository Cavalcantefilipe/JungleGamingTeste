import { useMutation, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=970a124b";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=970a124b";
import { sessionStore, useSession } from "/src/features/auth/session-store.ts";
import { setFavorite } from "/src/features/favorites/api.ts";
import {
  getFavoriteToggle,
  invalidateFavoriteLists,
  updateFavoriteCache
} from "/src/features/favorites/favorite-cache.ts";
import { favoriteMessages } from "/src/features/favorites/messages.ts";
import { ApiError } from "/src/lib/errors.ts";
import { queryKeys } from "/src/lib/query-keys.ts";
export function useToggleFavorite() {
  const session = useSession();
  const userId = session?.user.id ?? "";
  const client = useQueryClient();
  const key = queryKeys.favorites(userId);
  const mutationKey = ["favorite-mutation", userId];
  const isCurrentUser = () => Boolean(session && sessionStore.getSnapshot()?.token === session.token);
  const update = (nftId, remove) => {
    updateFavoriteCache(client, userId, nftId, remove);
  };
  const mutation = useMutation({
    mutationKey,
    mutationFn: ({ nftId, remove }) => {
      if (!isCurrentUser()) throw new ApiError("UNAUTHENTICATED", 401);
      return setFavorite(nftId, remove);
    },
    onMutate: async ({ nftId, remove }) => {
      await client.cancelQueries({ queryKey: key });
      if (!isCurrentUser()) return;
      update(nftId, remove);
    },
    onError: (_error, { nftId, remove }) => {
      if (!isCurrentUser()) return;
      update(nftId, !remove);
      toast.error(favoriteMessages.updateFailed);
    },
    onSettled: async () => {
      if (!isCurrentUser() || client.isMutating({ mutationKey }) !== 1) return;
      await invalidateFavoriteLists(client, userId);
    }
  });
  return {
    ...mutation,
    mutate: (nftId) => {
      mutation.mutate(getFavoriteToggle(client, userId, nftId));
    }
  };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZVRvZ2dsZUZhdm9yaXRlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3Nvbm5lcic7XG5cbmltcG9ydCB7IHNlc3Npb25TdG9yZSwgdXNlU2Vzc2lvbiB9IGZyb20gJ0AvZmVhdHVyZXMvYXV0aC9zZXNzaW9uLXN0b3JlJztcbmltcG9ydCB7IHNldEZhdm9yaXRlIH0gZnJvbSAnQC9mZWF0dXJlcy9mYXZvcml0ZXMvYXBpJztcbmltcG9ydCB7XG4gIGdldEZhdm9yaXRlVG9nZ2xlLFxuICBpbnZhbGlkYXRlRmF2b3JpdGVMaXN0cyxcbiAgdXBkYXRlRmF2b3JpdGVDYWNoZSxcbn0gZnJvbSAnQC9mZWF0dXJlcy9mYXZvcml0ZXMvZmF2b3JpdGUtY2FjaGUnO1xuaW1wb3J0IHsgZmF2b3JpdGVNZXNzYWdlcyB9IGZyb20gJ0AvZmVhdHVyZXMvZmF2b3JpdGVzL21lc3NhZ2VzJztcbmltcG9ydCB7IEFwaUVycm9yIH0gZnJvbSAnQC9saWIvZXJyb3JzJztcbmltcG9ydCB7IHF1ZXJ5S2V5cyB9IGZyb20gJ0AvbGliL3F1ZXJ5LWtleXMnO1xuXG5leHBvcnQgZnVuY3Rpb24gdXNlVG9nZ2xlRmF2b3JpdGUoKSB7XG4gIGNvbnN0IHNlc3Npb24gPSB1c2VTZXNzaW9uKCk7XG4gIGNvbnN0IHVzZXJJZCA9IHNlc3Npb24/LnVzZXIuaWQgPz8gJyc7XG4gIGNvbnN0IGNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KCk7XG4gIGNvbnN0IGtleSA9IHF1ZXJ5S2V5cy5mYXZvcml0ZXModXNlcklkKTtcbiAgY29uc3QgbXV0YXRpb25LZXkgPSBbJ2Zhdm9yaXRlLW11dGF0aW9uJywgdXNlcklkXTtcbiAgY29uc3QgaXNDdXJyZW50VXNlciA9ICgpID0+XG4gICAgQm9vbGVhbihzZXNzaW9uICYmIHNlc3Npb25TdG9yZS5nZXRTbmFwc2hvdCgpPy50b2tlbiA9PT0gc2Vzc2lvbi50b2tlbik7XG4gIGNvbnN0IHVwZGF0ZSA9IChuZnRJZDogc3RyaW5nLCByZW1vdmU6IGJvb2xlYW4pID0+IHtcbiAgICB1cGRhdGVGYXZvcml0ZUNhY2hlKGNsaWVudCwgdXNlcklkLCBuZnRJZCwgcmVtb3ZlKTtcbiAgfTtcbiAgY29uc3QgbXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XG4gICAgbXV0YXRpb25LZXksXG4gICAgbXV0YXRpb25GbjogKHsgbmZ0SWQsIHJlbW92ZSB9OiB7IG5mdElkOiBzdHJpbmc7IHJlbW92ZTogYm9vbGVhbiB9KSA9PiB7XG4gICAgICBpZiAoIWlzQ3VycmVudFVzZXIoKSkgdGhyb3cgbmV3IEFwaUVycm9yKCdVTkFVVEhFTlRJQ0FURUQnLCA0MDEpO1xuICAgICAgcmV0dXJuIHNldEZhdm9yaXRlKG5mdElkLCByZW1vdmUpO1xuICAgIH0sXG4gICAgb25NdXRhdGU6IGFzeW5jICh7IG5mdElkLCByZW1vdmUgfSkgPT4ge1xuICAgICAgYXdhaXQgY2xpZW50LmNhbmNlbFF1ZXJpZXMoeyBxdWVyeUtleToga2V5IH0pO1xuICAgICAgaWYgKCFpc0N1cnJlbnRVc2VyKCkpIHJldHVybjtcbiAgICAgIHVwZGF0ZShuZnRJZCwgcmVtb3ZlKTtcbiAgICB9LFxuICAgIG9uRXJyb3I6IChfZXJyb3IsIHsgbmZ0SWQsIHJlbW92ZSB9KSA9PiB7XG4gICAgICBpZiAoIWlzQ3VycmVudFVzZXIoKSkgcmV0dXJuO1xuICAgICAgdXBkYXRlKG5mdElkLCAhcmVtb3ZlKTtcbiAgICAgIHRvYXN0LmVycm9yKGZhdm9yaXRlTWVzc2FnZXMudXBkYXRlRmFpbGVkKTtcbiAgICB9LFxuICAgIG9uU2V0dGxlZDogYXN5bmMgKCkgPT4ge1xuICAgICAgaWYgKCFpc0N1cnJlbnRVc2VyKCkgfHwgY2xpZW50LmlzTXV0YXRpbmcoeyBtdXRhdGlvbktleSB9KSAhPT0gMSkgcmV0dXJuO1xuICAgICAgYXdhaXQgaW52YWxpZGF0ZUZhdm9yaXRlTGlzdHMoY2xpZW50LCB1c2VySWQpO1xuICAgIH0sXG4gIH0pO1xuICByZXR1cm4ge1xuICAgIC4uLm11dGF0aW9uLFxuICAgIG11dGF0ZTogKG5mdElkOiBzdHJpbmcpID0+IHtcbiAgICAgIG11dGF0aW9uLm11dGF0ZShnZXRGYXZvcml0ZVRvZ2dsZShjbGllbnQsIHVzZXJJZCwgbmZ0SWQpKTtcbiAgICB9LFxuICB9O1xufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLGFBQWEsc0JBQXNCO0FBQzVDLFNBQVMsYUFBYTtBQUV0QixTQUFTLGNBQWMsa0JBQWtCO0FBQ3pDLFNBQVMsbUJBQW1CO0FBQzVCO0FBQUEsRUFDRTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsT0FDSztBQUNQLFNBQVMsd0JBQXdCO0FBQ2pDLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsaUJBQWlCO0FBRW5CLGdCQUFTLG9CQUFvQjtBQUNsQyxRQUFNLFVBQVUsV0FBVztBQUMzQixRQUFNLFNBQVMsU0FBUyxLQUFLLE1BQU07QUFDbkMsUUFBTSxTQUFTLGVBQWU7QUFDOUIsUUFBTSxNQUFNLFVBQVUsVUFBVSxNQUFNO0FBQ3RDLFFBQU0sY0FBYyxDQUFDLHFCQUFxQixNQUFNO0FBQ2hELFFBQU0sZ0JBQWdCLE1BQ3BCLFFBQVEsV0FBVyxhQUFhLFlBQVksR0FBRyxVQUFVLFFBQVEsS0FBSztBQUN4RSxRQUFNLFNBQVMsQ0FBQyxPQUFlLFdBQW9CO0FBQ2pELHdCQUFvQixRQUFRLFFBQVEsT0FBTyxNQUFNO0FBQUEsRUFDbkQ7QUFDQSxRQUFNLFdBQVcsWUFBWTtBQUFBLElBQzNCO0FBQUEsSUFDQSxZQUFZLENBQUMsRUFBRSxPQUFPLE9BQU8sTUFBMEM7QUFDckUsVUFBSSxDQUFDLGNBQWMsRUFBRyxPQUFNLElBQUksU0FBUyxtQkFBbUIsR0FBRztBQUMvRCxhQUFPLFlBQVksT0FBTyxNQUFNO0FBQUEsSUFDbEM7QUFBQSxJQUNBLFVBQVUsT0FBTyxFQUFFLE9BQU8sT0FBTyxNQUFNO0FBQ3JDLFlBQU0sT0FBTyxjQUFjLEVBQUUsVUFBVSxJQUFJLENBQUM7QUFDNUMsVUFBSSxDQUFDLGNBQWMsRUFBRztBQUN0QixhQUFPLE9BQU8sTUFBTTtBQUFBLElBQ3RCO0FBQUEsSUFDQSxTQUFTLENBQUMsUUFBUSxFQUFFLE9BQU8sT0FBTyxNQUFNO0FBQ3RDLFVBQUksQ0FBQyxjQUFjLEVBQUc7QUFDdEIsYUFBTyxPQUFPLENBQUMsTUFBTTtBQUNyQixZQUFNLE1BQU0saUJBQWlCLFlBQVk7QUFBQSxJQUMzQztBQUFBLElBQ0EsV0FBVyxZQUFZO0FBQ3JCLFVBQUksQ0FBQyxjQUFjLEtBQUssT0FBTyxXQUFXLEVBQUUsWUFBWSxDQUFDLE1BQU0sRUFBRztBQUNsRSxZQUFNLHdCQUF3QixRQUFRLE1BQU07QUFBQSxJQUM5QztBQUFBLEVBQ0YsQ0FBQztBQUNELFNBQU87QUFBQSxJQUNMLEdBQUc7QUFBQSxJQUNILFFBQVEsQ0FBQyxVQUFrQjtBQUN6QixlQUFTLE9BQU8sa0JBQWtCLFFBQVEsUUFBUSxLQUFLLENBQUM7QUFBQSxJQUMxRDtBQUFBLEVBQ0Y7QUFDRjsiLCJuYW1lcyI6W119