import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/FeaturedCard.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=970a124b";
import { ArtworkImage } from "/src/components/media/ArtworkImage.tsx";
export function FeaturedCard({ nft }) {
  if (!nft) return null;
  return /* @__PURE__ */ jsxDEV(
    Link,
    {
      to: "/nfts/$nftId",
      params: { nftId: nft.id },
      className: "mt-8 block overflow-hidden bg-featured-gradient pt-7",
      children: [
        /* @__PURE__ */ jsxDEV("p", { className: "mb-5 px-5 text-2xl leading-[29px] font-bold text-text-accent", children: "NFT EM DESTAQUE" }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FeaturedCard.tsx",
          lineNumber: 14,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mb-3 text-center text-[22px] leading-4 font-bold", children: "OFERTA LIMITADA" }, void 0, false, {
          fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FeaturedCard.tsx",
          lineNumber: 17,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          ArtworkImage,
          {
            sizes: "310px",
            src: nft.images[0]?.src,
            alt: nft.images[0]?.alt ?? nft.name,
            width: 310,
            height: 368,
            loading: "lazy",
            className: "aspect-[310/368] w-full rounded-[22px] object-cover"
          },
          void 0,
          false,
          {
            fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FeaturedCard.tsx",
            lineNumber: 18,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FeaturedCard.tsx",
      lineNumber: 9,
      columnNumber: 5
    },
    this
  );
}
_c = FeaturedCard;
var _c;
$RefreshReg$(_c, "FeaturedCard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FeaturedCard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FeaturedCard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/FeaturedCard.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYU07QUFiTixTQUFTQSxZQUFZO0FBRXJCLFNBQVNDLG9CQUFvQjtBQUd0QixnQkFBU0MsYUFBYSxFQUFFQyxJQUFtQixHQUFHO0FBQ25ELE1BQUksQ0FBQ0EsSUFBSyxRQUFPO0FBQ2pCLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLElBQUc7QUFBQSxNQUNILFFBQVEsRUFBRUMsT0FBT0QsSUFBSUUsR0FBRztBQUFBLE1BQ3hCLFdBQVU7QUFBQSxNQUVWO0FBQUEsK0JBQUMsT0FBRSxXQUFVLGdFQUE4RCwrQkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsb0RBQW1ELCtCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStFO0FBQUEsUUFDL0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLEtBQUtGLElBQUlHLE9BQU8sQ0FBQyxHQUFHQztBQUFBQSxZQUNwQixLQUFLSixJQUFJRyxPQUFPLENBQUMsR0FBR0UsT0FBT0wsSUFBSU07QUFBQUEsWUFDL0IsT0FBTztBQUFBLFlBQ1AsUUFBUTtBQUFBLFlBQ1IsU0FBUTtBQUFBLFlBQ1IsV0FBVTtBQUFBO0FBQUEsVUFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPaUU7QUFBQTtBQUFBO0FBQUEsSUFoQm5FO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWtCQTtBQUVKO0FBQUNDLEtBdkJlUjtBQUFZLElBQUFRO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkxpbmsiLCJBcnR3b3JrSW1hZ2UiLCJGZWF0dXJlZENhcmQiLCJuZnQiLCJuZnRJZCIsImlkIiwiaW1hZ2VzIiwic3JjIiwiYWx0IiwibmFtZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkZlYXR1cmVkQ2FyZC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluayB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInO1xuXG5pbXBvcnQgeyBBcnR3b3JrSW1hZ2UgfSBmcm9tICdAL2NvbXBvbmVudHMvbWVkaWEvQXJ0d29ya0ltYWdlJztcbmltcG9ydCB0eXBlIHsgTmZ0IH0gZnJvbSAnQC9jb250cmFjdHMvbmZ0JztcblxuZXhwb3J0IGZ1bmN0aW9uIEZlYXR1cmVkQ2FyZCh7IG5mdCB9OiB7IG5mdD86IE5mdCB9KSB7XG4gIGlmICghbmZ0KSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIChcbiAgICA8TGlua1xuICAgICAgdG89XCIvbmZ0cy8kbmZ0SWRcIlxuICAgICAgcGFyYW1zPXt7IG5mdElkOiBuZnQuaWQgfX1cbiAgICAgIGNsYXNzTmFtZT1cIm10LTggYmxvY2sgb3ZlcmZsb3ctaGlkZGVuIGJnLWZlYXR1cmVkLWdyYWRpZW50IHB0LTdcIlxuICAgID5cbiAgICAgIDxwIGNsYXNzTmFtZT1cIm1iLTUgcHgtNSB0ZXh0LTJ4bCBsZWFkaW5nLVsyOXB4XSBmb250LWJvbGQgdGV4dC10ZXh0LWFjY2VudFwiPlxuICAgICAgICBORlQgRU0gREVTVEFRVUVcbiAgICAgIDwvcD5cbiAgICAgIDxwIGNsYXNzTmFtZT1cIm1iLTMgdGV4dC1jZW50ZXIgdGV4dC1bMjJweF0gbGVhZGluZy00IGZvbnQtYm9sZFwiPk9GRVJUQSBMSU1JVEFEQTwvcD5cbiAgICAgIDxBcnR3b3JrSW1hZ2VcbiAgICAgICAgc2l6ZXM9XCIzMTBweFwiXG4gICAgICAgIHNyYz17bmZ0LmltYWdlc1swXT8uc3JjfVxuICAgICAgICBhbHQ9e25mdC5pbWFnZXNbMF0/LmFsdCA/PyBuZnQubmFtZX1cbiAgICAgICAgd2lkdGg9ezMxMH1cbiAgICAgICAgaGVpZ2h0PXszNjh9XG4gICAgICAgIGxvYWRpbmc9XCJsYXp5XCJcbiAgICAgICAgY2xhc3NOYW1lPVwiYXNwZWN0LVszMTAvMzY4XSB3LWZ1bGwgcm91bmRlZC1bMjJweF0gb2JqZWN0LWNvdmVyXCJcbiAgICAgIC8+XG4gICAgPC9MaW5rPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvZmlsaXBlY2F2YWxjYW50ZS9Eb2N1bWVudHMvSnVuZ2xlR2FtaW5nVGVzdGUvc3JjL2ZlYXR1cmVzL2NhdGFsb2cvY29tcG9uZW50cy9GZWF0dXJlZENhcmQudHN4In0=