import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/HeroArtwork.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { ArtworkImage } from "/src/components/media/ArtworkImage.tsx";
import { Skeleton } from "/src/components/ui/skeleton.tsx";
export function HeroArtwork({ nft, secondary, loading }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "absolute top-3 right-4 w-[38%] max-w-[138px] md:static md:w-full md:max-w-none", children: [
    loading ? /* @__PURE__ */ jsxDEV(Skeleton, { className: "aspect-square w-full rounded-xl md:rounded-3xl" }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroArtwork.tsx",
      lineNumber: 14,
      columnNumber: 7
    }, this) : nft ? /* @__PURE__ */ jsxDEV(
      ArtworkImage,
      {
        sizes: "(min-width: 1280px) 450px, (min-width: 768px) 40vw, 138px",
        loading: "eager",
        src: nft.images[0]?.src,
        alt: nft.images[0]?.alt ?? nft.name,
        width: 450,
        height: 450,
        fetchPriority: "high",
        className: "aspect-square w-full rounded-2xl object-cover md:rounded-3xl"
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroArtwork.tsx",
        lineNumber: 16,
        columnNumber: 7
      },
      this
    ) : /* @__PURE__ */ jsxDEV("div", { className: "aspect-square rounded-xl bg-surface-raised md:rounded-3xl" }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroArtwork.tsx",
      lineNumber: 27,
      columnNumber: 7
    }, this),
    secondary && /* @__PURE__ */ jsxDEV(
      ArtworkImage,
      {
        sizes: "58px",
        src: secondary.images[0]?.src,
        alt: "",
        width: 58,
        height: 58,
        className: "absolute -bottom-2 left-3.5 size-[58px] rounded-2xl object-cover md:hidden"
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroArtwork.tsx",
        lineNumber: 30,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroArtwork.tsx",
    lineNumber: 12,
    columnNumber: 5
  }, this);
}
_c = HeroArtwork;
var _c;
$RefreshReg$(_c, "HeroArtwork");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroArtwork.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroArtwork.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/HeroArtwork.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYVE7QUFiUixTQUFTQSxvQkFBb0I7QUFDN0IsU0FBU0MsZ0JBQWdCO0FBUWxCLGdCQUFTQyxZQUFZLEVBQUVDLEtBQUtDLFdBQVdDLFFBQTBCLEdBQUc7QUFDekUsU0FDRSx1QkFBQyxTQUFJLFdBQVUsa0ZBQ1pBO0FBQUFBLGNBQ0MsdUJBQUMsWUFBUyxXQUFVLG9EQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9FLElBQ2xFRixNQUNGO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUFNO0FBQUEsUUFDTixTQUFRO0FBQUEsUUFDUixLQUFLQSxJQUFJRyxPQUFPLENBQUMsR0FBR0M7QUFBQUEsUUFDcEIsS0FBS0osSUFBSUcsT0FBTyxDQUFDLEdBQUdFLE9BQU9MLElBQUlNO0FBQUFBLFFBQy9CLE9BQU87QUFBQSxRQUNQLFFBQVE7QUFBQSxRQUNSLGVBQWM7QUFBQSxRQUNkLFdBQVU7QUFBQTtBQUFBLE1BUlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBUTBFLElBRzFFLHVCQUFDLFNBQUksV0FBVSwrREFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBFO0FBQUEsSUFFM0VMLGFBQ0M7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU07QUFBQSxRQUNOLEtBQUtBLFVBQVVFLE9BQU8sQ0FBQyxHQUFHQztBQUFBQSxRQUMxQixLQUFJO0FBQUEsUUFDSixPQUFPO0FBQUEsUUFDUCxRQUFRO0FBQUEsUUFDUixXQUFVO0FBQUE7QUFBQSxNQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU13RjtBQUFBLE9BeEI1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMkJBO0FBRUo7QUFBQ0csS0EvQmVSO0FBQVcsSUFBQVE7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiQXJ0d29ya0ltYWdlIiwiU2tlbGV0b24iLCJIZXJvQXJ0d29yayIsIm5mdCIsInNlY29uZGFyeSIsImxvYWRpbmciLCJpbWFnZXMiLCJzcmMiLCJhbHQiLCJuYW1lIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSGVyb0FydHdvcmsudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFydHdvcmtJbWFnZSB9IGZyb20gJ0AvY29tcG9uZW50cy9tZWRpYS9BcnR3b3JrSW1hZ2UnO1xuaW1wb3J0IHsgU2tlbGV0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvc2tlbGV0b24nO1xuaW1wb3J0IHR5cGUgeyBOZnQgfSBmcm9tICdAL2NvbnRyYWN0cy9uZnQnO1xuXG5pbnRlcmZhY2UgSGVyb0FydHdvcmtQcm9wcyB7XG4gIG5mdDogTmZ0IHwgdW5kZWZpbmVkO1xuICBzZWNvbmRhcnk6IE5mdCB8IHVuZGVmaW5lZDtcbiAgbG9hZGluZzogYm9vbGVhbjtcbn1cbmV4cG9ydCBmdW5jdGlvbiBIZXJvQXJ0d29yayh7IG5mdCwgc2Vjb25kYXJ5LCBsb2FkaW5nIH06IEhlcm9BcnR3b3JrUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0zIHJpZ2h0LTQgdy1bMzglXSBtYXgtdy1bMTM4cHhdIG1kOnN0YXRpYyBtZDp3LWZ1bGwgbWQ6bWF4LXctbm9uZVwiPlxuICAgICAge2xvYWRpbmcgPyAoXG4gICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJhc3BlY3Qtc3F1YXJlIHctZnVsbCByb3VuZGVkLXhsIG1kOnJvdW5kZWQtM3hsXCIgLz5cbiAgICAgICkgOiBuZnQgPyAoXG4gICAgICAgIDxBcnR3b3JrSW1hZ2VcbiAgICAgICAgICBzaXplcz1cIihtaW4td2lkdGg6IDEyODBweCkgNDUwcHgsIChtaW4td2lkdGg6IDc2OHB4KSA0MHZ3LCAxMzhweFwiXG4gICAgICAgICAgbG9hZGluZz1cImVhZ2VyXCJcbiAgICAgICAgICBzcmM9e25mdC5pbWFnZXNbMF0/LnNyY31cbiAgICAgICAgICBhbHQ9e25mdC5pbWFnZXNbMF0/LmFsdCA/PyBuZnQubmFtZX1cbiAgICAgICAgICB3aWR0aD17NDUwfVxuICAgICAgICAgIGhlaWdodD17NDUwfVxuICAgICAgICAgIGZldGNoUHJpb3JpdHk9XCJoaWdoXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJhc3BlY3Qtc3F1YXJlIHctZnVsbCByb3VuZGVkLTJ4bCBvYmplY3QtY292ZXIgbWQ6cm91bmRlZC0zeGxcIlxuICAgICAgICAvPlxuICAgICAgKSA6IChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhc3BlY3Qtc3F1YXJlIHJvdW5kZWQteGwgYmctc3VyZmFjZS1yYWlzZWQgbWQ6cm91bmRlZC0zeGxcIiAvPlxuICAgICAgKX1cbiAgICAgIHtzZWNvbmRhcnkgJiYgKFxuICAgICAgICA8QXJ0d29ya0ltYWdlXG4gICAgICAgICAgc2l6ZXM9XCI1OHB4XCJcbiAgICAgICAgICBzcmM9e3NlY29uZGFyeS5pbWFnZXNbMF0/LnNyY31cbiAgICAgICAgICBhbHQ9XCJcIlxuICAgICAgICAgIHdpZHRoPXs1OH1cbiAgICAgICAgICBoZWlnaHQ9ezU4fVxuICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIC1ib3R0b20tMiBsZWZ0LTMuNSBzaXplLVs1OHB4XSByb3VuZGVkLTJ4bCBvYmplY3QtY292ZXIgbWQ6aGlkZGVuXCJcbiAgICAgICAgLz5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9maWxpcGVjYXZhbGNhbnRlL0RvY3VtZW50cy9KdW5nbGVHYW1pbmdUZXN0ZS9zcmMvZmVhdHVyZXMvY2F0YWxvZy9jb21wb25lbnRzL0hlcm9BcnR3b3JrLnRzeCJ9