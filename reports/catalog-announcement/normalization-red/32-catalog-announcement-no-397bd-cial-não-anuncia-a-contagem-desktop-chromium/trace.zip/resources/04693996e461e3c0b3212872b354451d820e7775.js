import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/components/EditorialSections.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=970a124b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { ErrorState } from "/src/components/feedback/ErrorState.tsx";
import { Skeleton } from "/src/components/ui/skeleton.tsx";
import { EditorialContent } from "/src/features/catalog/components/EditorialContent.tsx";
import { useContentQuery } from "/src/features/catalog/useContentQuery.ts";
export function EditorialSections() {
  _s();
  const query = useContentQuery();
  if (query.isError)
    return /* @__PURE__ */ jsxDEV("section", { "aria-label": "Conteúdo editorial", className: "mt-24", children: /* @__PURE__ */ jsxDEV(
      ErrorState,
      {
        error: query.error,
        retry: () => {
          void query.refetch();
        },
        title: "Conteúdo editorial indisponível",
        retryLabel: "Recarregar conteúdo editorial"
      },
      void 0,
      false,
      {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialSections.tsx",
        lineNumber: 11,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialSections.tsx",
      lineNumber: 10,
      columnNumber: 5
    }, this);
  if (!query.data)
    return /* @__PURE__ */ jsxDEV("div", { className: "mt-24 space-y-24", children: [
      /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-64 w-full" }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialSections.tsx",
        lineNumber: 24,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-80 w-full" }, void 0, false, {
        fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialSections.tsx",
        lineNumber: 25,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialSections.tsx",
      lineNumber: 23,
      columnNumber: 5
    }, this);
  return /* @__PURE__ */ jsxDEV(EditorialContent, { content: query.data }, void 0, false, {
    fileName: "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialSections.tsx",
    lineNumber: 28,
    columnNumber: 10
  }, this);
}
_s(EditorialSections, "Xy+78SKn+r06z9GKcBrK8mGmcN0=", false, function() {
  return [useContentQuery];
});
_c = EditorialSections;
var _c;
$RefreshReg$(_c, "EditorialSections");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialSections.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialSections.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/filipecavalcante/Documents/JungleGamingTeste/src/features/catalog/components/EditorialSections.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVVE7O0FBVlIsU0FBU0Esa0JBQWtCO0FBQzNCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyx3QkFBd0I7QUFDakMsU0FBU0MsdUJBQXVCO0FBRXpCLGdCQUFTQyxvQkFBb0I7QUFBQUMsS0FBQTtBQUNsQyxRQUFNQyxRQUFRSCxnQkFBZ0I7QUFDOUIsTUFBSUcsTUFBTUM7QUFDUixXQUNFLHVCQUFDLGFBQVEsY0FBVyxzQkFBcUIsV0FBVSxTQUNqRDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBT0QsTUFBTUU7QUFBQUEsUUFDYixPQUFPLE1BQU07QUFDWCxlQUFLRixNQUFNRyxRQUFRO0FBQUEsUUFDckI7QUFBQSxRQUNBLE9BQU07QUFBQSxRQUNOLFlBQVc7QUFBQTtBQUFBLE1BTmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTTRDLEtBUDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUVKLE1BQUksQ0FBQ0gsTUFBTUk7QUFDVCxXQUNFLHVCQUFDLFNBQUksV0FBVSxvQkFDYjtBQUFBLDZCQUFDLFlBQVMsV0FBVSxpQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLE1BQ2pDLHVCQUFDLFlBQVMsV0FBVSxpQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLFNBRm5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUVKLFNBQU8sdUJBQUMsb0JBQWlCLFNBQVNKLE1BQU1JLFFBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBc0M7QUFDL0M7QUFBQ0wsR0F2QmVELG1CQUFpQjtBQUFBLFVBQ2pCRCxlQUFlO0FBQUE7QUFBQSxLQURmQztBQUFpQixJQUFBTztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJFcnJvclN0YXRlIiwiU2tlbGV0b24iLCJFZGl0b3JpYWxDb250ZW50IiwidXNlQ29udGVudFF1ZXJ5IiwiRWRpdG9yaWFsU2VjdGlvbnMiLCJfcyIsInF1ZXJ5IiwiaXNFcnJvciIsImVycm9yIiwicmVmZXRjaCIsImRhdGEiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJFZGl0b3JpYWxTZWN0aW9ucy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRXJyb3JTdGF0ZSB9IGZyb20gJ0AvY29tcG9uZW50cy9mZWVkYmFjay9FcnJvclN0YXRlJztcbmltcG9ydCB7IFNrZWxldG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL3NrZWxldG9uJztcbmltcG9ydCB7IEVkaXRvcmlhbENvbnRlbnQgfSBmcm9tICdAL2ZlYXR1cmVzL2NhdGFsb2cvY29tcG9uZW50cy9FZGl0b3JpYWxDb250ZW50JztcbmltcG9ydCB7IHVzZUNvbnRlbnRRdWVyeSB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy91c2VDb250ZW50UXVlcnknO1xuXG5leHBvcnQgZnVuY3Rpb24gRWRpdG9yaWFsU2VjdGlvbnMoKSB7XG4gIGNvbnN0IHF1ZXJ5ID0gdXNlQ29udGVudFF1ZXJ5KCk7XG4gIGlmIChxdWVyeS5pc0Vycm9yKVxuICAgIHJldHVybiAoXG4gICAgICA8c2VjdGlvbiBhcmlhLWxhYmVsPVwiQ29udGXDumRvIGVkaXRvcmlhbFwiIGNsYXNzTmFtZT1cIm10LTI0XCI+XG4gICAgICAgIDxFcnJvclN0YXRlXG4gICAgICAgICAgZXJyb3I9e3F1ZXJ5LmVycm9yfVxuICAgICAgICAgIHJldHJ5PXsoKSA9PiB7XG4gICAgICAgICAgICB2b2lkIHF1ZXJ5LnJlZmV0Y2goKTtcbiAgICAgICAgICB9fVxuICAgICAgICAgIHRpdGxlPVwiQ29udGXDumRvIGVkaXRvcmlhbCBpbmRpc3BvbsOtdmVsXCJcbiAgICAgICAgICByZXRyeUxhYmVsPVwiUmVjYXJyZWdhciBjb250ZcO6ZG8gZWRpdG9yaWFsXCJcbiAgICAgICAgLz5cbiAgICAgIDwvc2VjdGlvbj5cbiAgICApO1xuICBpZiAoIXF1ZXJ5LmRhdGEpXG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMjQgc3BhY2UteS0yNFwiPlxuICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC02NCB3LWZ1bGxcIiAvPlxuICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC04MCB3LWZ1bGxcIiAvPlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgcmV0dXJuIDxFZGl0b3JpYWxDb250ZW50IGNvbnRlbnQ9e3F1ZXJ5LmRhdGF9IC8+O1xufVxuIl0sImZpbGUiOiIvVXNlcnMvZmlsaXBlY2F2YWxjYW50ZS9Eb2N1bWVudHMvSnVuZ2xlR2FtaW5nVGVzdGUvc3JjL2ZlYXR1cmVzL2NhdGFsb2cvY29tcG9uZW50cy9FZGl0b3JpYWxTZWN0aW9ucy50c3gifQ==