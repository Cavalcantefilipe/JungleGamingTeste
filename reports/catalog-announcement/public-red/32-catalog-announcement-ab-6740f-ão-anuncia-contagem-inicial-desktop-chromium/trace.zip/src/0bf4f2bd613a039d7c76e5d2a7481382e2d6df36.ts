import { expect, test } from './fixtures/kurio';

const resultAnnouncement = (page: import('@playwright/test').Page) =>
  page.locator('[aria-live="polite"]').filter({ hasText: /NFTs? encontrad/ });

test('abrir e recarregar catálogo com filtros não anuncia contagem inicial', async ({ page }) => {
  await page.goto('/?q=Cosmic&scenario=slow-network');
  await expect(page.getByLabel('Carregando NFT').first()).toBeVisible();
  await expect(resultAnnouncement(page)).toHaveCount(0);
  await expect(page.getByTestId('nft-grid').getByRole('link').first()).toContainText('Cosmic');
  await expect(resultAnnouncement(page)).toHaveCount(0);
  await page.reload();
  await expect(page.getByTestId('nft-grid').getByRole('link').first()).toContainText('Cosmic');
  await expect(resultAnnouncement(page)).toHaveCount(0);
});

test('busca e retorno aos filtros iniciais anunciam resultados sem duplicar a contagem', async ({
  page,
  isMobile,
}) => {
  await page.goto('/');
  await expect(page.getByTestId('nft-grid').getByRole('link')).toHaveCount(9);
  if (!isMobile) await page.getByRole('link', { name: 'Buscar NFTs', exact: true }).click();
  await page.getByRole('searchbox', { name: 'Buscar NFTs', exact: true }).fill('Cosmic Bloom');
  await expect(resultAnnouncement(page)).toHaveText('1 NFT encontrado');
  await expect(page.getByText('1 NFT encontrado', { exact: true })).toHaveCount(1);
  await page.getByRole('searchbox', { name: 'Buscar NFTs', exact: true }).fill('');
  await expect(resultAnnouncement(page)).toHaveText('48 NFTs encontrados');
  await page.getByRole('button', { name: 'Página 2', exact: true }).click();
  await expect(page).toHaveURL(/page=2/);
  await expect(resultAnnouncement(page)).toHaveText('48 NFTs encontrados');
});

test('filtro acionado pelo rodapé também anuncia o resultado', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByTestId('nft-grid')).toBeVisible();
  await page.getByRole('contentinfo').getByRole('link', { name: 'Arte digital', exact: true }).click();
  await expect(page).toHaveURL(/category=arte-digital/);
  await expect(resultAnnouncement(page)).toContainText('NFTs encontrados');
});
